# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 8.6-将函数存储在模块中.py
@time: 2019/11/1 13:38
"""

# 8.6.1 导入整个模块
# import pizza

# 8.6.2 导入特定的函数
# from pizza import make_pizza

# 8.6.3 使用as给函数指定别名
# from pizza import make_pizza as mp

# 8.6.4 使用as给模块指定别名
# import pizza as p

# 8.6.5 导入模块中的所有函数
# from pizza import *
