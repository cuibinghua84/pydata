# -*- coding: utf-8 -*-
"""
@author: 东风
@file: note.py
@time: 2019/11/21 13:50
"""


def fs():
    print("*" * 40)

# 9.1 创建Dog类
