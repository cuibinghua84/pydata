# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 6.1-一个简单的字典.py
@time: 2019/11/1 13:36
"""

alien_0 = {'color': 'green', 'points': 5}
print(alien_0['color'])
print(alien_0['points'])
