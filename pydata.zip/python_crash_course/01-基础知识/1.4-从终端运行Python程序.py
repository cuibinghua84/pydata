# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 1.4-从终端运行Python程序.py
@time: 2019/10/30 10:47
"""