# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 1.3-解决按照问题.py
@time: 2019/10/30 10:47
"""