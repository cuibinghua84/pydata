# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 1.2-在不同操作系统中搭建Python编程环境.py
@time: 2019/10/30 10:46
"""