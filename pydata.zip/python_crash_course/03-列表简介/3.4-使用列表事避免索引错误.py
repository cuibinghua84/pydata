# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 3.4-使用列表事避免索引错误.py
@time: 2019/10/30 10:58
"""