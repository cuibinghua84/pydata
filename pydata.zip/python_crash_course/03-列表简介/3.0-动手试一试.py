# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 3.0-动手试一试.py
@time: 2019/10/31 9:42
"""

# 3-1 姓名
names = ['cui', 'li', 'xia']
print(names[0])
print(names[1])
print(names[2])

# 3-2 问候语

# 3-3 自己的列表




