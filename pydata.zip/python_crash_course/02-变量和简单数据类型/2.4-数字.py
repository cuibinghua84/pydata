# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 2.4-数字.py
@time: 2019/10/30 10:56
"""

# 2.4.1 整数
print(2 + 3)
print(3 - 2)
print(2 * 3)
print(3 / 2)
print(3 ** 2)
print(3 ** 3)
print(10 ** 6)
print(2 + 3 * 4)
print((2 + 3) * 4)

# 2.4.1 浮点数
print(0.1 + 0.1)
print(0.2 + 0.2)
print(2 * 0.1)
print(2 * 0.2)
print(0.2 + 0.1)
print(3 * 0.1)

# 2.4.3 str()函数
age = 36
message = "Happy " + str(age) + "rd Birthday!"
print(message)
