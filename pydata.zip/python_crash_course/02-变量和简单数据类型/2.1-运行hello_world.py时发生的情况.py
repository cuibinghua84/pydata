# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 2.1-运行hello_world.py时发生的情况.py
@time: 2019/10/30 10:55
"""
print("Hello Python world!")

