# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 5.5-设置if语句的格式.py
@time: 2019/10/30 11:02
"""