# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 5.1-一个简单示例.py
@time: 2019/10/30 11:00
"""

cars = ['audi', 'bmw', 'subaru', 'toyota']
for car in cars:
	if car == 'bmw':
		print(car.upper())
	else:
		print(car.title())

