# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:13
# 文件      : 5.1-字典数据类型.py
# IDE       : PyCharm


myCat = {'size': 'fat', 'color': 'gray', 'disposition': 'loud'}
# print(myCat['size'])
# print('My cat has ' + myCat['color'] + ' fur.')
# spam = {12345: 'Luggage Combination', 42: 'The Answer'}


# 5.1.1 字典与列表
# 字典中表项是不排序的
# spam = ['cats', 'dogs', 'moose']
# bacon = ['dogs', 'moose', 'cats']
# print(spam == bacon)

# eggs = {'name': 'Zophie', 'species': 'cat', 'age': '8'}
# ham = {'species': 'cat', 'age': '8', 'name': 'Zophie'}
# print(eggs == ham)


# birthdays = {'Alice': 'Apr 1', 'Bob': 'Dec 12', 'Carol': 'Mar 4'}
# while True:
# 	print('Enter a name: (blank to quit)')
# 	name = input()
# 	if name == '':
# 		break

# 	if name in birthdays:
# 		print(birthdays[name] + ' is the birthday of ' + name)
# 	else:
# 		print('I do not have birthday information for ' + name)
# 		print('What is their birthday? ')
# 		bday = input()
# 		birthdays[name] = bday
# 		print('Birthday database updated.')
# 		print(birthdays)


# 5.1.2 keys()、values()和items()方法
# 分别对应字典的键、值和键-值对
# spam = {'color': 'red', 'age': 42}
# for v in spam.values():
# 	print(v)

# print()
# for k in spam.keys():
# 	print(k)

# print()
# for i in spam.items():
# 	print(i)

# print()
# print(spam.keys())
# print(list(spam.keys()))

# print()
# for k, v in spam.items():
# 	print('Key: ' + k.title() + ' Value: ' + str(v))

# 5.1.3 检查字典中是否存在键或值
# in not in
# spam3 = {'name': 'Zophie', 'age': 7}
# print('name' in spam3.keys())
# print('Zophie' in spam3.values())
# print('color' in spam3.keys())
# print('color' not in spam3.keys())

# 5.1.4 get()方法
# 有两个参数，如果该键不存在时，返回备用值
picnicItems = {'apples': 5, 'cups': 2}
print('I am bringing ' + str(picnicItems.get('cups', 0)) + ' cups.')
print('I am bringing ' + str(picnicItems.get('eggs', 0)) +' eggs.')

print()
# 5.1.5 setdefault()方法
spam5 = {'name': 'Pooka', 'age': 5}
# if 'color' not in spam5:
# 	spam5['color'] = 'black'
# 	print(spam5)

# setdefault()方法：如果该键不存在时设置新值
print(spam5.setdefault('color', 'break'))
print(spam5.setdefault('color', 'white'))
print()

# 计算字符串中每个字符出现的次数
message = 'It was a bright cold day in April, and the clocks were striking thirteen.'
count = {}
for character in message:
	count.setdefault(character, 0)
	count[character] = count[character] + 1
print(count)