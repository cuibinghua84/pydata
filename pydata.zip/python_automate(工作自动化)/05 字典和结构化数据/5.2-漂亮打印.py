# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:13
# 文件      : 5.2-漂亮打印.py
# IDE       : PyCharm

import pprint

# 利用函数pprint()
# 计算字符串中每个字符出现的次数
message = 'It was a bright cold day in April, and the clocks were striking thirteen.'
count = {}
for character in message:
	count.setdefault(character, 0)
	count[character] = count[character] + 1
# print(count)
pprint.pprint(count)

