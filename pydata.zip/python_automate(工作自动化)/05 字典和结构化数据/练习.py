# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 练习.py
@time: 2018/6/14 10:27
"""

# 字典方法
# keys() 迭代键

# values() 迭代值

# items() 迭代所有

# spam = {'color': 'red', 'age': 35}
# for v in spam.values():
#     print(v)
#
# for v in spam.keys():
#     print(v)
#
# for v in spam.items():
#     print(v)

# for k, v in spam.items():
#     print('Key: ' + k + ',' + ' Value: ' + str(v))

# 检查字典中是否存在键或值
# spam = {'name': 'Zophie', 'age': 35}
# print('name' in spam.keys())
# print('Zophie' in spam.values())

# get()方法：检查键是否存在字典中
# picnicItems = {'apples': 5, 'cups': 2}
# print('I am bringing ' + str(picnicItems.get('cups', 0)) + ' cups.')

# setdefault()方法：
spam = {'name': 'Pooka', 'age': 35}

# if 'color' not in spam:
#     spam['color'] = 'black'
# print(spam)

# 不存在
spam.setdefault('color', 'black')
print(spam)
# 存在
spam.setdefault('age', 36)
print(spam)