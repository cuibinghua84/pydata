# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 2-characterCount.py
@time: 2018/6/14 11:19
"""

message = 'It was a bright cold day in April, and the clocks were striking thirteen.'
count = {}

for character in message:
    count.setdefault(character, 0)
    count[character] = count[character] + 1

print(count)