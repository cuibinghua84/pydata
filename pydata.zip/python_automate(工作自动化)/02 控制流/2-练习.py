# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 2-练习.py
@time: 2018/6/8 16:11
"""

# if else练习
# name = "dongfeng"
# password = 'cbh'
#
# if name == 'dongfeng':
#     print('Hello ' + name)
# if password == 'cbh':
#     print('Access granted.')
# else:
#     print('Worong pasword')

# while练习
# spam = 2
# if spam < 5:
#     print('Hello, world')
#     print(spam)
#     spam = spam + 1
#
# print('*' * 30)
#
# spam1 = 0
# while spam1 < 5:
#     print('Hello, world.')
#     spam1 = spam1 + 1

# for i in range(12, 16):
for i in range(0, 10, 2):
    print(i)

for i in range(5, -1, -1):
    print(i)