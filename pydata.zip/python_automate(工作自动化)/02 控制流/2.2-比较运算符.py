# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:06
# 文件      : 2.2-比较运算符.py
# IDE       : PyCharm

"""
==  等于
!=  不等于
<   小于
>   大于
<=  小于等于
>=  大于等于
"""
print(42 == 42)
print(42 == 99)
print(2 != 3)
print(2 != 2)
print('hello' == 'hello')
print('dog' != 'cat')
print(True != False)
print(42 == 42.0)
print(42 < 100)
print(42 > 100)
