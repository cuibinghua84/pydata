# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 1-章节目录.py
@time: 2018/6/7 17:16
"""

"""
2.1 布尔值
    True False
    
2.2 比较操作符
    ==  等于
    !=  不等于
    <   小于
    >   大于
    <=  小于等于
    >=  大于等于

2.3 布尔操作符
    and or:二元操作符
    not
    
    真值表
    True and True   True
    True and False  False
    False and True  False
    False and False False
    
    True or True    True
    True or False   True
    False or 
    True   True
    False or False  False
    
    not True    False
    not False   True
    

2.4 混合布尔和比较操作符
    

2.5 控制流的元素

2.6 程序执行

2.7 控制流语句

2.8 导入模块

2.9 用sys.exit()提前结束程序

2.10 小结

2.11 习题
"""