# -*- coding: utf-8 -*-
"""
@author: 东风
@file: swordfish.py
@time: 2018/6/11 10:41
"""
while True:
    print('Who are you?')
    name = input()
    if name != 'Joe':
        continue
    print('Hello, Joe. What is the password?(It is a fish.)')
    password = input()
    if password.lower() == 'abc':
        break
print('Access granted.')