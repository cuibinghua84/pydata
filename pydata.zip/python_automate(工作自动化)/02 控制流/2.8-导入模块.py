# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:07
# 文件      : 2.8-导入模块.py
# IDE       : PyCharm


import random
for i in range(5):
	print(random.randint(1, 10))

