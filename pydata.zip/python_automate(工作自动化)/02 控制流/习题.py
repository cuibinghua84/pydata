# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 习题.py
@time: 2018/6/11 11:09
"""

'''
1、True False
2、and or not
3、True False
6、> < = >= <= !=
'''
# print((5 > 4) and (3 == 5))  # False
# print(not (5 > 4))  # False
# print((5 > 4) or (3 == 5))  # True
# print(not ((5 > 4) or (3 == 5)))  # False
# print((True and True) and (True == False))  # Flase
# print((not False) or (not True))  # True

# spam = 4
# if spam == 1:
#     print('Hello')
# elif spam == 2:
#     print('Howdy')
# else:
#     print('Greetings!')

# break中断程序，continue跳到程序开始

# for i in range(10):
# for i in range(0, 10):
# for i in range(0, 10, 1):
#     print(i)

# for i in range(1,11):
#     print(i)
#
# i = 1
# while i < 11:
#     print(i)
#     i = i + 1