# -*- coding: utf-8 -*-
"""
@author: 东风
@file: printRandom.py
@time: 2018/6/11 11:04
"""

import random
for i in range(5):
    print(random.randint(1, 10))