# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:07
# 文件      : 2.7-控制流语句.py
# IDE       : PyCharm

# 2.7.1 if语句
# 如果条件我真，执行字句中的代码

# 2.7.2 else语句
# 如果条件为真，执行这段代码，否则，执行那段代码

# 2.7.3 elif语句
# 否则如果

# 2.7.4 while循环语句
# 利用while可以让一个代码块一遍又一遍的执行
# spam = 0
# if spam < 5:
# 	print('Hello, world.')
# 	spam += 1

# print("*" * 15)

# spam1 = 0
# while spam1 < 5:
# 	print('Hello, world.')
# 	spam1 += 1

# 2.7.5 烦人的循环
# name = ''
# while name != 'your name':
# 	print('Please type your name.')
# 	name = input()
# 	if name == 'q':
# 		break
# print('Thank you!')

# 2.7.6 break语句
# while True:
# 	print('Please type your name.')
# 	name = input()
# 	if name == 'your name':
# 		break
# print('Thank you!')

# 2.7.7 continue语句
# while True:
# 	print('Who are you? ')
# 	name = input()
# 	if name != 'Joe':
# 		continue
# 	print('Hello, Joe, What is the password? (It is a fish.)')
# 	password = input()
# 	if password == 'swordfish':
# 		break
# print('Access granted.')

# 2.7.8 for循环和range()函数
print('My name is')
for i in range(5):
    print('Jimmy Five Times (' + str(i) + ')')

print()

total = 0 
for num in range(101):
	total = total + num
print(total)


# 2.7.9 等价的while循环
print()
print('My name is')
i = 0
while i < 5:
	print('Jimmy Five Times (' + str(i) + ')')
	i = i + 1

# 2.7.10 range()的开始、停止和步长参数
print()
for i in range(12, 16):
	print(i)

print()
for i in range(0, 10, 2):
	print(i)

