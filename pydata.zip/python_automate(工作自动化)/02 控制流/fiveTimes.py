# -*- coding: utf-8 -*-
"""
@author: 东风
@file: fiveTimes.py
@time: 2018/6/11 10:59
"""

print('My name is')
for i in range(5):
    print('Jimmy Five Times (' + str(i) + ')')


total = 0
for num in range(101):
    total = num + total
print(total)