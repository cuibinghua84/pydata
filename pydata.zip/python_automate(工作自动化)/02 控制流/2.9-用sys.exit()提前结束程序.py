# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:08
# 文件      : 2.9-用sys.exit()提前结束程序.py
# IDE       : PyCharm

import sys

while True:
	print('Type exit to exit.')
	response = input()
	if response == 'exit':
		sys.exit()
	print('You typed ' + response + '.')