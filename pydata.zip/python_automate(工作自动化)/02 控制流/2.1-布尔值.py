# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:05
# 文件      : 2.1-布尔值.py
# IDE       : PyCharm

# True和False 首字母大写
spam = True
print(spam)
