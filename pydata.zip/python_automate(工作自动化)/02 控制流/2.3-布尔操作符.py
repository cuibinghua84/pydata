# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:06
# 文件      : 2.3-布尔操作符.py
# IDE       : PyCharm

# and、or、not
print(True and True)
print(True and False)

"""
and操作符的真值表
True and True	True
True and False	False
False and True	False
False and False	False

or操作符真值表
True or True 	True
True or False 	True
False or False 	False
False or Trrue 	True

not操作符的真值表
not True 	False
not False 	True
"""