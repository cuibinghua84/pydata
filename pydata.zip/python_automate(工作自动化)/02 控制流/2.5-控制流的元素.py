# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:06
# 文件      : 2.5-控制流的元素.py
# IDE       : PyCharm

name = 'Mary'
password = 'swordfish'

if name == 'Mary':
	print("Hello Mary")
if password == 'swordfish':
	print('Access granted.')
else:
	print('Wrong password.')
