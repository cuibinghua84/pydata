# -*- coding: utf-8 -*-
"""
@author: 东风
@file: fiveTimes.py
@time: 2018/6/11 10:59
"""

print('My name is')
for i in range(5):
    print('Jimmy Five Times (' + str(i) + ')')


print('My name is')
i = 0
while i < 5:
    print('Jimmy Five Times (' + str(i) + ')')
    i = i + 1