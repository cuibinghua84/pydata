# -*- coding: utf-8 -*-
"""
@author: 东风
@file: exitExample.py
@time: 2018/6/11 11:06
"""

import sys

while True:
    print('Type exit to exit.')
    response = input()
    if response == 'exit':
        sys.exit()
    print('You typed ' + response + '.')