# -*- coding: utf-8 -*-
"""
@author: 东风
@file: yourName.py
@time: 2018/6/8 17:11
"""

name = ''
while name != 'your name':
    print('Please type your name.')
    name = input()
print('Thank you')