# -*- coding: utf-8 -*-
"""
@author: 东风
@file: vampire.py
@time: 2018/6/8 16:32
"""

name = 'Alice1'
age = 3000

if name == 'Alice':
    print('Hi, ' + name)
elif age < 12:
    print('Your are not Alice, kiddo.')
elif age > 2000:
    print('Unlike you, Alice is not an undead, immortal vampire.')
elif age > 100:
    print('Your are not Alice, grannice')