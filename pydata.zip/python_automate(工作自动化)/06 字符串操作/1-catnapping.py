# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 1-catnapping.py
@time: 2018/6/14 15:51
"""
# 三重引号
print('''Dear Alice,
Eve's cat has been arrested for catnapping, cat burglary, and extortion.
Sincerely,
Bob''')