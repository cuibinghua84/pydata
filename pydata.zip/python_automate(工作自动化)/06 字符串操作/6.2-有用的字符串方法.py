# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:14
# 文件      : 6.2-有用的字符串方法.py
# IDE       : PyCharm


# 6.2.1 字符串方法upper() lower() isupper() islower()
# spam1 = 'Hello world!'
# spam1 = spam1.upper()
# print(spam1)
# spam1 = spam1.lower()
# print(spam1)

# 忽略大小写
# print()
# print('How are you?')
# feeling = input()
# if feeling.lower() == 'great':
# 	print('I feel great too.')
# else:
# 	print('I hope the rest of your day is good.')

spam = 'Hello world!'
# print(spam.islower())
# print(spam.isupper())
# print('HELLO'.isupper())
# print('abc12345'.islower())
# print('12345'.islower())
# print('12345'.isupper())

# print('Hello'.upper()) # 全部大写
# print('Hello'.lower()) # 全部小写
# print('Hello'.upper().lower())
# print('Hello'.upper().lower().upper())
# print('HELLO'.lower())
# print('HELLO'.lower().islower())


# 6.2.2 isX字符串方法
"""
islower()：是否全部小学
isupper()：是否全部大学
isalpha()：返回True，如果字符串只包含字母，并且非空
isalnum()：返回True，如果字符串只包含字母和数字，并且非空
isdecimal()：返回True，如果字符串只包含数字字符，并且非空
isspace()：返回True，如果字符串只包含空格、制表符和换行，并且非空
istitle()：返回True，如果字符串仅包含大写字母开头、后面都是小写字母的单词

"""
# print('HELLO'.islower())
# print('HELLO'.isupper())
# print('HELLO'.isalpha())
# print('cui123'.isalnum())
# print('12342'.isdecimal())
# print('  \t \n'.isspace())
# print('Cuiasdas'.istitle())


# 验证用户输入
# while True:
# 	print('Enter your age: ')
# 	age = input()
# 	if age.isdecimal():
# 		break
# 	print('Please enter a number for your age.')

# while True:
# 	print('Select a new password (letters and numbers only): ')
# 	password = input()
# 	if password.isalnum():
# 		break
# 	print('Passwords can only have letters and numbers.')



# 6.2.3 字符串方法startswith()和endswitch()
# 以字符串开始或结束
print('Hello world!'.startswith('Hello'))
print('Hello, world'.endswith('rld'))


# 6.2.4 字符串方法join()和split()：连接和拆分
print(', '.join(['cats', 'rats', 'bats']))
print(' '.join(['cats', 'rats', 'bats']))

print('My name is, Simon'.split(','))


# 6.2.5 用rjust() ljust() center()方法对齐文本
# 6.3.6 用strip() rstrip() lstrip()删除空白字符


# 6.3.7 用pyperclip模块拷贝粘贴字符串
