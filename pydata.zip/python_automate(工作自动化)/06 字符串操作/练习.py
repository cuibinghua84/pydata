# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 练习.py
@time: 2018/6/14 15:47
"""

# 转移字符
"""
转义字符            打印为
\'                  单引号
\"                  双引号
\t                  制表符
\n                  换行符
\\                  倒斜杠
"""
# print("Hello there!\nHow are you?\nI\'m doing \tfine \\ok.")

# 原始字符串
# print('That is Carol\'s cat.')
# print(r'That is Carol\'s cat.')

# 多行注释

# 字符串下标和切片

# 字符串的in和not in 操作符

# 字符串方法
# upper() lower() isupper() islower() 将原字符串的所有字母转换为大写或小写
# spam = 'Hello world!'
# print(spam.upper()) # 大写
# print(spam)
# print(spam.lower()) # 小写
# print(spam)

# 忽略字符串大小写的比较
# print('How are you?')
# feeling = input()
# if feeling.lower() == 'great':
#     print('I feel great too.')
# else:
#     print('I hope the rest of your day is good.')

# 至少有一个字母，并且所有字母都是大写或小写
# spam = 'Hello world!'
# print(spam.islower())
# print(spam.isupper())
# print('HELLO'.isupper())
# print('abc12345'.islower())

# isX字符串方法
# str = ''
# str.isalpha() # 返回True 如果字符串只包含字母，并且非空
# print('abadd'.isalpha())

# str.isalnum()# 返回True  如果字符串只包含字母和数字，并且非空
# print('a1aaba33'.isalnum())

# str.isdecimal()# 返回True 如果字符串只包含数字字符，并且非空
# print('1111'.isdecimal())

# str.isspace()# 返回True 如果字符串只包含空格 制表符和换行，并且非空
# print(' \t  '.isspace())

# str.istitle() # 返回True 如果字符串仅包含以大写字母开头、后面都是小写字母的单词
# print('CuibinghuaQ'.istitle())

# startswith() endswith() 字符串以什么开始或结束

# join() 连接字符串
# split() 拆分字符串
# rjust() ljust() center() 对齐方式 以空格或指定字符填充
# strip() rstrip() lstrip() 删除空白字符


# pyperclip模块
import pyperclip
pyperclip.copy('Hello world!')
pyperclip.paste()