# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:14
# 文件      : 6.1-处理字符串.py
# IDE       : PyCharm


# 6.1.1 字符串字面量
# 6.1.2 双引号
# 6.1.3 转义字符
"""
\'	单引号
\"	双引号
\t	制表符
\n	换行符
\\	倒斜杠
"""
# print("Hello there!\n\tHow are you?\n\tI\'m doing fine.")


# 6.1.4 原始字符串
# print('That is Carol\'s cat.')
# print(r'That is Carol\'s cat.')

# 6.1.5 用三重引号的多行字符串
# print('''Dear Alice,
# Eve's cat has been arrested for catnapping, cat burglary, and extortion.
# Sincerely,
# Bob''')

# print('Dear Alice,\n\nEve\'s cat has been arrested for catnapping, cat burglary, and extortion.\n\nSincerely, \nBob')

# 6.1.6 多行注释
# 6.1.7 字符串下标和切片
spam = 'Hello world!'
print(spam[0])
print(spam[4])
print(spam[-1])
print(spam[0:5])
print(spam[:5])
print(spam[6:])

# 6.1.8 字符串的in和not in操作符
print('Hello' in 'Hello World!')
print('Hello' in 'Hello')
print('HELLO' in 'Hello World')
print('' in 'spam')
print('cats' not in 'cats and dogs')

