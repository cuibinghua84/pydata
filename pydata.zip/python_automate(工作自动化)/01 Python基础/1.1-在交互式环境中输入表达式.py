# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 10:10
# 文件      : 1.1-在交互式环境中输入表达式.py
# IDE       : PyCharm

"""
数学操作符，优先级从高到低
**  指数
%   取模/取余数
//  整除/商数取整
/   除法
*   乘法
-   减法
+   加法
"""
print(2 ** 3)
print(22 % 8)
print(22 // 8)
print(22 / 8)
print(3 * 5)
print(5 - 2)
print(2 + 2)
