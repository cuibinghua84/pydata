# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 10:30
# 文件      : 1.3-字符串连接和复制.py
# IDE       : PyCharm

print('Alice' + 'Bob')
print('Alice' * 5)