# -*- coding: utf-8 -*-
"""
@author: 东风
@file: hello.py
@time: 2018/6/7 17:09
"""

# print("Hello world!")
# print("What is your name?")
# myName = input()
# print("It is good to meet you, " + myName)
# print("The length of your name is: ")
# print(len(myName))
# print("What si your age? ")
# myAge = input()
# print("You will be " + str(int(myAge) + 1) + " in a year.")

"""
print()函数：将字符串显示在屏幕上
input()函数：等待用户在键盘上输入一些文本
len()函数：求值字符串的字符个数，返回整型值
str() int() float()函数：转换函数
"""
print(type(36))
print(type(str(36)))
print(type(float(36)))