# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 10:35
# 文件      : 1.5-第一个程序.py
# IDE       : PyCharm

print("Hello world!")
print('What is your name?')
myName = input() # 等待用户在键盘上输入一些文本
print('It is good t meet you, ' + myName)
print('The length of your name is:')
print(len(myName)) # 求值字符串的个数
print('What is your age?')
myAge = input()
print('You will be ' + str(int(myAge) + 1) + ' in a year.') # str() int() float() 转换函数

