# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 3-myPets.py
@time: 2018/6/13 16:15
"""

myPets = ['Zophie', 'Pooka', 'Fat-tail']
print('Enter a pet name: ')
name = input()
if name not in myPets:
    print('I do not have a pet named ' + name)
else:
    print(name + ' is my pet.')