# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 5-passingReference.py
@time: 2018/6/13 17:53
"""


def eggs(someParameter):
    someParameter.append('Hello')


spam = [1, 2, 3]
eggs(spam)
print(spam)
