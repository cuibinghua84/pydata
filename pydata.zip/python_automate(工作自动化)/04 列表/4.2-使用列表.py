# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:11
# 文件      : 4.2-使用列表.py
# IDE       : PyCharm

# catNames = []
# while True:
# 	print('Enter the name of cat ' + str(len(catNames) + 1) + ' (Or enter nothing to stop.):')
# 	name = input()
# 	if name == '':
# 		break
# 	catNames = catNames + [name]
# print('The cat names are: ')
# for name in catNames:
# 	print(' ' + name)


# 4.2.1 列表用于循环
# for i in range(4):
# 	print(i)

# supplies = ['pens', 'staplers', 'flame-throwers', 'binders']
# for i in range(len(supplies)):
# 	print('Index ' + str(i) + ' in supplies is: ' + supplies[i])


# 4.2.2 in和not in操作符
# print('howdy' in ['hello', 'hi', 'howdy', 'heyas'])
# spam = ['hello', 'hi', 'howdy', 'heyas']
# print('cat' in spam)
# print('howdy' not in spam)
# print('cat' not in spam)

# myPets = ['Zophie', 'Pooka', 'Fat-tail']
# print('Enter a pet name: ')
# name = input()
# if name not in myPets:
# 	print('I do not have a pet named ' + name)
# else:
# 	print(name + ' is my pet.')


# 4.2.3 多重赋值技巧
cat = ['fat', 'black', 'loud']
size, color, disposition = cat
print(cat)
print(size)
print(color)
print(disposition)
