# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 6-copy.py
@time: 2018/6/13 17:56
"""

import copy

spam = ['A', 'B', 'C', 'D']
cheese = copy.copy(spam)
cheese[1] = 42
print(spam)
print(cheese)

# deepcopy()函数同时复制它们内部的列表