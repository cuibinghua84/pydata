# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:11
# 文件      : 4.4-方法.py
# IDE       : PyCharm


# 4.4.1 用index()方法在列表中查找值
spam = ['hello', 'hi', 'howdy', 'heyas', 'hi']
# print(spam.index('hello'))
# print(spam.index('heyas'))
# print(spam.index('hi'))


# 4.4.2 用append()和insert()方法在列表中添加值
# append()将参数添加到列表末尾
# insert()将参数添加到列表的任意下标处
spam2 = ['cat', 'dog', 'bat']
spam2.append('moose')
# print(spam2)
spam2.insert(1, 'chicken')
# print(spam2)

# 4.4.3 用remove()方法从列表中删除值
spam3 = ['cat', 'bat', 'rat', 'elephant', 'bat']
spam3.remove('bat')
# print(spam3)

# 4.4.4 用sort()方法将列表中的值排序
"""
sort()方法当场对列表排序
不能对既有数字又有字符串值的列表排序
sort()方法对字符串排序时，使用"ASCII字符排序"，而不是实际的字典排序，即大小写字母排在小写字母前
"""

spam4 = [2, 5, 3.14, 1, -7]
spam4.sort()
# print(spam4)
spam5 = ['ants', 'cats', 'dogs', 'badgers', 'elephants']
# spam5.sort()
# print(spam5)

# 指定参数reverse=True，让sort()按逆序排序
spam5.sort(reverse=True)
# print(spam5)

spam6 = ['Alice', 'Bob', 'ants', 'badgers', 'Carol', 'cats']
spam6.sort()
# print(spam6)

# 如果需要按照普通的字典顺序来排序，在调用sort()时，将关键字参数key设置为str.lower
spam7 = ['a', 'z', 'A', 'Z']
spam7.sort(key=str.lower)
print(spam7)

