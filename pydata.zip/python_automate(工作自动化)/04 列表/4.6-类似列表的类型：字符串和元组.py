# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:12
# 文件      : 4.6-类似列表的类型：字符串和元组.py
# IDE       : PyCharm


# 4.6.1 可变和不可变数据类型
# 字符串操作：按下标取值、切片、用于for循环、用于len()，以及用于in和not in操作符
name = 'Zophie'
# print(name[0])
# print(name[-2])
# print(name[0:4])
# print('Zo' in name)
# print('z' in name)
# print('p' not in name)
# for i in name:
# 	print('* * * ' + i + ' * * *')

name1 = 'Zophie a cat'
newName = name1[0:7] + 'the' + name1[8:12]
# print(name1)
# print(newName)


# 4.6.2 元组数据类型
eggs = ('hello', 42, 0.5)
# print(eggs[0])
# print(eggs[1:3])
# print(len(eggs))


# 4.6.3 用list()he tuple()函数来转换类型
# 将返回传递给他们的值的列表和元组版本
print(tuple(['cat', 'dog', 5]))
print(list(('cat', 'dog', 5)))
print(list('hello'))




