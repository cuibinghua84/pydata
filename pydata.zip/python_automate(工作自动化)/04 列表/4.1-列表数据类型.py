# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:10
# 文件      : 4.1-列表数据类型.py
# IDE       : PyCharm


# 4.1.1 用下标取得列表中的单个值
spam = ['cat', 'bat', 'rat', 'elephant']
# print(spam[0])
# print(spam[1])
# print(spam[2])
# print(spam[3])
# print('Hello ' + spam[0])
# print('The ' + spam[1] + ' ate the ' + spam[0] + '.')

spam1 = [['cat', 'bat'], [10, 20, 30, 40, 50]]
# print(spam1[0])
# print(spam1[0][1])
# print(spam1[1])
# print(spam1[1][4])



# 4.1.2 负数下标
# print(spam)
# print(spam[-1])
# print(spam[-3])
# print('The ' + spam[-1] + ' is afraid of the ' + spam[-3] + '.')

# 4.1.3 利用切片取得子列表
# print(spam[0:4])
# print(spam[1:3])
# print(spam[0:-1])
# print(spam[:2])
# print(spam[1:])
# print(spam[:])

# 4.1.4 用len()取得列表的长度
# print(len(spam))
# print(len(spam1))

# 4.1.5 用下标改变列表中的值
# print(spam)
# spam[1] = 'aardvark'
# print(spam)
# spam[2] = spam[1]
# print(spam)
# spam[-1] = 12345
# print(spam)


# 4.1.6 列表连接和列表复制
# print([1, 2, 3] + ['A', 'B', 'C'])
# print(['X', 'Y', 'Z'] * 3)
# spam6 = [1, 2, 3]
# spam6 = spam6 + ['A', 'B', 'C']
# print(spam6)


# 4.1.7 用del语句从列表中删除值
print(spam)
del spam[3]
print(spam)
del spam[2]
print(spam)


