# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 2-allMyCats2.py
@time: 2018/6/13 16:00
"""

catNames = []
while True:
    print('Enter the name of cat ' + str(len(catNames) + 1) + ' (Or enter nothing to stop.):')
    name = input()
    if name == '':
        break
    catNames = catNames + [name]
print('The cat names are:')
for name in catNames:
    print(' ' + name)