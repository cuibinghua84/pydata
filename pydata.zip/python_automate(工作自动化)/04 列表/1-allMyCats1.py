# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 1-allMyCats1.py
@time: 2018/6/13 15:53
"""

print('Enter the name of cat 1:')
catName1 = input()

print('Enter the name of cat 2:')
catName2 = input()

print('Enter the name of cat 3:')
catName3 = input()

print('Enter the name of cat 4:')
catName4 = input()

print('Enter the name of cat 5:')
catName5 = input()

print('Enter the name of cat 6:')
catName6 = input()

print('The cat names are:')
# print(catName1 + ' ' + catName2 + ' ' + catName3 + ' ' + catName4 + ' ' + catName5 + ' ' + catName6)
print(catName1, catName2, catName3, catName4, catName5, catName6, sep=',')
