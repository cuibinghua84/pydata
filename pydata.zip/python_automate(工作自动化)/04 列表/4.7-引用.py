# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:12
# 文件      : 4.7-引用.py
# IDE       : PyCharm

# spam = 42 
# cheese = spam
# print(spam)
# print(cheese)
# spam = 100
# print(spam)
# print(cheese)


# spam = [0, 1, 2, 3, 4, 5]
# print(id(spam))
# cheese = spam
# print(id(cheese))

# cheese[1] = 'Hello!'
# print(spam)
# print(cheese)


# 4.7.1 传递引用
def eggs(someParameter):
	someParameter.append('Hello')

# spam = [1, 2, 3]
# eggs(spam)
# print(spam)


# 4.7.2 copy模块的copy()和deepcopy()函数
# copy.copy() 用来复制列表或字典的可变值
import copy

spam = ['A', 'B', 'C', 'D']
cheese = copy.copy(spam)
# cheese = spam
print(spam)
print(cheese)
cheese[1] = 42
print(spam)
print(cheese)


# 如果要复制的列表中包含了列表，使用copy.deepcopy()函数来代替，deepcopy()函数将同时复制他们内部的列表

