# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 练习.py
@time: 2018/6/13 15:44
"""

# spam = ['cat', 'bat', 'rat', 'elephant']
# print(spam[0])
# print(spam[-1])

# len()获取列表的长度
# print(len(spam))

# for i in range(4):
#     print(i)

# for i in range(len(spam)):
#     print('Index ' + str(i) + ' in spams is: ' +spam[i])

# 列表方法
# spam = ['hello', 'hi', 'howdy', 'heyas']

# index()在列表中查找值，返回下标
# print(spam.index('hi'))

#append() insert()向列表中添加值
# spam = ['cat', 'dog', 'bat']
# spam.append('moose')
# print(spam)
# spam.insert(1, 'chicken')
# print(spam)

# remove()从列表中删除值
# spam = ['cat', 'bat', 'rat', 'elephant', 'bat']
# spam.remove('bat')
# print(spam)

# sort()将列表中的值排序
# spam = [2, 5, 3.14, 1, -7]
# spam.sort()
# print(spam)
# spam = ['ants', 'cats', 'dogs', 'badgers', 'elephants']
# spam.sort(reverse=True)
# print(spam)

"""
可变  ：列表
不可变：字符串、元组
"""

# list()和tuple()函数进行转换

# compy模块的copy()和deepcopy()函数
