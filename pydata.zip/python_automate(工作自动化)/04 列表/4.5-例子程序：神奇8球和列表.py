# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:11
# 文件      : 4.5-例子程序：神奇8球和列表.py
# IDE       : PyCharm

# magic8Ball2.py

import random

messages = ['It is certain',
	'It is decidedly so',
	'Yes definitely',
	'Reply hazy try again',
	'Ask again later',
	'Concentrate and ask again',
	'My reply is no',
	'Outlook not so good',
	'Very doubtful']

print(messages[random.randint(0, len(messages) - 1)])