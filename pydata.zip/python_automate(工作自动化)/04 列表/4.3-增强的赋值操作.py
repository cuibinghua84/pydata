# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:11
# 文件      : 4.3-增强的赋值操作.py
# IDE       : PyCharm

# spam = 42
# spam = spam + 1
# print(spam)

"""
spam += 1
spam -= 1
spam *= 1
spam /= 1
spam %= 1

"""

spam = 'Hello'
spam += ' world!'
print(spam)
bacon = ['Zophie']
bacon *= 3
print(bacon)

