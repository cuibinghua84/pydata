# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/25 17:21
# 文件      : 7.11-不区分大小写的匹配.py
# IDE       : PyCharm

import re

# 正则表达式不区分大小写：向re.compile()传入re.IGNORECASE或re.I 作为第二个参数
robocop = re.compile(r'robocop', re.I)
print(robocop.search('RoboCop is part man, part machine, all cop.').group())
print(robocop.search('ROBOCOP protects the innocent.').group())
print(robocop.search('Al, why does your programming book talk about robocop so much?').group())

