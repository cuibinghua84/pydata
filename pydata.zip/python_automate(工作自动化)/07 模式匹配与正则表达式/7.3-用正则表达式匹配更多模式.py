import re
# 7.3.1 利用括号分组

# phoneNumRegex = re.compile(r'(\d\d\d)-(\d\d\d-\d\d\d\d)')
# mo = phoneNumRegex.search('My number is 415-555-4242.')
# print(mo.group(1))
# print(mo.group(2))
# print(mo.group(0))
# print(mo.group())

# groups()方法：一次获取所有的分组
# print(mo.groups())

# areaCode, mainNumber = mo.groups()
# print(areaCode)
# print(mainNumber)

# 7.3.2 用管道（|）匹配多个分组，如果需要匹配真正的管道字符，就用倒斜杠转义，即\|
# heroRegex = re.compile(r'Batman|Tina Fey')
# mo1 = heroRegex.search('Batman and Tina Fey.')
# print(mo1.group())/

# mo2 = heroRegex.search('Tina Fey and Batman.')
# print(mo2.group())

# 匹配任意一个
# batRegex = re.compile(r'Bat(man|mobile|copter|bat)')
# mo = batRegex.search('Batmobile lost a wheel ')
# print(mo.group())
# print(mo.group(1))

# 7.3.3 用问号实现可选匹配
# batRegex = re.compile(r'Bat(wo)?man')
# mo1 = batRegex.search('The Adventures of Batman')
# print(mo1.group())

# phoneNumRegex = re.compile(r'(\d\d\d-)?\d\d\d-\d\d\d\d')
# mo1 = phoneNumRegex.search('My number is 415-555-4242')
# print(mo1.group())

# mo2 = phoneNumRegex.search('My number is 555-4242')
# print(mo2.group())

# 7.3.4 用星号匹配零次或多次
# * 意味着“匹配零次或多次”，即星号之前的分组，可以在文本中出现任意次，可以完全不存在，或一次又一次地重复
# batRegex = re.compile(r'Bat(wo)*man')
# mo1 = batRegex.search('The Adventures of Batman')
# print(mo1.group())

# mo2 = batRegex.search('The Adventures of Batwoman')
# print(mo2.group())

# mo3 = batRegex.search('The Adventures of Batwowowowoman')
# print(mo3.group())

# 7.3.5 用加号匹配一次或多次
# * 意味着“匹配零次或多次” + 意味着“匹配一次或多次”
# batRegex = re.compile(r'Bat(wo)+man')
# mo1 = batRegex.search('The Adventures of Batwoman')
# print(mo1.group())

# mo2 = batRegex.search('Teh Adventures of Batwowowowoman')
# print(mo2.group())

# mo3 = batRegex.search('The Adventures of Batman')
# print(mo3 == None)

# 7.3.6 用花括号匹配特定次数
# 在正则表达式分组的后面，跟上花括号包围的数字，还可以指定一个范围，即在花括号中写下一个最小值、一个逗号和一个最大值
haRegex = re.compile(r'(Ha){3}')
mo1 = haRegex.search('HaHaHa')
print(mo1.group())

mo2 = haRegex.search('Ha')
print(mo2 == None)