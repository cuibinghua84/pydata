import re

# 匹配所有元音字母
vowelRegex = re.compile(r'[aeiouAEIOU]')
print(vowelRegex.findall('RoboCop eats baby food. BABY FOOD'))
# print(vowelRegex.search('RoboCop eats baby food. BABY FOOD'))

# 匹配所有非元音字母
vowelRegex1 = re.compile(r'[^aeiouAEIOU]')
print(vowelRegex1.findall('RoboCop eats baby food. BABY FOOD'))