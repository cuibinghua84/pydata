import re

# .(句点)称为“通配符”,句点只匹配一个字符
# atRegex = re.compile(r'.at')
# print(atRegex.findall('The cat  in the hat sat on the flat mat.'))

# 7.9.1 用点-星匹配所有字符：.*，使用“贪心”模式，总是匹配尽可能多的文本
# nameRegex = re.compile(r'First Name:(.*) Last Name:(.*)')
# mo = nameRegex.search('First Name: Al Last Name: Sweigart')
# print(mo.group(1))
# print(mo.group(2))
# print(mo.group(0))

# 贪心模式和非贪心模式的区别
nongreedyRegex = re.compile(r'<.*?>')
mo = nongreedyRegex.search('<To serve man>for dinner.>')
# print(mo.group())

greedyRegex = re.compile(r'<.*>')
mo1 = greedyRegex.search('<To serve man>for dinner.>')
# print(mo1.group())

# 7.9.2 用句点字符匹配换行
# 通过传入re.DOTALL作为re.compile()的第二个参数，可以让句点字符匹配所有字符，包括换行字符
noNewlineRegex = re.compile('.*')
print(noNewlineRegex.search('Serve the public trust.\nProtect the innocent.'
                            '\nUphold the law.').group())
newlineRegex = re.compile('.*', re.DOTALL)
print(newlineRegex.search('Serve the public trust. \nProtect the inncent.'
                          '\nUphold the law.').group())
