"""
^：表明匹配必须发生在被查找文本开始处
$：表示该字符串必须以这个正则表达式的模式结束
同时使用……和$，表明整个字符串必须匹配该模式，也就是说只匹配该字符串的某个子集是不够的
"""

import re

# 正则表达式r^Hello匹配以'Hello'开始的字符串
beginsWithHello = re.compile(r'^Hello')
print(beginsWithHello.search('Hello world!'))
print(beginsWithHello.search('He said hello.') == None)

# r'\d$' 匹配以数字0到9结束的字符串
endsWithNumber = re.compile(r'\d$')
print(endsWithNumber.search('Your number is 36'))
print(endsWithNumber.search('Your number is forty two.') == None)

# 正则表达式r'^\d+$'匹配从开始到结束都是数字的字符串
wholeStringIsNum = re.compile(r'^\d+$')
print(wholeStringIsNum.search('1234567890'))
print(wholeStringIsNum.search('12345xyz132320') == None)
print(wholeStringIsNum.search('12  adasd121122') == None)