# -*- coding: utf-8 -*-
# 作者      : p_bhcui
# 创建时间  : 2019/6/25 23:03
# 项目名称  : py
# 文件      : 7.12-用sub()方法替换字符串.py
# IDE       : PyCharm

import re

"""
正则表达式不仅能找到文本模式，而且能够用新的文本替换掉这些模式
sub()方法需要传入两个参数：第一个参数是字符串，用于取代发现的匹配；第二个参数是一个字符串，即正则表达式。
"""
namesRegex = re.compile(r'Agent \w+')
print(namesRegex.sub('CENSORED', 'Agent Alice gave the secret documents to Agent Bob.'))

agentNameRegex = re.compile(r'Agent (\w)\w*')
print(agentNameRegex.sub(r'\1****', 'Agent Alice told Agent Carol that Agent Eve knew Agent Bob was a double agent.'))


