# Python的正则表达式默认是“贪心”的，表示在有二义的情况下，尽可能匹配最长的字符串
# 花括号的“非贪心”匹配尽可能最短的字符串，即在结束的花括号后跟着一个问号
# 问号在正则表达式中可能有两种含义：声明非贪心匹配或表示可选的分组

import re

greedyHaRegex = re.compile(r'(Ha){3,5}')
mo1 = greedyHaRegex.search('HaHaHaHaHa')
print(mo1.group())

nongreedyHaRegex = re.compile(r'(Ha){3,5}?')
mo2 = nongreedyHaRegex.search('HaHaHaHaHa')
print(mo2.group())