import re

# search()将返回一个Match对象，包含被查找字符串中的“第一次”匹配的文本
# findall()方法将返回一组字符串，包含被查找字符串中的所有匹配

phoneNumRegex = re.compile(r'\d\d\d-\d\d\d-\d\d\d\d')
mo = phoneNumRegex.search('Cell: 415-555-9999 Work: 212-555-0000')
print(mo.group())

print(phoneNumRegex.findall('Cell: 415-555-9999 Work: 212-555-0000'))

phoneNumRegex = re.compile(r'(\d\d\d)-(\d\d\d)-(\d\d\d\d)')
print(phoneNumRegex.findall('Cell: 415-555-9999 Work: 212-555-0000'))

# 1. 如果调用在一个没有分组的正则表达式上，方法findall()将返回一个匹配字符串的列表
# 2. 如果调用在一个有分组的正则表达式上，方法findall()将返回一个字符串的元组列表