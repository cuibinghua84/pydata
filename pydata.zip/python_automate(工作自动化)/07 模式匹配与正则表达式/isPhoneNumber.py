# 不用正则表达式来查找文本模式 isPhoneNumber
def isPhoneNumber(text):
	# 检查带是否有12个字符
    if len(text) != 12:
        return False

    # 检查区号是否包含数字
    for i in range(0, 3):
        if not text[i].isdecimal():
            return False
    # 检查该字符串是否符合电话号码的模式，号码必须在区号出现抵押给横短线
    if text[3] != '-':
        return False
    # 3个数字
    for i in range(4, 7):
        if not text[i].isdecimal():
            return False
    # 检查横短线
    if text[7] != '-':
        return False
    # 最后是4个数字
    for i in range(8, 12):
        if not text[i].isdecimal():
            return False
    return True

print('415-555-4242 is a phone number: ')
print(isPhoneNumber('415-555-4242'))
print('Moshi moshi is a phone number: ')
print(isPhoneNumber('Moshi moshi'))

print("*" * 20)
message = 'Call me at 415-555-1011 tomorrow. 415-555-999 is my office'
for i in range(len(message)):
	chunk = message[i:i+12]
	if isPhoneNumber(chunk):
		print('Phone number found: ' + chunk)
print('Done')