"""
\d：表示一位数字字符（0-9）

"""

# 所有正则表达式的函数都在模块re中
import re

# re.compile()传入要给字符串值，表示正则表达式，返回一个Regex模式对象
phoneNumRegex = re.compile(r'\d\d\d-\d\d\d-\d\d\d\d')

# search()方法查找传入的字符串，寻找该正则表达式的所有匹配，返回Match对象
# Match对象的group()方法，返回被查找字符串中实际匹配的文本
mo = phoneNumRegex.search('My number is 415-555-4242.')
print('Phone number found: ' + mo.group())

"""
正则表达式查找留存
1、用import re导入正则表达式模块
2、re.compile()函数创建一个Regex对象（记得使用原始字符串）
3、Regex对象的search()方法传入想查找的字符串。它返回一个Math从对象
4、调用Match对象的group()方法，返回实际匹配文本的字符串
"""