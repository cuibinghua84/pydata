# -*- coding: utf-8 -*-
"""
@author: 东风
@file: passwordFile.py
@time: 2018/6/7 10:52
"""
#  打开文件
passwordFile = open('SecretPasswordFile.txt')
# 读取密码
secretPassword = passwordFile.read()
# 提示用户输入密码
print('Enter your password.')
typedPassword = input()
# 比较密码
if typedPassword == secretPassword:
    # 如果密码一致，打印以下内容
    print("Access granted")
    # 如果密码是12345，提示密码过于简单
    if typedPassword == "12345":
        print("That password is one that an idiot puts on their luggage")
else:
    print("Access denied")
