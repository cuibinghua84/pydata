# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 3-章节目录.py
@time: 2018/6/11 13:31
"""

'''
3.1 def语句和函数

3.2 返回值和return语句

3.3 None值

3.4 关键字参数和print()

3.5 局部和全局作用域

3.6 global语句

3.7 异常处理

3.8 一个小程序：猜数字

3.9 小结

3.10 习题

3.11 实践项目
'''

print('Hello', end='')
print('World')