# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:09
# 文件      : 3.5-局部和全局作用域.py
# IDE       : PyCharm

"""
概念
在被调用函数内赋值的变元和变量，处于该函数的“局部作用域”——局部变量
在所有函数之外赋值的变量，属于“全局作用域”——全局变量

作用
全局作用域中的代码不能使用任何局部变量
但是，局部作用域可以访问全局变量
一个函数的局部作用域中的代码，不能使用其他局部作用域中的变量
如果在不同的作用域中，你可以用相同的名字命名不同的变量
"""

# 3.5.1 局部变量不能再全局作用域内使用
def spam():
	eggs = 31337
spam()
# print(eggs) # eggs已经被销毁了

# 3.5.2 局部作用域不能使用其他局部作用域内的变量
def spam1():
	eggs = 99
	bacon()
	print(eggs)

def bacon():
	ham = 101
	eggs = 0

# spam1()

# 3.5.3 全局变量可以在局部作用域中读取
def spam3():
	print(eggs)
# eggs = 36
# spam3()
# print(eggs)

# 3.5.4 名称相同的局部变量和全局变量
def spam4():
	eggs = 'spam local'
	print(eggs)

def bacon1():
	eggs = 'bacon1 local'
	print(eggs) # bacon1 local
	spam4()		# spam local
	print(eggs)	# bacon1 local'

eggs = 'global'
bacon1()
