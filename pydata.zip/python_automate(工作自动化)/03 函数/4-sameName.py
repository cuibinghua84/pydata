# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 4-sameName.py
@time: 2018/6/12 4:02
"""

# def spam():
#     eggs = 'spam local'
#     print(eggs)
#
# def bacon():
#     eggs = 'bacon local'
#     print(eggs)
#     spam()
#     print(eggs)
#
# eggs = 'global'
# bacon()
# print(eggs)

