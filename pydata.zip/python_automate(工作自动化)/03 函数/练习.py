# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 练习.py
@time: 2018/6/11 17:58
"""

# print()函数有可选的变元end和sep
# print('Hello ', end='')
# print('World')
#
# print('cats', 'dogs', 'mice', sep=',')

# 作用域
# def spam():
#     eggs = 31337
#
# spam()
# print(eggs)

# def spam():
#     eggs = 99
#     bacon()
#     print(eggs)
#
# def bacon():
#     ham = 101
#     eggs = 0
#     print(ham)
#
# spam()


def spam():
    print(eggs)
eggs = 42
spam()
print(eggs)