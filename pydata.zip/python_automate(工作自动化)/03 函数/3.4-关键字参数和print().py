# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:09
# 文件      : 3.4-关键字参数和print().py
# IDE       : PyCharm

print('Hello ', end='')
print('World')

print('cats', 'dogs', 'mice', sep=',')


