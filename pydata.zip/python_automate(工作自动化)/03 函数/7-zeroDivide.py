# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 7-zeroDivide.py
@time: 2018/6/13 4:10
"""

def spam(divideBy):
    try:
        return 42 / divideBy
    except ZeroDivisionError:
        print('Error: Invalid argument.')
print(spam(2))
print(spam(12))
print(spam(0))
print(spam(1))