# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 5-sameName2.py
@time: 2018/6/12 4:05
"""

def spam():
    global eggs
    eggs = 'spam'

eggs = 'global'
spam()
print(eggs)
