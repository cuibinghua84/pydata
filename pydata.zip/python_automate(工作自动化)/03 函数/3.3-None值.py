# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:08
# 文件      : 3.3-None值.py
# IDE       : PyCharm

spam = print('Hello')
# print(spam)

print(None == spam)

