# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:10
# 文件      : 3.8-一个小程序：猜数字.py
# IDE       : PyCharm

# 猜字游戏
import random
secretNumber = random.randint(1, 20)
print(secretNumber)
print('I am thinking of a number between 1 and 20.')

for guessesTaken in range(1, 7):
	print('Take a guess.')
	guess = int(input())

	if guess < secretNumber:
		print('Your guess is too low.')
	elif guess > secretNumber:
		print('Your guess is too high.')
	else:
		break

if guess == secretNumber:
	print('Good job! You guessed my number in ' + str(guessesTaken) + ' guesses!')
else:
	print('Nope. The number I was thinking of was ' + str(secretNumber))

