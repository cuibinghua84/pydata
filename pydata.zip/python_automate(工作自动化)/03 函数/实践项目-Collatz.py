# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 实践项目-Collatz.py
@time: 2018/6/13 14:12
"""


def collatz(number):
    if number % 2 == 0:
        print(number // 2)
    elif number % 2 == 1:
        print(3 * number + 1)



