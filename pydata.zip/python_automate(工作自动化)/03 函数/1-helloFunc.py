# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 1-helloFunc.py
@time: 2018/6/11 13:41
"""

def hello():
    print('Howdy! ')
    print('Howdy!!!')
    print('Hello there.')

hello()
hello()
hello()