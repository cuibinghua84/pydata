# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 2-helloFunc2.py
@time: 2018/6/11 16:23
"""

def hello(name):
    print('Hello ' + name)

hello('Alice')
hello('Bob')