# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 6-sameName3.py
@time: 2018/6/12 20:46
"""


def spam():
    global eggs
    eggs = 'spam'


def bacon():
    geeg = 'bacon'


def ham():
    print(eggs)


eggs = 36
spam()
print(eggs)
