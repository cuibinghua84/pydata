# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/6/26 11:08
# 文件      : 3.1-def语句和参数.py
# IDE       : PyCharm

# def hello():
# 	print('Howdy!')
# 	print('Howdy!!!')
# 	print('Hello three.')

# print(hello())
# print()
# hello()


# def hello(name):
# 	print('Hello ' + name)

# hello('Alice')
# hello('Bob')








