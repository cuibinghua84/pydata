# 1.1 解压序列赋值给多个变量
# 任何的序列可以通过一个简单的赋值语句解压并赋值给多个变量。唯一的前提就是变量的数量必须跟序列元素的数量是一样的
p = (4, 5)
x, y = p
print(x)
print(y)

data = ['ACME', 50, 91.1, (2019, 12, 12)]
name, shares, price, date = data
print(name)
print(shares)
print(price)
print(date)

# 解压赋值，可以用在任何可迭代对象上面，包括字符串、文件对象、迭代器和生成器
s = "Hello"
a, b, c, d, e = s
print(a)
print(b)
print(c)
print(d)
print(e)

# 解压一部分





