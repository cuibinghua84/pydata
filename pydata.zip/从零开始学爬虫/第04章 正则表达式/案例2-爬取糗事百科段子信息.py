# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/8/7 10:21
# 文件      : 案例2-爬取糗事百科段子信息.py
# IDE       : PyCharm

# 导入相应的库文件
import requests
import re
import time

# 加入请求头
headers = {
    'Host': 'www.qiushibaike.com',
    'Referer': 'https://www.qiushibaike.com/',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
}

# 初始化列表，用于装入爬虫信息
info_lists = []


# 定义获取用户性别的函数
def judgment_sex(class_name):
    if class_name == 'articleGender womenIcon':
        return '女'
    else:
        return '男'


# 定义获取详细信息函数
def get_info(url):
    res = requests.get(url, headers=headers)
    ids = re.findall('<h2>(.*?)</h2>', res.text, re.S)  # 用户ID
    levels = re.findall('<div class="articleGender womenIcon">(.*?)</div>', res.text, re.S)  # 用户等级
    sexs = re.findall('<div class="articleGender womenIcon(.*?)">', res.text, re.S)  # 用户性别
    contents = re.findall('<div class="content">.*?<span>(.*?)</span>', res.text, re.S)  # 发表段子文字信息
    laughs = re.findall('<span class="stats-vote"><i class="number">(\d+)</i>', res.text, re.S)  # 好笑数量
    comments = re.findall('<i class="number">(\d+)</i> 评论', res.text, re.S)  # 评论数量
    for id, level, sex, content, laugh, comment in zip(ids, levels, sexs, contents, laughs, comments):
        info = {
            'id': id,
            'level': level,
            'sex': judgment_sex(sex),
            'content': content,
            'laugh': laugh,
            'comment': comment
        }
        info_lists.append(info)


# 程序主入口
if __name__ == '__main__':
    urls = ['https://www.qiushibaike.com/text/page/{}/'.format(str(i)) for i in range(1, 2)]
    for url in urls:
        get_info(url)
    for info_list in info_lists:
        f = open('qiushibaike.txt', 'a+')
        try:
            f.write(info_list['id'] + '\n')
            f.write(info_list['level'] + '\n')
            f.write(info_list['sex'] + '\n')
            f.write(info_list['content'] + '\n')
            f.write(info_list['laugh'] + '\n')
            f.write(info_list['comment'] + '\n')
            f.close()
        except UnicodeEncodeError:
            pass
