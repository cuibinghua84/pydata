# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/8/6 17:31
# 文件      : re模块学习.py
# IDE       : PyCharm

import re
import requests

"""
正则表达式符号
一般字符
.
\
[...]

预定义字符集
\d
\D
\s
\S
\w
\W

数量词
*
+
?
{m}
{m,n}

边界匹配
^
$
\A
\Z

"""


# (.*?)
# a = 'xxIxxjshdxxlovexxasfsasxxpythonxxedasdfsa'
# infos = re.findall('xx(.*?)xx', a)
# print(infos)

# search()
# a = 'one1two2three3'
# infos_a = re.search('\d+', a)
# print(infos_a.group())

# sub()
# phone = '123-4567-1234'
# new_phone = re.sub('\D', '', phone)
# print(new_phone)

# findall()
# infos_a_all = re.findall('\d+', a)
# print(infos_a_all)

# 通过正则表达式获取房屋的价格
# url = 'http://bj.xiaozhu.com/'
# headers = {
#     'Host': 'bj.xiaozhu.com',
#     'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
# }
# res = requests.get(url, headers=headers)
# print(res.status_code)
# prices = re.findall('<span class="result_price">&#165;<i>(.*?)</i>起/晚</span>', res.text)
# print(prices)
# for price in prices:
#     print(price)

# re模块修饰符
# re.I
# re.L
# re.M
# re.S
a = '''<div>指数
</div>'''
word = re.findall('<div>(.*?)</div>', a, re.S)
print(word[0].strip())
# re.U
# re.X

