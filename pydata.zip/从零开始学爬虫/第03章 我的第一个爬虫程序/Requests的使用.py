# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/8/5 16:51
# 文件      : Requests的使用.py
# IDE       : PyCharm

import requests

# 网站为小猪短租网北京地区网址
url = 'http://bj.xiaozhu.com/'
headers = {
    'Host': 'bj.xiaozhu.com',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
}

res = requests.get(url, headers=headers)
try:
    print(res)  # 如果范围200，说明请求网站成功；若为400，则请求网址失败
    print(res.text[:100])
except ConnectionError:
    print('拒绝连接')

