# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/8/5 16:59
# 文件      : BS的使用.py
# IDE       : PyCharm

import requests
from bs4 import BeautifulSoup

url = 'http://bj.xiaozhu.com/'
headers = {
    'Host': 'bj.xiaozhu.com',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
}

res = requests.get(url, headers=headers)
# print(res.apparent_encoding)
# print(res.encoding)
# print(res.status_code)
soup = BeautifulSoup(res.text, 'html.parser')
# print(soup.prettify(encoding='utf-8'))

# 打印一个房屋的价格
# price = soup.select('#page_list > ul > li:nth-child(1) > div.result_btm_con.lodgeunitname > div:nth-child(1) > span > i')
# print(price)

# 打印所有房屋的价格
prices = soup.select('#page_list > ul > li > div.result_btm_con.lodgeunitname > div > span > i')
# 循环遍历
for price in prices:
    print(price.get_text())
