# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/8/6 11:51
# 文件      : 案例1-爬取北京地区短租房屋信息.py
# IDE       : PyCharm

# 导入相应的库文件
from bs4 import BeautifulSoup
import requests
import time

# 加入请求头
headers = {
    'Host': 'bj.xiaozhu.com',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
}


# 定义判断用户性别的函数
def judgment_sex(class_name):
    if class_name == ['member_ico1']:
        return '女'
    else:
        return '男'


# 定义获取详细页的函数
def get_links(url):
    wb_data = requests.get(url, headers=headers)
    soup = BeautifulSoup(wb_data.text, 'lxml')
    # links为URL列表
    links = soup.select('#page_list > ul > li > a')
    for link in links:
        href = link.get("href")
        get_info(href)


# 定义获取网页信息的函数
def get_info(url):
    wb_data = requests.get(url, headers=headers)
    # print(wb_data.status_code)
    soup = BeautifulSoup(wb_data.text, 'lxml')
    tittles = soup.select('div.pho_info > h4')  # 标题
    addresses = soup.select('span.pr5')  # 地址
    prices = soup.select('#pricePart > div.day_l > span')  # 价格
    imgs = soup.select('#floatRightBox > div.js_box.clearfix > div.member_pic > a > img')  # 房东头像链接
    names = soup.select('#floatRightBox > div.js_box.clearfix > div.w_240 > h6 > a')  # 房东名称
    sexs = soup.select('#floatRightBox > div.js_box.clearfix > div.member_pic > div')  # 房东性别

    for tittle, address, price, img, name, sex, in zip(tittles, addresses, prices, imgs, names, sexs):
        data = {
            'tittle': tittle.get_text().strip(),
            'address': address.get_text().strip(),
            'price': price.get_text(),
            'img': img.get("src"),
            'name': name.get_text(),
            'sex': judgment_sex(sex.get("class"))
        }
        # 获取信息并通过字典的信息打印
        print(data)


# 主程序入口
if __name__ == '__main__':
    # 构造多页URL
    urls = ['http://bj.xiaozhu.com/search-duanzufang-p{}-0/'.format(number) for number in range(1, 2)]
    print(urls)
    # 循环调用get_links函数
    for single_url in urls:
        get_links(single_url)
        # 睡眠3秒
        time.sleep(3)
