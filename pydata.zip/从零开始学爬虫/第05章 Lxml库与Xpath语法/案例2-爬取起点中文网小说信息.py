# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/8/9 15:29
# 文件      : 案例2-爬取起点中文网小说信息.py
# IDE       : PyCharm


# 导入相应的库文件
import requests
from lxml import etree
from bs4 import BeautifulSoup
import re
import time

