# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/8/9 13:29
# 文件      : 性能对比.py
# IDE       : PyCharm


# 导入相应的库文件
import requests
from lxml import etree
from bs4 import BeautifulSoup
import re
import time


# 分别利用正则表达式、BeautifulSoup、Lxml对糗事百科文字内容爬取来对比性能

# 加入请求头
headers = {
	'Host': 'www.qiushibaike.com',
	'Referer': 'https://www.qiushibaike.com/',
	'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
}


# 构造urls
urls = ['https://www.qiushibaike.com/text/page/{}/'.format(str(i)) for i in range(1, 4)]
# print(urls)


# 用正则表达式爬虫
def re_scraper(url):
	res = requests.get(url, headers=headers)
	ids = re.findall('<h2>(.*?)</h2>', res.text, re.S)	# 用户ID 
	contents = re.findall('<div class="content">.*?<span>(.*?)</span>', res.text, re.S)	# 段子文字信息
	laughs = re.findall('<span class="stats-vote"><i class="number">(\d+)</i>', res.text, re.S)	# 好笑数量
	comments = re.findall('<i class="number">(\d+)</i> 评论', res.text, re.S)	# 评论数量
	for id, content, laugh, comment in zip(ids, contents, laughs, comments):
		info = {
			'id': id,
			'content': content,
			'laugh': laugh,
			'comment': comment
		}
		return info 	# 只返回数据，不存储



# 用BeautifulSoup爬虫
def bs_scraper(url):
	res = requests.get(url, headers=headers)
	soup = BeautifulSoup(res.text, 'lxml')
	ids = soup.select('a > h2')
	contents = soup.select('div > span')
	laughs = soup.select('span.stats-vote > i')
	comments = soup.select('i.number')
	for id, content, laugh, comment in zip(ids, contents, laughs, comments):
		info = {
			'id': id.get_text(),
			'content': content.get_text(),
			'laugh': laugh.get_text(),
			'comment': comment.get_text()
		}
		return info


# Lxml爬虫
def lxml_scraper(url):
	res = requests.get(url, headers=headers)
	selector = etree.HTML(res.text)
	url_infos = selector.xpath('//div[@class="article block untagged mb15 typs_hot"]')
	try:
		for url_info in url_infos:
			id = url_info.xpath('div[1]/a[2]/h2/text()')[0]
			content = url_info.xpath('a[1]/div/span/text()')[0]
			laugh = url_info.xpath('div[2]/span[1]/i/text()')[0]
			comment = url_info.xpath('div[2]/span[2]/a/i/text()')[0]

			info = {
				'id': id,
				'content': content,
				'laugh': laugh,
				'comment': comment
			}
			return info

	except IndexError:
		pass

# 程序主入口
if __name__ == '__main__':
	for name, scraper in [('Regular expreesions', re_scraper), ('BeautifulSoup', bs_scraper), ('Lxml', lxml_scraper)]:
		start = time.time()
		for url in urls:
			scraper(url)
		end = time.time()
		print(name, end - start)

"""
总结
爬取方法			性能 	使用难度		安装难度
正则表达式		快		困难			简单
BeautifulSoup 	慢		简单			简单
Lxml 			快		简单 		相对困难

当网页结构简单并且想要避免额外依赖的话，使用正则表达式更为合适。
当网页爬取的数据量较少时，使用较慢的BeautifulSoup也不成问题
当数据量大，需要追求效益时，Lxml是最好的选择
"""