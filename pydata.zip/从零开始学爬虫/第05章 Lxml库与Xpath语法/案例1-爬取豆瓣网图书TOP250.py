# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/8/9 19:29
# 文件      : 案例1-爬取豆瓣网图书TOP250.py
# IDE       : PyCharm


# 导入相应的库文件
import requests
from lxml import etree
from bs4 import BeautifulSoup
import re
import time
import csv


# 示例
# fp = open('test.csv', 'w+')
# writer = csv.writer(fp)
# writer.writerow(('id', 'name'))
# writer.writerow(('1', 'xiaoming'))
# writer.writerow(('2', '张三'))
# writer.writerow(('3', '李四'))

# 爬取内容：书名、书本的URL链接、作者、出版社和出版时间、书本价格、评分和评价


# 创建csv
fp = open('doubanbook_top250.csv', 'wt', newline='', encoding='utf-8')
writer = csv.writer(fp)
writer.writerow(('name', 'url', 'author', 'publisher', 'date', 'price', 'rate', 'comment'))

# 构造urls
urls = ['https://book.douban.com/top250?start={}'.format(str(i)) for i in range(0, 25, 25)]

# 加入请求头
headers = {
	'Host': 'book.douban.com',
	'Referer': 'https://book.douban.com/top250',
	'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
}


# 爬取数据
for url in urls:
	html = requests.get(url, headers=headers)
	selector = etree.HTML(html.text)
	infos = selector.xpath('//tr[@class="item"]')	# 取大标签，以次循环
	for info in infos:
		name = info.xpath('td/div/a/@title')[0]
		url = info.xpath('td/div/a/@href')[0]
		book_infos = info.xpath('td/p/text()')[0]
		author = book_infos.split('/')[0]
		publisher = book_infos.split('/')[-3]
		date = book_infos.split('/')[-2]
		price = book_infos.split('/')[-1]
		rate = info.xpath('td/div/span[2]/text()')[0]
		comments = info.xpath('td/p/span/text()')
		comment = comments[0] if len(comments) != 0 else "空"
		# print(comment)

		writer.writerow((name, url, author, publisher, date, price, rate, comment))


# 关闭csv文件
fp.close()


