# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/8/8 11:29
# 文件      : Xpath的使用.py
# IDE       : PyCharm

import requests
from lxml import etree


# 父节点
# 子节点
# 同胞节点
# 先辈节点
# 后代节点

# 节点的选择
"""
nodename
/	选取此节点的所有子节点
//	从跟绝点需求怒
.	选取当前节点
..	选取当前节点的父节点
@	选取属性

谓语
/user_database/user[1]	选取属于user_database子元素的第一个user元素
//li[@attribute]	选取所有拥有名为attribute属性的li元素
//li[@attribute=' red']	 选取所有li元素，且这些元素拥有作为red的attribute属性
"""

"""
# 通过xpath获取糗事百科的用户ID
headers = {
	'Host': 'www.qiushibaike.com',
	'Referer': 'https://www.qiushibaike.com/',
	'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
}

url = "https://www.qiushibaike.com/text/"
res = requests.get(url, headers=headers)
selector = etree.HTML(res.text)

# 获取单个用户ID
# id = selector.xpath('//*[@id="qiushi_tag_122093301"]/div[1]/a[2]/h2/text()')[0]
# print(id)

# 批量获取用户ID
url_infos = selector.xpath('//div[@class="article block untagged mb15 typs_hot"]')
for url_info in url_infos:
	id = url_info.xpath('div[1]/a[2]/h2/text()')[0].strip()
	print(id)
"""


# 相同的字符开头的多个标签，处理方法，通过start-with()获取多个标签内容
html1 = '''
<li class="tag-1">需要的内容1</li>
<li class="tag-2">需要的内容2</li>
<li class="tag-3">需要的内容3</li>
'''
# selector = etree.HTML(html1)
# contents = selector.xpath('//li[starts-with(@class, "tag")]/text()')
# for content in contents:
# 	print(content)


# 标签嵌套时，想同时爬取内容，可以通过string(.)处理
html2 = '''
<div class="red">需要的内容1
	<h1>需要的内容2</h1>
</div>
'''
selector = etree.HTML(html2)
content1 = selector.xpath('//div[@class="red"]')[0]
content2 = selector.xpath('string(.)')
print(content2)