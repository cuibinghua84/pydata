# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/8/7 13:33
# 文件      : Lxml的使用.py
# IDE       : PyCharm
from lxml import etree
import requests

# 修正HTML代码
# text = '''
# <div>
#     <ul>
#         <li class="red"><h1>red flowers</h1></li>
#         <li class="yellow"><h2>yellow flowers item</h2></li>
#         <li class="white"><h3>white flowers</h3></li>
#         <li class="black"><h4>black flowers</h4></li>
#         <li class="blue"><h5>blue flowers</h5>
#     </ul>
# </div>
# '''
# html = etree.HTML(text)
# result = etree.tostring(html)
# print(result)

# 读取HTML
# html = etree.parse('flower.html')
# result = etree.tostring(html, pretty_print=True)
# print(result)

parser = etree.HTMLParser(encoding='utf-8')
htmlelement = etree.parse("flower.html", parser=parser)
print(etree.tostring(htmlelement, encoding='utf-8').decode("utf-8"))

# 解析HTML
url = 'https://book.douban.com/top250'
headers = {
    'Host': 'book.douban.com',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
}

res = requests.get(url, headers=headers)
html = etree.HTML(res.text)
result = etree.tostring(html)
print(result)

