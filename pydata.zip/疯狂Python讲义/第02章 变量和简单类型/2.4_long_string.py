s = '''"Let's go fishing", said Mary.
"OK, Let's go", said her brother.
they walked to a lake'''
print(s)

# 转义字符
s2 = 'The quick brown fox \
jumps over the lazy dog'
print(s2)