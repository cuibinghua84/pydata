s = ' this is puppy '
# strip()：删除字符串前后的空白
print(s.strip())

# lstrip()：删除字符串前面的空白
print(s.lstrip())

# rstrip()：删除字符串后面的空白
print(s.rstrip())

print(s)

s2 = 'i think it is a scarecrow'
print(s2.lstrip('itow'))
print(s2.rstrip('itow'))
print(s2.strip('itow'))