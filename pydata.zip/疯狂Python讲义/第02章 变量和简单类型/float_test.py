af1 = 5.2345556
print(af1)

af2 = 25.2345
print(type(af2))

f1 = 5.12e2
print(f1)

f2 = 5e3
print(f2)
print(type(f2))