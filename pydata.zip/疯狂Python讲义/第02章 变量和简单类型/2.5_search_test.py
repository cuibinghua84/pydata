s = 'crazyit.org is a good site'

# startswith()：判断字符串是否以指定子串开头
print(s.startswith('crazyit'))

# endswith()：判断字符串是否以指定子串结尾
print(s.endswith('site'))

# find()：查找指定子串在字符串中出现的位置，如果没有找到指定子串，则返回-1
print(s.find('org'))

# index()：查找指定子串在字符串中出现的位置，如果没有找到指定子串，则引发ValueError错误
print(s.index('org'))

# replace()：使用指定子串替换字符串中的目标子串
print(s.replace('it', 'xxxx'))
print(s.replace('c', 'xxxx', 1))

# translate()：使用指定的翻译映射表对字符串执行替换
table = {97: 945, 98: 946, 116: 964}
print(s.translate(table))

# 通过方法maketrans()进行映射
table =  str.maketrans('abt', 'αβγ')
print(table)

table = str.maketrans('abc', '123')
print(table)