a = 56
print(a)

a = 99999999999999999999
print(a)
print(type(a))