# -*- coding: utf-8 -*-
# print()函数可同时输出多个变量
# print(value, ..., sep='', end='\n', file=sys.stdout, flush=False)

user_name = 'Carl'
user_age = 35

# 同时输出多个变量和字符串，指定分隔符
print("读者名：", user_name, "年龄：", user_age, sep='|')

# 设置end参数，指定输出之后不再换行
print(40, '\t', end="")
print(50, '\t', end="")
print(60, '\t', end="")

# file参数默认sys.stdout，代表了系统标准输出，即屏幕；也可以改变参数让函数输出到特定文件中
f = open("poem.txt", "w") # 打开文件以便写入
print('沧海月明珠有泪', file=f)
print('蓝田日暖玉生烟', file=f)
f.close()

# flush()参数用于控制输出缓存，该参数一般保持为False
