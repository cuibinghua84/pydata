# dir()：列出指定类或模块包含的全部内容（函数、方法、类、变量等）
# help()：查看某个函数或方法的帮助文档

# print(dir(str))
# print(help(str.title))

"""
title()：将每个单词的首字母改为大写
lower()：将整个字符串改为小写
upper()：将整个字符串改为大写
"""

a = 'our domain is crazyit.org'
# title()：将每个单词的首字母改为大写
print(a.title())

# lower()：将整个字符串改为小写
print(a.lower())

# upper()：将整个字符串改为大写
print(a.upper())