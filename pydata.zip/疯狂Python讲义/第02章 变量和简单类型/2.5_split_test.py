s = 'crazyit.org is a good site'
# split()：将字符串按指定分隔符分割成多个短语
print(s.split())
print(s.split(None, 2))	# 使用空白对字符串进行分割，最多只分割前两个单词
print(s.split('.'))

# join()：将多个短语连接成字符串
my_list = s.split()
print(my_list)
print('/'.join(my_list))
print(','.join(my_list))