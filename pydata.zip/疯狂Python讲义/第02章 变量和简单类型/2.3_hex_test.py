"""
Python整型有4种：
十进制：0-9
二进制：0b 0B
八进制：0o 0O
十六进制:0x  0X 10~15=>a~f
"""

# 以0x或0X开头的整型数值是十六进制形式的整数
hex_value1 = 0x13
hex_value2 = 0XaF
print("hexValue1的值为：", hex_value1)
print("hexValue2的值为：", hex_value2)

# 以0b或0B开头的整数值是二进制的整数
bin_val = 0b111
print('bin_val的值为：', bin_val)
bin_val = 0B101
print('bin_vald的值为：', bin_val)

# 以0o或0O开头的整型数值是八进制形式的整数
oct_val = 0o54
print(oct_val)
oct_val = 0O17
print(oct_val)

# 在数值中使用下划线
one_million = 1_000_000
print(one_million)
price = 234_234_234
android = 1234_1234
print(price)
print(android)
