str1 = 'Charlie'
str2 = "疯狂Python学习"
print(str1)
print(str2)

# 转移符 \
str5 = '"we are scared, Let\'s hide in the shade", says teh bird'
print(str5)

# 拼接字符串 +
s2 = "Python "
s3 = "is Funny"
s4 = s2 + s3
print(s4)

# repr和字符串
# str()和repr()将数值转换成字符串
# str是Python内置的类型，repr()则是一个函数，它会以Python表达式的形势表示值
s1 = "这本书的价格是："
p = 99.8
# print(s1 + p)
print(s1 + str(p))
print(s1 + repr(p))

st = "I will play my fife"
print(st)
print(repr(st))

