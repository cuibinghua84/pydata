msg = input("请输入你的值：")
print(type(msg))
print(msg)