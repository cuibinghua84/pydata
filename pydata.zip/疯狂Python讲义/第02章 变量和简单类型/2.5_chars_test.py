# 序列相关方法
s = 'crazyit.org is very good'
print(s[2])
print(s[-4])
print(s[3:5])
print(s[3:-5])
print(s[-6:-3])
print(s[5:])
print(s[-6:])
print(s[:-6])

# in运算符判断是否包含某个字符串
print('very' in s)
print('fkit' in s)

# len()函数获取字符串长度
print(len(s))
print(len('test'))

# min() max()函数获取字符串中最小字符和最大字符
print(min(s))
print(max(s))