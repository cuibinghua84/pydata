# 定义一个数值类型变量
a = 5
print(a)

# 重新将字符串赋值给a变量
a = 'Hello, Charlie'
print(a)
print(type(a))

"""
标识符可以由字母、数组、下划线组成，其中数字不能打头
标识符不能是Python关键字，但可以包含关键字
标识符不能包含空格
"""