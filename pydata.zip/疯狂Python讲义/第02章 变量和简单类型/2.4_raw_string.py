s1 = r'D:\work\py\pydata'
print(s1)
s2 = r'"Let\'s go", said Charlie'
print(s2)
s3 = r'Good Morning' '\\'
print(s3)