# 2.6.1 赋值运算符
print("赋值运算符")
st = 'python'
pi = 3.14
visited = True
st2 = st
print(st2)
a = b = c = 20
d1 = 12.34
d2 = d1 + 5
print("d2的值为： %g" % d2)

# 2.6.2 算术运算符
print("\n算术运算符")
a = 5.2
b = 3.1
the_sum = a + b
print("the_sum的值为：", the_sum)

s1 = 'Hello, '
s2 = 'Python'
print(s1 + s2)

c = 5.2
d = 3.1
sub = c - d
print("sub的值为：", sub)

x = -0.5
x = -x
print(x)

y = -5.0
y = +y
print(y)

e = 5.2
f = 3.1
multiply = e * f
print("multiply的值为：", multiply)

s3 = 'crazyit '
print(s3 * 5)

# / //
print("19/4的结果是：", 19 / 4)
print("19//4的结果是：", 19 // 4)
aa = 5.2
bb = 3.1
print("aa//bb的值是：", aa // bb)
print("aa/bb的值是：", aa / bb)

# 求余运算符 %
print(5 % 3)
print(5.2 % 3.1)
print(-5.2 % -3.1)
print(5.2 % -2.9)
print(5.2 % -1.5)
print(5.2 % 1.5)
print(-5.2 % 1.5)
print()

# 乘法运算符
print(5 ** 2)
print(4 ** 3)
print(4 ** 0.5)
print(27 ** (1 / 3))

# 2.6.3 位运算符
print('\n位运算符')
"""
&:按位与
|:按位或
^:按位异或
~:按位取反
<<:左位移运算
>>:右位移运算
"""
print(5 & 9)
print(5 | 9)

# 2.6.4 扩展后的赋值运算符
print('\n')
"""
+=	x = x + y
-=	x = x - y
*=	
/=
//=
%/
**=
&=
|=
^=
<<=
>>=
"""

# 2.6.5 索引运算符
print('\n索引运算符')

# 2.6.6 比较运算符与bool类型
print('\n比较运算符与bool类型')
'''
>
>=
<
<=
==
!=
is
is not
'''
import time
a = time.gmtime()
b = time.gmtime()
print(a)
print(b)
print(a == b)
print(a is b)
print(id(a))
print(id(b))

# 2.6.7 逻辑运算符
print('\n逻辑运算符')
# and or not

# 2.6.8 三目运算符
print('\n三目运算符')
# if

# 2.6.9 in运算符
print('\nin运算符')

# 2.6.10 运算符优先级
print('\n运算符优先级')