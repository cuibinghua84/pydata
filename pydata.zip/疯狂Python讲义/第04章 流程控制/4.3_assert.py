s_age = input("请输入您的年龄：")
age = int(s_age)
assert 20 < age < 80
print("请输入您的年龄在20到80之间")