print("break结束循环")
for i in range(0, 10):
	print("i的值是：", i)
	if i == 2:
		break
	else:
		print('else块：', i)

print("\nbreak语句定义，变量标志，是否跳槽外层循环")
exit_flag = False
# 外层循环
for i in range(0, 5):
	# 内层循环
	for j in range(0, 3):
		print("i的值为： %d, j的值为：%d" % (i, j))
		if j == 1:
			exit_flag = True
			# 跳出内层循环
			break
	# 如果exit_flag为True，跳出外层循环
	if exit_flag:
		break

print("\ncontinue忽略本次循环的剩下语句")
for i in range(0, 3):
	print("i的值是：", i)
	if i == 1:
		# 忽略当次循环的剩下语句
		continue
	print("continue后的输出语句")

print("\nreturn结束方法")
def test():
	# 外层循环
	for i in range(10):
		for j in range(10):
			print("i的值为： %d，j的值为： %d" % (i, j))
			if j == 1:
				return
			print("return后的输出语句")

test()
