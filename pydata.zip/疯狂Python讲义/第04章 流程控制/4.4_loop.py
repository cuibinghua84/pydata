"""
循环语句四部分：初始化语句、循环条件、循环体、迭代语句
"""
print("\n通过while循环、列表或元组的索引来遍历列表和元组中的所有元素")
count_i = 0
while count_i < 10:
	print("count:", count_i)
	count_i += 1
print("循环结束！")

print("\nwhile循环遍历列表和元组")
print("循环元组")
a_tuple = ('fkit', 'crazyit', 'Chrlie')
i = 0
while i < len(a_tuple):
	print(a_tuple[i])
	i += 1

print("\n对一个整数列表的元素进行分类")
src_list = [12, 45, 34, 13, 100, 24, 56, 74, 109]
a_list = []	# 定义保存整除3的元素
b_list = []	# 定义保存除以3余1的元素
c_list = []	# 定义保存处理3余2的元素
while len(src_list) > 0:
	ele = src_list.pop()
	if ele % 3 == 0:
		a_list.append(ele)
	elif ele % 3 == 1:
		b_list.append(ele)
	else:
		c_list.append(ele)
print("列表为：", src_list)
print("整除3：", a_list)
print("除以3余1：", b_list)
print("除以3余2：", c_list)

print("\nfor-in循环专门用于遍历范围、列表、元组和字典等可迭代对象包含的元素")
print("for-in循环来计算指定整数的阶乘")
# s_max = input("请输入您想计算的阶乘：")
# mx = int(s_max)
# result = 1
# for num in range(1, mx + 1):
# 	result *= num
# print(result)

print("\nfor-in循环遍历列表和元组")
a_tuple = ('crazyit', 'fkit', 'Charlie')
for ele in a_tuple:
	print("当前元素是：", ele)

print("\n遍历列表，同时计算列表中所有元素的总和、平均值")
src_list = [12, 45, 3.4, 13, 12, 'fkit', 45, 'a', 4, 56, 'crazyit', 109.5, 3.4, 'fkit']
my_sum = 0
my_count = 0

for ele in src_list:
	# 如果该元素是整数或浮点数
	# isinstance()函数用于判断某个变量是否为指定类型的实例
	if isinstance(ele, int) or isinstance(ele, float):
		print(ele)
		# 累加该元素
		my_sum += ele
		# 数值元素的个数加1
		my_count += 1
print("总和：", my_sum)
print("平均数：", my_sum / my_count)

print("\nfor-in根据索引来遍历列表")
a_list = [330, 1.4, 50, 'fkit', -3.5]
for i in range(0, len(a_list)):
	# 根据索引访问列表元素
	print("第%d个元素是 %s" % (i, a_list[i]))

print("\nfor-in循环遍历字典")
# items()：返回字典中所有key-value对的列表
# keys()：返回字典中所有key的列表
# values()：返回字典中所有value的列表
my_dict = {'语文': 89, '数学': 92, '语文': 80}
for key, value in my_dict.items():
	print('key:', key)
	print('value:', value)
print("------------")
for key in my_dict.keys():
	print('key:', key)
	print('value:', my_dict[key])
print("------------")
for value in my_dict.values():
	print('value:', value)

print("\n统计列表中个元素出现的测试")
statistics = {}
for ele in src_list:
	if ele in statistics:
		statistics[ele] += 1
	else:
		statistics[ele] =  1
for ele, count in statistics.items():
	print("%s 出现的次数为：%d" % (ele, count))

print("\n循环使用else")
count_i = 0
while count_i < 5:
	print('count_i小于5：', count_i)
	count_i += 1
else:
	print('count_i大于或等于5：', count_i)

print("\nelse模块放在while循环体之外")
count_i = 0
while count_i < 5:
	print("count_i小于5：", count_i)
	count_i += 1
print("count_i大于或等于5：", count_i)

print("\nfor循环中的else")
a_list = [330, 1.4, 50, 'fkit', -3.5]
for ele in a_list:
	print("元素：", ele)
else:
	print('else块：', ele)

print("\n嵌套循环简单示例")
print("外层循环执行1次，内层循环执行1遍")
# 外层循环
for i in range(0, 5):
	j = 0
	# 内层循环
	while j < 3:
		print("i的值为：%d，j的值为：%d" % (i, j))
		j += 1

print("\nfor表达式，返回的是列表，也称为列表推导式")
# a_range = range(10)
a_list = [x * x for x in range(10)]
print(a_list)

b_list = [x * x for x in range(10) if x % 2 == 0]
print(b_list)

print("\n使用圆括号的for表达式，最终返回的是生成器")
a_range = range(10)
c_generator = (x * x for x in a_range if x % 2 == 0)
for i in c_generator:
	print(i, end='\t')
print()

print("\nfor表达式可使用多个循环")
d_list = [(x, y) for x in range(5) for y in range(4)]
print(d_list)

print("\n上面的for表达式相当于嵌套循环如下：")
dd_list = []
for x in range(5):
	# print(x)
	for y in range(4):
		# print(y)
		dd_list.append((x, y))
print(dd_list)

print("\nfor表达式三层嵌套")
e_list = [[x, y, z] for x in range(5) for y in range(4) for z in range(6)]
print(e_list)

print("\n多个循环的for表达式，同时指定if条件")
src_a = [30, 12, 66, 34, 39, 78, 36, 57, 121]
src_b = [3, 5, 7, 11]
result = [(x, y) for x in src_b for y in src_a  if y % x == 0]
print(result)

print("\nzip函数把两个列表压缩成一个zip对象（可迭代对象）")
a = ['a', 'b', 'c']
b = [1, 2, 3]
c = [0.1, 0.2]
print([x for x in zip(a, b)])
print([x for x in zip(a, c)])
print([x for x in zip(a, b, c)])

print("\nzip函数实现并行遍历")
books = ['疯狂Kotlin讲义', '疯狂Swift讲义', '疯狂Python讲义']
prices = [79, 69, 89]
# 实现并行遍历
for book, price in zip(books, prices):
	print("%s的价格是：%5.2f" % (book, price))

print("\nreversed()函数，返回一个'反序排列'的迭代器")
a = range(10)
print(list(a))
# print(reversed(list(a)))
print([x for x in reversed(a)])

b = ['a', 'fkit', 20, 3.4, 50]
print([x for x in reversed(b)])

c = "Hello, Charlie"
print([x for x in reversed(c)])

print("\nsorted()函数")
a = [20, 30, -1.2, 3.5, 90, 3.6]
print(sorted(a))
print(a)
print(sorted(a, reverse=True))

b = ['fkit', 'crazyit', 'Charlie', 'fox', 'Emily']
print(sorted(b, key=len))

my_list = ['fkit', 'crazyit', 'Charlie', 'fox', 'Emily']
for s in sorted(my_list, key=len):
	print(s)

