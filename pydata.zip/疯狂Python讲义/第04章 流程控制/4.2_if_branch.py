# s_age = input("请输入您的年龄：")
# age = int(s_age)
# if age > 36:
# 	print("年龄已经大于35岁了")
# 	print("35岁以上的人应该学会承担责任...")

'''
注意事项
1 不要忘记缩进
2 不要随意缩进
3 不要遗忘冒号
'''

# if条件可以是任意类型
print('if条件类型')
print('定义空字符串')
s = ""
if s:
	print('s不是空字符串')
else:
	print('s是空字符串')

print('\n定义空列表')
my_list = []
if my_list:
	print("my_list不是空列表")
else:
	print("my_lits是空列表")

print('\n定义空字典')
my_dict = {}
if my_dict:
	print('my_dict不是空字典')
else:
	print('my_dict是空字典')

# if分支的逻辑错误
print('\nif分支的逻辑错误')
age = 45
if age > 20:
	print("青年人")
elif age > 40:
	print("中年人")
elif age > 60:
	print("老年人")

print('\nif分支的正确逻辑')
age = 45
if age > 60:
	print("老年人")
elif age > 40:
	print("中年人")
elif age > 20:
	print("年轻人")

print("\nif分支的正确逻辑另一种写法")
age = 45
if age > 60:
	print("老年人")
if age > 40 and not(age > 60):
	print("中年人")
if age > 20 and not(age > 60) and not(age > 40 and not(age > 60)):
	print("青年人")


# if语句还可以作为表达式

# pass语句
print("\npass语句就是空语句")
s = input("请输入一个整数：")
s = int(s)
if s > 5:
	print("大于5")
elif s < 5:
	pass
else:
	print("等于5")
