# -*- coding: utf-8 -*
print("定义类")

print("\n对象的产生和使用")

print("\n实例方法和自动绑定self")

