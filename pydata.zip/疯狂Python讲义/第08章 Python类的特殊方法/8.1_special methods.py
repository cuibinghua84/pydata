# __repr__方法
class Item:
	def __init__(self, name, price):
		self.name = name
		self.price = price

# im = Item('鼠标', 29.8)
# print(im)
# print(im.__repr__)


class Apple:
	def __init__(self, color, weight):
		self.color = color
		self.weight = weight

	def __repr__(self):
		return "Apple[color=" + self.color + ", weight= " + str(self.weight) + "]"

a = Apple("红色", 5.68)
print(a)