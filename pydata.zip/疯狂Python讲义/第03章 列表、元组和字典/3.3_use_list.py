# 创建列表
# list()函数可用于将元组、区间等对象转换为列表
'''
a_tuple = ('crazyit', 20, -1.2)
# 将元组转成列表
a_list = list(a_tuple)
print(a_list)

# 使用range()函数创建区间对象
a_range = range(1, 5)
print(a_range)
# 将区间转换成列表
b_list = list(a_range)
print(b_list)
# 创建区间指定步长
c_list = list(range(4, 20, 3))
print(c_list)
'''

# tuple()函数可用于将列表、区间等对象转换为元组
# print()
# a_list = ['crazyit', 20, -1.2]
# a_tuple = tuple(a_list)
# print(a_tuple)
# a_range = range(1, 5)
# print(a_range)
# b_tuple = tuple(a_range)
# print(b_tuple)
# c_tuple = tuple(range(4, 20, 3))
# print(c_tuple)

# 增加列表元素
# append()
a_list = ['crazyit', 20, -2]
# 追加元素
a_list.append('fkit')
print(a_list)

# 追加元组
a_tuple = (3.4, 5.6)
a_list.append(a_tuple)
print(a_list)
# 追加列表
a_list.append(['a', 'b'])
print(a_list)

# extend()追加列表中的元素，而不是当做整体追加
print()
b_list = ['a', 30]
b_list.extend((-2, 3.2))
print(b_list)

b_list.extend(['C', 'R', 'A'])
print(b_list)

b_list.extend(range(97, 100))
print(b_list)

# insert()：指定元素插入列表中的位置
print()
c_list = list(range(1, 6))
print(c_list)
c_list.insert(3, 'CRAZY')
print(c_list)
c_list.insert(3, tuple('crazy'))
print(c_list)

# 删除元素
# del可以删除列表中的单个元素，也可以删除列表的中间一段
# remove()：根据元素本身来删除，只删除一个找到的元素
# clear()：清空列表的所有元素


# 修改类别，通过slice操作

# 列表的其他方法
# dir()：查看列表包含的所有方法
# count()：用于统计列表中某个元素出现的次数
# index()：用于判断某个元素在列表中出现的位置
# pop()：用户将列表当做栈使用，实现元素出栈功能
# reverse()：用于将列表中的元素反向存放
# sort()：用于对列表元素排序