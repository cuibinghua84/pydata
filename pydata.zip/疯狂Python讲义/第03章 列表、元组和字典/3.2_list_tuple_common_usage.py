# 通过索引使用元素
# a_tuple = ('Carl', 36, 9.8, 'fkit', -13)
# print(a_tuple[0])
# print(a_tuple[1])
# print(a_tuple[-1])
# print(a_tuple[-2])

# 子序列
# print(a_tuple[1:3])
# print(a_tuple[-3:-1])
# print(a_tuple[1:-2])

# print()
# b_tuple = (1, 2, 3, 4, 5, 6, 7, 8, 9)
# print(b_tuple[2: 8: 2])
# print(b_tuple[2: 8: 3])
# print(b_tuple[2: -2: 2])

# 加法
# 元组和列表不能相加
# sum_tuple = a_tuple + b_tuple
# print(sum_tuple)

# 乘法
# 将元素重复N次
# order_endings = ('st', 'nd', 'rd') + ('th',) * 17 + ('st', 'nd', 'rd') + ('th',) * 7 + ('st',)
# print(order_endings)
# day = input("请输入日期(1-32): ")
# day_int = int(day)
# print(day + order_endings[day_int - 1])

# in运算符


# 长度、最大值和最小值
# len()
# max()
# min()


# 序列封包和序列解包
# 程序把多个值赋给一个变量时，Python会自动将多个值封装成元组：序列封包
# 程序允许将序列（元组或列表等）直接赋值给多个变量，此时序列的各个元组会被依次赋值给每个变量（要求序列的元素个数和变量个数相等）：序列解包

# 序列封包：将10、20、30封装成元组后赋值给vals
vals = 10, 20, 30
print(vals)
print(type(vals))
print(vals[1])

# 序列解包：将a_tuple元组的各元素依次赋值给a, b, c, d, e
a_tuple = tuple(range(1, 10, 2))
print(a_tuple)
a, b, c, d, e = a_tuple
print(a, b, c, d, e)

# 序列解包
a_list = ['fkit', 'crazyit']
a_str, b_str = a_list
print(a_str, b_str)

# 序列解包，也可以只解出部分变量
print()
first, second, *rest = range(10)
print(first)
print(second)
print(rest)

*begin, last = range(10)
print(begin)
print(last)

first, *middle, last = range(10)
print(first)
print(middle)
print(last)