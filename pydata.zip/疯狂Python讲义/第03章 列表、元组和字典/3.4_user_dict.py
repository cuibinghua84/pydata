# 字典入门
# key-> value

# 创建字典
# 使用dict()创建字典或花括号创建字典
# scores = {'语文': 89, '数学': 92, '英语': 93}
# print(scores)

# empty_dict = {}
# print(empty_dict)

# dict2 = {(20, 30): 'good', 30: 'bad'}
# print(dict2)

# 传入多个列表或元组
print('\n传入多个列表或元组')
vegetables = [('celery', 1.58), ('brocoli', 1.29), ('lettuce', 2.19)]
dict3 = dict(vegetables)
print(dict3)
cars = [['BMW', 8.5], ['BENS', 8.3], ['AUDI', 7.9]]
dict4 = dict(cars)
print(dict4)

# 创建空字典
dict5 = dict()
print(dict5)

# dict关键字参数创建字典
dict6 = dict(spinach=1.39, cabbage=2.59)
print(dict6)

# 字典的基本方法
print('\n字典的基本方法')
print("字典相当于索引是任意不可变类型的列表；而列表则相当于key只能是整数的字典")
# 通过key进行访问、添加、删除、修改和判定
# 通过key访问value
scores = {'语文': 89}
print(scores['语文'])
# 通过key添加key-value对
scores['数学'] = 93
scores[92] = 5.7
print(scores)
# 通过key删除key-value对
del scores['语文']
print(scores)
del scores['数学']
print(scores)
# 通过key修改key-value对
cars = {'BMW': 8.5, 'BENS': 8.3, 'AUDI': 7.9}
print(cars)
cars['BENS'] = 4.3
cars['AUDI'] = 3.8
print(cars)
# 通过key判定指定key-value对是否存在
print('AUDI' in cars)
print('PORSCHE' in cars)
print('LAMBORGHINI' not in cars)


# 字典的常用方法
print('\ndict类的方法')
print(dir(dict))
"""
'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 
'pop', 'popitem', 'setdefault', 'update', 'values'
"""
# clear()：用于清空字典
print("\nclear()用于清空字典中的所有key-value对")
cars = {'BMW': 8.5, 'BENS': 8.3, 'AUDI': 7.9}
# print(cars)
# cars.clear()
# print(cars)

# get()：根据key获取value
print('\nget()根据key来获取value，如果key不存在时，该方法会简单地返回None')
print(cars.get('BMW'))
print(cars.get('PORSCHE'))
# print(cars['PORSCHE'])	# keyError

# update()：可使用一个字典所包含的key-value()来更新已有的字典
print('\nupdate()：可使用一个字典所包含的key-value()来更新已有的字典')
print(cars)
cars.update({'BMW': 4.5, 'PORSCHE': 9.3})
print(cars)

# items()：获取所有的key-value
# keys()：获取所有key
# values()：获取所有value
print("\nitems() keys() values()使用方法")
cars = {'BMW': 8.5, 'BENS': 8.3, 'AUDI': 7.9}
print(cars)
ims = cars.items()
print(ims)
print(type(ims))
print(list(ims))
print(list(ims)[1])
kys = cars.keys()
print(type(kys))
print(list(kys))
print(list(kys)[1])
vals = cars.values()
print(type(vals))
print(list(vals))
print(list(vals)[1])

# pop()：获取指定的key对应的value
print('\npop()方法用于获取指定可以对应的value，并删除这个key-value对')
print(cars)
print(cars.pop('AUDI'))
print(cars)

# popitem()：随机弹出字典的一个key-value对：
print('\npopitem()方法用于随机弹出字典中的一个key-value对')
cars = {'BMW': 8.5, 'BENS': 8.3, 'AUDI': 7.9}
print(cars)
print(cars.popitem())
print(cars)
print('\n实际上弹出的就是一个元组，可以进行序列解包')
k, v = cars.popitem()
print(k, v)

# setdefault()：根据key来获取对应的value值，如不存在时，会为key设置一个默认的value
print('\nsetdefault()：根据key来获取对应的value值，如不存在时，会为key设置一个默认的value')
cars = {'BMW': 8.5, 'BENS': 8.3, 'AUDI': 7.9}
print(cars.setdefault('PORSCHE', 9.2))
print(cars)
print(cars.setdefault('BMW', 3.4))
print(cars)

# fromkeys()：使用给定的多个key创建字典，这些key对应的value默认都是None
print("\nfromkeys()：使用给定的多个key创建字典，这些key对应的value默认都是None")
a_dict = dict.fromkeys(['a', 'b'])
print(a_dict)

b_dict = dict.fromkeys((13, 17))
print(b_dict)

c_dict = dict.fromkeys((13, 17), 'good')
print(c_dict)

# 使用字典格式化字符串
print("\n使用字典格式化字符串")
temp = '书名是：%(name)s，价格是：%(price)010.2f，出版社是：%(publish)s'
book = {'name': '疯狂Python讲义', 'price': 88.9, 'publish': '电子社'}
print(temp % book)
book = {'name': '疯狂Java讲义', 'price': 78.9, 'publish': '电子社'}
print(temp % book)