# 序列类型：字符串、列表和元组等

# 定义列表
my_list = ['carl', 36, 'Python']
# 定义元组
my_tuple = ('carl', 36, 'Python')
print(my_list)
print(my_tuple)