"""
发布Python程序
使用zipapp生成可执行的Python档案包
使用功能zipapp创建独立应用
安装PYInstaller模块
使用PyInstaller生成EXE程序
"""