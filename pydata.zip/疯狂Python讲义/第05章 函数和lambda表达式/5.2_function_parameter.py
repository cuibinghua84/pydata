# 关键字参数
print("关键字参数")


def girth(width, height):
    print("width: ", width)
    print("height: ", height)
    return 2 * (width + height)


# print(girth(3.5, 4.8))
# print(girth(width=3.5, height=4.8))
# print(girth(height=4.8, width=3.5))
# print(girth(3.5, height=4.8))

# 参数默认值
print("\n参数默认值")


# 关键词参数必须位于位置参数的后面
def say_hi(name="孙悟空", message="欢迎来到Python世界"):
    print(name, "，您好")
    print("消息是：", message)


# say_hi()
# say_hi("白骨精")
# say_hi("白骨精", "欢迎学习Python")
# say_hi(message="欢迎学习Python")

# 调用函数时关键字参数必须位于位置参数的后面
# 定义一个打印三角形的函数，有默认值的参数必须放在后面
def printTriangle(char, height=5):
    for i in range(1, height + 1):
        # 先打印一排空格
        for j in range(height - i):
            print(' ', end='')
        # 再打印一排特殊字符
        for j in range(2 * i - 1):
            print(char, end='')
        print()


# printTriangle('@', 6)
# printTriangle('#', height=7)
# printTriangle(char = '*')

print("\n收集多个参数，参数值被当做元组传入")


def test(a, *books):
    print(books)
    # books被当做元组处理
    for b in books:
        print(b)
    print(a)


# test(5, "疯狂IOS讲义", "疯狂Python讲义")

def test1(*books, num):
    print(books)
    for b in books:
        print(b)
    print(num)


# test1("疯狂Python讲义", "疯狂Java讲义", num=20)

def test2(x, y, z=3, *books, **scores):
    print(x, y, z)
    print(books)
    print(scores)


# test2(1, 2, 3, "疯狂Python讲义", "疯狂Java讲义", 语文=89, 数学=98)

print("\n逆向参数收集")
"""
指的是在程序已有列表、元组、字典等对象的前提下，把他们的元素“拆开”后传给函数的参数
逆向参数收集需要在传入的列表、元组参数之前添加一个星号，在字典参数之前添加两个星号
"""


def test3(name, message):
    print("用户是：", name)
    print("欢迎消息：", message)


# my_list = ['孙悟空', '欢迎学习Python']


# test3(*my_list)

def foo(name, *nums):
    print("name参数：", name)
    print("nums参数：", nums)


# my_tuple = (1, 2, 3)


# 使用逆向收集，将my_tuple元组的元素传给nums参数
# foo('fkit', *my_tuple)
# foo(*my_tuple)
# foo(my_tuple)


def bar(book, price, desc):
    print("这本书的名称是：", book, " 这本书的价格是：", price)
    print("描述信息", desc)


# my_dict = {'price': 89, 'book': '疯狂Python讲义', 'desc': '这是一本系统全面的Python学习图书'}
# bar(**my_dict)

print("\n函数的参数传递机制")
"""
Python中函数的参数传递机制都是“值传递”
值传递：就是将实际数值的副本传入函数，而参数本身不会受任何影响
"""


def swap(a, b):
    a, b = b, a
    print("在swap函数里，a的值是：", a, "; b的值是", b)


# a = 6
# b = 9
# swap(a, b)
# print("交换结束后，变量a的值是：", a, "; 变量b的值是", b)


def swap1(dw):
    dw['a'], dw['b'] = dw['b'], dw['a']
    print("在swap()函数里，a元素的值是", dw['a'], "; b元素的值是", dw['b'])


# dw = {'a': 6, 'b': 9}
# swap1(dw)
# print("交换结束后，a元素的值是", dw['a'], "; b元素的值是", dw['b'])

print("\n变量的作用域")
"""
根据定义变量的位置
	局部变量：在函数中定义的变量，包括参数，都被称为局部变量
	全局变量：在函数外面、全局范围内定义的变量，被称为全局变量
获取指定范围内的“变量字典”工具
	globals()：该函数返回全局范围内所有变量组成的“变量字典”
	locals()：该函数返回当前局部范围内所有变量组成的“变量字典”
	vars(object)：获取指定对象范围内所有变量组成的“变量字典”
"""


def locals_test():
    age = 20
    # 直接访问age局部变量
    print(age)

    # 访问函数局部范围内的“变量数组”
    print(locals())

    # 通过locals函数局部范围内的“变量数组”改变age变量的值
    print(locals()['age'])
    locals()['age'] = 12

    # 再次访问age变量的值
    print('xxx', age)

    # 通过globals函数修改x全局变量
    globals()['x'] = 19


x = 5
y = 20
# print(globals())

# 在全局范围内使用locals函数，访问的是全局变量的“数组变量”
# print(locals())

# 直接访问x全局变量
# print(x)

# 通过全局变量的“变量数组”访问x全局变量
# print(globals()['x'])

# 通过全局变量的“变量数组”对x全局变量赋值
# globals()['x'] = 39
# print(x)

# 在全局范围内使用locals函数对x全局变量赋值
# locals()['x'] = 99
# print(x)

# # 遮蔽全局变量
# 在函数内部对不存在的变量赋值时，默认就是重新定义新的局部变量
# 可通过globals()函数来实现
# name = 'Charlie'
# def test4():
#     print(globals()['name'])
#     name = "数据汇"
# test4()
# print(name)

print("\n在函数中声明全局变量")
name = 'Charlie'
def test5():
	# 声明name是全局变量，后面的赋值语句不会重新定义局部变量
	global name
	print(name)
	name = '孙悟空'
test5()
print(name)