# 定义函数

# 定义一个函数，声明两个参数
def my_max(x, y):
    '''
    获取两个数字之间较大的函数
    my_max(x. y)
        返回x、y两个参数之间较大的那个数
    '''
    # 定义一个变量z，该变量等于x、y中的较大值
    z = x if x > y else y
    # 返回变量z的值
    return z

# 定义一个函数，声明一个参数
def say_hi(name):
    print("===正在执行 say_hi()函数===")
    return name + ", 您好！ "

a = 6
b = 9

# # 调用my_max()函数，将函数返回值赋值给result变量
# result = my_max(a, b)
# print(result)
# # 调用say_hi()函数，直接输出函数的返回值
# print(say_hi("数据汇"))

# 为函数提供文档
# help(my_max)
# print(my_max.__doc__)

# 5.1.4 返回多个值
def sum_and_avg(list):
    sum = 0
    count = 0
    for e in list:
        # 如果元素e是数值
        if isinstance(e, int) or isinstance(e, float):
            count += 1
            sum += e
    return sum, sum / count

my_list = [20, 15, 2.8, 'a', 35, 5.9, -1.8]
# 获取sum_and_avg函数返回的多个值，多个返回值被封装成元组
# tp = sum_and_avg(my_list)
# print(tp)

# 使用序列解包来获取多个返回值
# s, avg = sum_and_avg(my_list)
# print(s)
# print(avg)


# 递归函数：在一个函数体内调用它自身
def fn(n):
    if n == 0:
        return 1
    elif n == 1:
        return 4
    else:
        # 在函数体中调用它自身，就是函数递归
        return 2 * fn(n - 1) + fn(n - 2)

print("fn(10)的结果是：", fn(10))