# -*- coding: utf-8 -*-
print("使用函数变量")


def pow(base, exponent):
    result = 1
    for i in range(1, exponent + 1):
        result *= base
    return result
# my_fun = pow
# print(my_fun(3, 4))


def area(width, height):
    return width * height
# my_fun = area
# print(my_fun(3, 4))


print("\n使用函数作为函数形参")
def map(data, fn):
    result = []
    for e in data:
        result.append(fn(e))
    return result

def square(n):
    return n * n

def cube(n):
    return n * n * n

def factorial(n):
    result = 1
    for index in range(2, n + 1):
        result *= index
    return result

# data = [3, 4, 9, 5, 8]
# print("原数据：", data)
# print("计算数组元素的平方")
# print(map(data, square))
# print("计算数组元素的立方")
# print(map(data, cube))
# print("计算数组元素的阶乘")
# print(map(data, factorial))


print("\n使用函数作为返回值")
def get_math_func(type):
    def square(n):
        return n * n

    def cube(n):
        return n * n * n

    def factorial(n):
        result = 1
        for index in range(2, n + 1):
            result *= index
        return result
    if type == "square":
        return square
    if type == "cube":
        return cube
    else:
        return factorial
math_func = get_math_func("cube")
print(math_func(5))
math_func = get_math_func("square")
print(math_func(5))
math_func = get_math_func("factorial")
print(math_func(5))


