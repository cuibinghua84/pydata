# -*- coding: utf-8 -*

print("使用lambda表达式来简化函数")
def get_math_func(type):
	result = 1
	if type == 'square':
		return lambda n: n * n
	elif type == 'cube':
		return lambda n: n * n * n
	else:
		return lambda n: (1 + n) * n / 2

math_func = get_math_func("cube")
print(math_func(5))
math_func = get_math_func("square")
print(math_func(5))
math_func = get_math_func("other")
print(math_func(5))

print("\nlambda表达式调用Python内部的map()函数")
x = map(lambda x: x * x, range(8))
print([e for e in x])
y = map(lambda x : x * x if x % 2 == 0 else 0, range(8))
print([e for e in y])