# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 12.3-方法链技术.py
@time: 2019/10/28 18:14
"""