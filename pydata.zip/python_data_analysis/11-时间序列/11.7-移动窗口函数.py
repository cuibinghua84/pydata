# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 11.7-移动窗口函数.py
@time: 2019/10/28 18:13
"""