# -*- coding: utf-8 -*-
"""
Created on Fri Nov 15 09:26:09 2019

@author: p_bhcui
"""

import pandas as pd
import requests

# 6.4 与数据库交互
