import numpy as np
from pprint import pprint

data = {i: np.random.randn() for i in range(7)}
pprint(data)
