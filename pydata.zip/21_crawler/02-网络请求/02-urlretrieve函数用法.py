# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/7/23 15:27
# 文件      : 2-urlretrieve函数用法.py
# IDE       : PyCharm

from urllib import request

# urlretrieve：可以方便的将网页上的一个文件保存到本地。以下代码可以非常方便的将网页首页下载到本地
# request.urlretrieve('http://guba.eastmoney.com/remenba.aspx?type=1', 'guba.txt')
request.urlretrieve('https://icweiliimg6.pstatp.com/weili/l/259288730514489536.webp', '11.jpg')
