# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/7/23 15:27
# 文件      : 3-参数编码和解码函数.py
# IDE       : PyCharm

from urllib import parse
from urllib import request

# 用浏览器发送请求的时候，如果url中包含了中文或者其他特殊字符，那么浏览器会自动的给我们进行编码。而如果使用代码发送请求
# 那么必须手动的进行编码，这时候就应该使用urlencode函数来实现。urlencode可以把字典数据转为URL编码
# data = {'name': '爬虫基础', 'greet': 'hello world', 'age': 35}
# qs = parse.urlencode(data)
# print(qs)

url = 'http://www.baidu.com/s'
params = {"wd": "刘德华"}
qs = parse.urlencode(params)
url = url + "?" + qs
resp = request.urlopen(url)
print(resp.read())


# parse_qs函数：可以将经过编码后的url参数进行解码
# qs1 = 'name=%E7%88%AC%E8%99%AB%E5%9F%BA%E7%A1%80&greet=hello+world&age=35'
# print(parse.parse_qs(qs1))

# urlparse和urlsplit

