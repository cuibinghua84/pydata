# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/7/23 15:28
# 文件      : 6-作业-内涵段子爬虫作业.py
# IDE       : PyCharm

from urllib import request

# 不使用代理
# url = 'http://httpbin.org/ip'
# res = request.urlopen(url)
# print(res.read())

# 使用代理
"""
note
ProxyHandler处理器（代理）
1. 代理的原理：在请求目的网站之前，先请求代理服务器，然后让代理服务器去请求目的网站，代理服务器拿到目的网站的数据后，再转发给我们的代码
2. http://httpbin.org：这个网站可以方便的查看http请求的一些参数
3. 在代码中使用代理
	* 使用urllib.request.ProxyHandler 传入一个代理，这个代理是一个字典，字典的key依赖于代理服务器能够接收的类型，一般是http 或者 https 值是：ip:port
	* 使用上一步创建的handler，以及request.build_opener 创建一个opener对象
	* 使用上一步创建的opener，调用open函数，发起请求

常用的代理有
西刺免费代理IP：http://www.xicidaili.com/
快代理：http://www.kuaidaili.com/
代理运：http://www.dailiyun.com/
"""

# 使用代理
url = 'http://httpbin.org/ip'
# 1.使用ProxyHandler传入代理构建一个handler
handler = request.ProxyHandler({'http': "123.206.30.254:808"})
# 2.使用上面创建的handler构建一个opener
opener = request.build_opener(handler)
# 3.使用opener去发送一个请求
res = opener.open(url)
print(res.read())
