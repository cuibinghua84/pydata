# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/7/23 15:28
# 文件      : 5-实战-用Request爬取拉勾网职位信息.py
# IDE       : PyCharm

from urllib import request, parse

# request.Request类
# 如果想要在请求的时候增加一些请求头，那么就必须使用request.Request类来实现

# url = 'http://guba.eastmoney.com/remenba.aspx?type=1'
# url = 'https://www.lagou.com/jobs/list_python?labelWords=&fromSearch=true&suginput='
url = "https://www.lagou.com/jobs/positionAjax.json?city=%E5%8C%97%E4%BA%AC&needAddtionalResult=false"


# resp = request.urlopen(url)
# print(resp.read())

headers = {
	'Host': 'www.lagou.com',
	'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
	'Referer': 'https://www.lagou.com/jobs/list_python?city=%E5%8C%97%E4%BA%AC&cl=false&fromSearch=true&labelWords=&suginput='
}

data = {
	'first': 'true',
	'pn': 1,
	'kd': 'python'
}

req = request.Request(url, headers=headers, data=parse.urlencode(data).encode('utf-8'), method='POST')
resp = request.urlopen(req)
print(resp.read().decode('utf-8'))


