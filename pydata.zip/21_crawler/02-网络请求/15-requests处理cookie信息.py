# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/7/23 15:29
# 文件      : 15-requests处理cookie信息.py
# IDE       : PyCharm

