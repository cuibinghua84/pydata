# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/7/23 15:30
# 文件      : 16-requests处理不信任的ssl证书.py
# IDE       : PyCharm

