# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/7/23 15:27
# 文件      : 1-urlopen函数用法.py
# IDE       : PyCharm

from urllib import request

# urllib是Python中一个基本的网络请求库。可以模拟浏览器的行为，向指定的服务器发送一个请求，并可以保存服务器返回的数据
# urllib库中，所有和网络请求相关的方法，都被集到urllib.requests模块下
'''
urlopen函数
url:请求的url
data：请求的data，如果设置了这个值，那么将变成post请求
返回值：返回值是一个http.client.HTTPResponse对象，这个对象是一个类文件句柄对象
有read(size) readline readlines以及getcode等方法
'''
resp = request.urlopen('http://guba.eastmoney.com/remenba.aspx?type=1')
# print(resp.read().decode('utf-8'))
# print(resp.readline().decode('utf-8'))
print(resp.readlines())
# print(resp.getcode())
