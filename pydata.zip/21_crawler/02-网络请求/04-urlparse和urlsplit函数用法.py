# -*- coding: utf-8 -*-
# 作者      : cuibinghua
# 创建时间  : 2019/7/23 15:28
# 文件      : 4-urlparse和urlsplit函数用法.py
# IDE       : PyCharm

from urllib import request, parse

# urlparse和urlsplit：想要对一个url中的各个部分进行分割，那么这时候就可以使用urlparse或者是urlsplit来进行分割，唯一不一样的地方，urlparse里面多了一个params属性，二urlsplit没有

url = 'http://www.baidu.com/s?username=cuidongfeng'

result = parse.urlsplit(url)
print(result)
# SplitResult(scheme='http', netloc='www.baidu.com', path='/s', query='username=cuidongfeng', fragment='')
"""
scheme:  http
netloc:  www.baidu.com
path:  /s
query:  username=cuidongfeng
"""

# result = parse.urlparse(url)
# print(result)
# ParseResult(scheme='http', netloc='www.baidu.com', path='/s', params='', query='username=cuidongfeng', fragment='')
# SplitResult(scheme='http', netloc='www.baidu.com', path='/s',            query='username=cuidongfeng', fragment='')
"""
scheme:  http
netloc:  www.baidu.com
path:  /s
query:  username=cuidongfeng
"""

print("scheme: ", result.scheme)
print("netloc: ", result.netloc)
print("path: ", result.path)
print("query: ", result.query)
print("fragment", result.fragment)
