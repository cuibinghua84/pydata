# -*- coding: utf-8 -*-
# 作者      : p_bhcui
# 创建时间  : 2019/9/5 15:27
# 文件      : rw_visual.py
# IDE       : PyCharm

import matplotlib.pyplot as plt
from random_walk import RandomWalk

rw = RandomWalk()
rw.fill_walk()
plt.scatter(rw.x_values, rw.y_values, s=15)
plt.show()