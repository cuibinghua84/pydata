# -*- coding: utf-8 -*-
# 作者      : p_bhcui
# 创建时间  : 2019/9/5 11:54
# 文件      : mpl_squares.py
# IDE       : PyCharm

# 绘制简单的折线图
import matplotlib.pyplot as plt

# 同时提供输入值和输出值
input_values = [1, 2, 3, 4, 5]
squares = [1, 4, 9, 16, 25]
# squares = [square ** 2 for square in range(1, 1000)]
# print(squares)
plt.plot(input_values, squares, linewidth=5)   # plot()绘制图形 设定线条的粗细

# 设置图表标题，并给坐标轴加上标签
plt.title("Square Numbers", fontsize=24)    # title() 指定标题，
plt.xlabel("Value", fontsize=14)
plt.ylabel("Square of Value", fontsize=14)

# 设置刻度标记的大小
plt.tick_params(axis='both', labelsize=14)


plt.show()  # plt.show()打开matplotlib查看器
