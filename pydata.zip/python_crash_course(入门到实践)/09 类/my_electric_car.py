# 在一个模块中存储多个类
from car import ElectriCar

my_tesla = ElectriCar('tesla', 'model s', 2020)
print(my_tesla.get_descriptive_name())
my_tesla.battery.describe_battery()
my_tesla.battery.get_range()