alien_color = 'red'

if alien_color == 'green':
    print("The player gains 5 points.")

alien_color = 'green'
if alien_color == 'green':
    print("The player gains 5 points.")