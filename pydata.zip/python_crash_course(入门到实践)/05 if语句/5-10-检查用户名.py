current_users = ['cuibinghua', 'admin', 'root', 'python', 'data_pool']

new_users = ['Python', 'java', 'go', 'data_pool', 'sql']

for new_user in new_users:
    if new_user.lower() in current_users:
        print(new_user + " 用户名已被使用")
    else:
        print(new_user + " 可以使用")