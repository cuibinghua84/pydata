alien_color = 'red'

if alien_color == 'green':
    print("5 points")
elif alien_color == 'yellow':
    print("10 points")
else:
    print("15 points")