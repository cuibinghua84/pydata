print("abc" == "adc")
print("abc" != "adc")

str1 = "Abc"
str2 = "abc"
print(str1.lower() == str2.lower())

num1 = 39
num2 = 42
print(num1 == num2)
print(num1 != num2)
print(num1 > num2)
print(num1 < num2)
print(num1 >= num2)
print(num1 <= num2)

age1 = 36 
age2 = 40
print(age1 >= 36 and age2 >= 40)
print(age1 < 36 or age2 >= 40)

str_list = ['python', 'sql', 'r', 'java']
print('python' in str_list)
print('php' not in str_list)

