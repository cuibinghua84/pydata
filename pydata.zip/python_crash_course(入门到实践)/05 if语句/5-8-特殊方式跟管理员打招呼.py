users = ['cbh', 'root', 'admin0', 'admin', 'cuibinghua']

for user in users:
    if user == 'admin':
        print("Hello " + user + ", would you like to see a status report?")
    else:
        print("Welcome to " + user.title() + ", thank you logging in again.")
