# 5.1 一个简单示例
print("一个简单示例")
cars = ['audi', 'bmw', 'subaru', 'toyota']
for car in cars:
	if car == 'bmw':
		print(car.upper())
	else:
		print(car.title())


# 5.2 条件测试
print()
print("条件测试")
# 检查是否相等 ==；是否相等且不考虑大小写lower()
# 检查是否不相等 !=
requested_topping = 'mushrooms'
if requested_topping != 'anchovies':
	print("Hold the anchovies!")

# 比较数字
answer = 36
if answer != 42:
	print("That is not the correct answer. Please try angin!")

# 检查多个条件 and 或 or
# 检查特定值是否包含在列表中 in 
# 检查特定值是否不包含在列表中 not in
print()
banned_users = ['andrew', 'carolina', 'david']
user = 'marie'
if user not in banned_users:
	print(user.title() + ", you can post a response if you wish")

print()
# 布尔表达式：True False


# 5.3 if语句
age = 36
if age >= 30:
	print("Your are old enough to vote!")
	print("Hava you registered to vote yet?")

print("\nif-else")
age = 36
if age >= 40:
	print("You are old enough to vote!")
	print("Have you registered to vote yet?")
else:
	print("Sorry, you are too young to vote")
	print("Please register to vote as soon as you turn 40!")

print("\nif-elif-else")
age = 12
if age < 4:
	print("Your admission cost is $0.")
elif age < 18:
	print("Your admission cost is $5.")
else:
	print("Your admission cost is $10.")

print("\n优化")
age = 12
if age < 4:
	price = 0
elif age < 18:
	price = 5
elif age < 65:
	price = 10
else:
	price = 5
print("Your admission cost is $" + str(price) + ".")

print("\n再次优化")
age = 12
if age < 4:
	price = 0
elif age < 18:
	price = 5
elif age < 65:
	price = 5
elif age >= 65:
	price = 5
print("Your admission cost is $" + str(price) + ".")

print("\n测试多个条件")
requested_topping = ['mushrooms', 'extra cheese']
if 'mushrooms' in requested_topping:
	print("Adding mushrooms.")
if 'pepperoni' in requested_topping:
	print("Adding pepperoni.")
if 'extra cheese' in requested_topping:
	print("Adding extra cheese.")
print("\nFinished making your pizza!")


# 5.4 使用if语句处理列表
print("\n检查特殊元素")
requested_toppings = ['mushrooms', 'green peppers', 'extra cheese']
for requested_topping in requested_toppings:
	if requested_topping == 'green peppers':
		print("Sorry, we are out of green peppers right now.")
	else:
		print("Adding " + requested_topping + ".")
print("\nFinished making your pizza!")

print("\n确定列表不是空的")
requested_toppings = []
if requested_toppings:
	for requested_topping in requested_toppings:
		print("Adding " + requested_topping + ".")
	print("\nFinished making your pizza!")
else:
	print("Are you sure you want a plain pizza?")

print("\n使用多个列表")
print("制作比萨")
available_toppins = ['mushrooms', 'olives', 'green peppers', 'pepperoni', 'pineapple', 'extra cheese']
requested_toppings = ['mushrooms', 'french fries', 'extra cheese']

for requested_topping in requested_toppings:
	# print("Adding " + requested_topping + ".")
	if requested_topping in available_toppins:
		print("Adding " + requested_topping + ".")
	else:
		print("Sorry, we don't have " + requested_topping + ".")
print("\nFinished making your pizza!")

# 5.5 设置if语句的格式