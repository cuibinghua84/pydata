alien_color = 'red'

if alien_color == 'green':
    print("5 points")
else:
    print("10 points")