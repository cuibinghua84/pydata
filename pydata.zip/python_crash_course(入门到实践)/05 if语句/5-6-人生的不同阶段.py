age = 36

if age < 2:
    print("婴儿")
elif 2 <= age < 4:
    print("蹒跚学步")
elif 4 <= age < 13:
    print("儿童")
elif 13 <= age < 20:
    print("青少年")
elif 20 <= age < 65:
    print("成年人")
elif age >= 65:
    print("老年人")
else:
    print("年龄对吗？")