favorite_fruits = ['apple', 'watermelon', 'orange', 'pear', 'cherry', 'banana']

if 'banana' in favorite_fruits:
    print("You really like banana." )

if 'guava' in favorite_fruits:
    print("You really like guava.")