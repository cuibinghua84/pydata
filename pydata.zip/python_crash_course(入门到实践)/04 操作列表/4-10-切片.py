languages = ['python', 'go', 'sql', 'java', 'r']
# print("The first three items in the list are: ")

# 前三个元素
for language in languages[0:3]:
    print(language)

# 中间三个元素
print()
for language in languages[1:4]:
	print(language)

# 后三个元素
print()
for language in languages[-3:]:
    print(language)
 