# numbers = list(range(1, 11))
squares = [value ** 2 for value in range(1, 11)]
print(squares)

print(list(numbers ** 3 for numbers in range(1, 11)))

values = [numbers ** 3 for numbers in range(1, 11)]
print(values)