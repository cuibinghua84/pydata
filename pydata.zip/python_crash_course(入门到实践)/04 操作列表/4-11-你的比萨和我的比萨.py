pizzas = ['new york style', 'chicago style', 'pan pizza']

friend_pizzas = pizzas[:]

print(pizzas)
print(friend_pizzas)

pizzas.append("add pizza")
friend_pizzas.append("friend add pizza")

print(pizzas)
print(friend_pizzas)

for pizza in pizzas:
    print("My favorite pizzas are:", pizza)

for friend_pizza in friend_pizzas:
    print("My friend's favorite pizzas are: ", friend_pizza)