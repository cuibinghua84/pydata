pizzas = ['new york style', 'chicago style', 'pan pizza']

for pizza in pizzas:
	print("I like", pizza)
print("I really love pizza!")