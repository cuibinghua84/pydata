animals = ['sporting dogs', 'working dogs', 'non-sporting dogs']

for animal in animals:
	print(animal)
	print("A dog would make a great pet\n")
print("Any of these animals would make a great pet!")