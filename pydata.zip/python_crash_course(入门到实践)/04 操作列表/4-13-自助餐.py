foods = ('beef', 'chicken', 'pork', 'mutton', 'fillet', 'tendon')

for food in foods:
    print(food)

foods = ('beef', 'chicken', 'pork', 'mutton', 'fillet', 'tendon', 'speck', 'lamb')

for food in foods:
    print(food)