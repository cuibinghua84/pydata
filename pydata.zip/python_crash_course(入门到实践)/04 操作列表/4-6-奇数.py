numbers = list(range(1, 21, 2))
for number in numbers:
	print(number)
