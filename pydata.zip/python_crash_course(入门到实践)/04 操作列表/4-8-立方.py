numbers = list(range(1, 11))
for number in numbers:
	value = number ** 3
	print(value)
# print(numbers)