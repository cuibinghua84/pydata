numbers = list(range(3, 31, 3))
for number in numbers:
	print(number)
print(numbers)