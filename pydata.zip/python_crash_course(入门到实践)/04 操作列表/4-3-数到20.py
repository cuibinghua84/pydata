for numbers in range(1, 21):
	print(numbers)