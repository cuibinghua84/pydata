# 4.1 遍历整个列表
magicians = ['alice', 'david', 'carolina']
# for magician in magicians:
# 	print(magician.title() + ', that was a great trick!')
# 	print("I can't wait to see you next trick, " + magician.title() + ".\n")
# print("Thank you, everyone. That was a great magic show!")

# 4.2 避免缩进错误

# 4.3 创建数值列表
# 使用range()生成数字
# for value in range(1, 5):
# 	print(value)

# 使用range()创建数字列表
# numbers = list(range(1, 21, 2))
# print(numbers)

# 将前10个数的平方加入到列表中
# squares = []
# for value in range(1, 11):
# 	# print(value)
# 	# square = value ** 2
# 	# squares.append(square)
# 	squares.append(value ** 2)
# print(squares)

# 对数字列表执行简单的统计计算
digits = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
# print(max(digits))
# print(min(digits))
# print(len(digits))

# 列表解析：将for循环和创建新元素的代码合并成一行，并自动附加新元素
# squares = [value ** 2 for value in range(1, 11)]
# print(squares)


# 4.4 使用列表的一部分
players = ['charles', 'martina', 'michael', 'florence', 'eli']

# 切片
print("切片")
print(players[0:3])
print(players[1:4])
print(players[:4])
print(players[2:])
print(players[-3:])
print()

# 遍历切片
print("遍历切片")
print("Here are the first three players on my team:")
for player in players[:3]:
	print(player)
print()

# 复制列表
print("复制列表")
my_foods = ['pizza', 'falafel', 'carrot cake']
friend_foods = my_foods[:]

my_foods.append('cannoli')
friend_foods.append('ice cream')

print("My favorite foods are: ")
print(my_foods)
print("\nMy friend's favorite foods are: ")
print(friend_foods)


# 4.5 元组
print()
print("元组")
dimensions = (200, 50)
print(dimensions[0])
print(dimensions[1])

# 遍历元组中的所有值
for dimension in dimensions:
	print(dimension)

# 修改元组的变量
print()
print("修改元组的变量")
print("Original dimensions:")
for dimension in dimensions:
	print(dimension)

dimensions = (400, 100)
print("\nModified dimensions:")
for dimension in dimensions:
	print(dimension)


# 4.6 设置代码格式
