address = ['shanghai', 'chongqing', 'xizang', 'qinghai', 'sanya']
print(address)
# print(sorted(address))
# print(sorted(address, reverse=True))
# print(address)

# address.reverse()
# print(address)
# address.reverse()
# print(address)

# address.sort()
# print(address)

address.sort(reverse=True)
print(address)
