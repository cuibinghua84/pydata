# 3.1 列表是什么
bicycles = ['trek', 'cannondale', 'redline', 'specialized']
# print(bicycles)
# print(bicycles[0].title())
# print(bicycles[-1])

# print()
# message = "My first bicycles was a " + bicycles[0].title() + "."
# print(message)

# 3.2 修改、添加和删除元素
# print()
# 修改列表
motorcycles = ['honda', 'yamaha', 'suzuki', 'ducati']
# motorcycles[0] = 'ducati'
# print(motorcycles)

# 添加元素
# 在列表末尾添加元素 append()
print()
# print(motorcycles)
# motorcycles.append('ducati')
# print(motorcycles)

motorcycles1 = []
motorcycles1.append('honda')
motorcycles1.append('yamaha')
motorcycles1.append('suzuki')
# print(motorcycles1)

# 在列表中插入元素 insert()
# motorcycles.insert(0, 'ducati')
# print(motorcycles)

# 从列表中删除元素
# del语句删除元素
# print(motorcycles)
# del motorcycles[0]
# del motorcycles[1]
# print(motorcycles)

# pop()删除元素：可删除列表末尾元素，并让你能够接着使用它
# popped_motorcycles = motorcycles.pop()
# print(motorcycles)
# print(popped_motorcycles)

# last_owned = motorcycles.pop()
# print("The last motorcycle I owned was a " + last_owned.title() + ".")

# 弹出列表中任何位置的元素
# first_owned = motorcycles.pop(0)
# print(first_owned)

# 根据值删除元素：remove()
# motorcycles.remove('ducati')
# print(motorcycles)


# too_expensive = 'ducati'
# motorcycles.remove(too_expensive)
# print(motorcycles)
# print("\nA " + too_expensive.title() + " is too expensive for me.")

# 3.3 组织列表
# sort()对列表进行永久性排序
print()
cars = ['bmw', 'audi', 'toyota', 'subaru']
print(cars)
# cars.sort()
# print(cars)

cars.sort(reverse=True)
print(cars)

# 3.4 使用列表时避免索引错误

# 3.5 小结

