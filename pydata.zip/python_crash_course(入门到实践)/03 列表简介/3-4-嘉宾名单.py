names = ['zs', 'ls', 'ww']
message = "to have dinner"
print("I and " +  names[0] + " " + message)
print("I and " +  names[1] + " " + message)
print("I and " +  names[2] + " " + message)

