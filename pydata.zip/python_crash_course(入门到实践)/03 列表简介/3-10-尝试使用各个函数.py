languages = ['python', 'sql', 'java', 'r', 'awk']
# print(languages)
# print(languages[0])
# print(languages[0].title())

# languages[-1] = 'go'

languages.append('go')
languages.insert(0, 'php')

# del languages[0]
print(languages)

# popped_languages = languages.pop()
# print(popped_languages)

# popped = languages.remove('sql')
# print(popped)
# print(languages)

# languages.sort()

# print(sorted(languages))
# print(languages)


languages.reverse()
print(languages)

print(len(languages))