names = ['zs', 'ls', 'ww']
message = "to have dinner"
print("I and " +  names[0].title() + " " + message)
print("I and " +  names[1].title() + " " + message)
print("I and " +  names[2].title() + " " + message)

print(names[-1].title() + " can't make dinner")

names[-1] = 'aaa'
print(names)

print("I and " + names[0].title() + " " + message)
print("I and " + names[1].title() + " " + message)
print("I and " + names[2].title() + " " + message)

