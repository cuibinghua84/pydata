names = ['zs', 'ls', 'ww']
message = "to have dinner"
names[-1] = 'aaa'

names.insert(0, 'bbb')
names.insert(2, 'ccc')
names.append('ddd')

print("I and " + names[0].title() + " " + message)
print("I and " + names[1].title() + " " + message)
print("I and " + names[2].title() + " " + message)
print("I and " + names[3].title() + " " + message)
print("I and " + names[4].title() + " " + message)
print("I and " + names[5].title() + " " + message)
print(names)

print("Only a soul guest can have lunch")

messages = "I'm sorry I can't have dinner with "
popped_name = names.pop()
print(messages + popped_name)
print(names)

popped_name = names.pop()
print(messages + popped_name)
print(names)

popped_name = names.pop()
print(messages + popped_name)
print(names)

popped_name = names.pop()
print(messages + popped_name)
print(names)

print("I and " + names[0].title() + " " + message)
print("I and " + names[1].title() + " " + message)

del names[0]
del names[0]
print(names)