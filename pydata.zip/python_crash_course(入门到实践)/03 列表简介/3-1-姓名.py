names = ['cui', "li", "xia"]
print(names[0])
print(names[1])
print(names[2])

