names = ['cui', "li", "xia"]
message = "Hello, python"
print(names[0] + " " + message)
print(names[1] + " " + message)
print(names[2] + " " + message)