names = ['cui', "li", "xia"]
bicycles = ['trek', 'cannondale', 'redline', 'specialized']
print(names[0] + " would like to own a " + bicycles[0].title())
print(names[1] + " would like to own a " + bicycles[1].title())
print(names[2] + " would like to own a " + bicycles[2].title())