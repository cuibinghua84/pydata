name = ['zs', 'ls', 'ww']

names = ['zs', 'ls', 'ww']
message = "to have dinner"
names[-1] = 'aaa'

names.insert(0, 'bbb')
names.insert(2, 'ccc')
names.append('ddd')

print(names)


print(len(name))
print(len(names))
