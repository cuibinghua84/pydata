messages = "Hello, Cui Python"
print(messages)