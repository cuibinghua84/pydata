messages = "Hello, Python "
name = 'Cui'
print(messages + name)