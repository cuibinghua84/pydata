# 2.1 运行hello_world.py时发生的情况

# 2.2 变量
# Python关键字


# 2.3 字符串
# 修改每个单词首字母大写
name = 'ada loveLACE'
print(name.title())

# 字母全部变为大写
print(name.upper())
# 字母全部变为小写
print(name.lower())
print()
# 拼接字符串
first_name = "ada"
last_name = "lovelace"
full_name = first_name + " " +last_name	# 拼接字符串
message = "Hello, " + full_name.title() + "!"
print(message)

print()
# 使用制表符或换行符来添加空白
print("\tPython之禅")
print("Languages:\n\tPython\n\tC\n\tJavaScript")

print()
# 删除空白
favorite_language = ' python '
print(favorite_language.rstrip())
print(favorite_language.lstrip())
print(favorite_language.strip())

print()
# 2.4 数字
# 使用函数str()避免类型错误
age = 36
message = "Happy " + str(age) + "rd Birthday!"
print(message)

# 2.5 注释


# 2.6 Python之禅
import this


# 2.7 小结

