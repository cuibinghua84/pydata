number = 888
print("I love number " + str(number))