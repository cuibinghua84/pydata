name = "cui dong feng"

message = "Hello " + name.title() + ", would you like to learn som Python today?"
print(message)