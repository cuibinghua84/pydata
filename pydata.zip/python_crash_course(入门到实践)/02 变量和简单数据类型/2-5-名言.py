name = "Alber Einstein"
message = "A person who never made a mistake never tried anything new."

print(name + "," + "\"" + message + "\"")