print(4 + 4)
print(10 - 2)
print(4 * 2)
print(int(16 / 2))