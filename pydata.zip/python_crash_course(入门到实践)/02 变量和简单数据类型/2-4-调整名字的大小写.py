name = "cui Dong FENG"

print(name.lower())
print(name.upper())
print(name.title())