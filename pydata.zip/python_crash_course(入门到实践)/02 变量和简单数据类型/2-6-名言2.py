famous_person = "Alber Einstein"
message = "A person who never made a mistake never tried anything new."
messages = famous_person + "," +"\"" + message + "\""
print(messages)
