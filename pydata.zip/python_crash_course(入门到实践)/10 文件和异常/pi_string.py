# filename = 'pi_digits.txt'

# with open(filename) as file_object:
# 	lines = file_object.readlines()

# pi_string = ""
# for line in lines:
# 	pi_string += line.strip()

# print(pi_string)
# print(len(pi_string))

# 一百万的大型文件
# filename = 'pi_million_digits.txt'

# with open(filename) as file_object:
# 	lines = file_object.readlines()

# pi_string = ''
# for line in lines:
# 	pi_string += line.strip()
# print(pi_string[:100] + "... ...")
# print(len(pi_string))

# 圆周率中包含你的生日吗
filename = 'pi_million_digits.txt'

with open(filename) as file_object:
	lines = file_object.readlines()
pi_string = ''
for line in lines:
	pi_string += line
birthday = input("Enter your birthday, in the form mmddyy: ")
if birthday in pi_string:
	print("Your birthday appers in the first million digits of pi!")
else:
	print("Your birthday does not appers in the first million digits of pi.")