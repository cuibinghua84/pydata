filename = 'pi_digits.txt'
with open(filename) as file_object:
    # contents = file_object.read()
    # print(contents.rstrip())

    # 逐行读取
    for line in file_object:
    	print(line.rstrip())


# 创建包含内容的列表
line_lists =[]
with open(filename) as file_object:
	lines = file_object.readlines()
	print(lines)
for line in lines:
	print(line.rstrip())
	line_lists.append(line.rstrip())
print(line_lists)

