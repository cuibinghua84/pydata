# 8.1 定义函数
print("定义函数")
def greet_user(username):
	print("Hello! " + username.title() + "!")

greet_user('jesse')

# 8.2 传递参数
print("\n位置实参")
def describe_pet(animal_type, pet_name):
	print("I have a " + animal_type + ".")
	print("My " + animal_type + "'s name is " + pet_name.title() + ".")
describe_pet('hamster', 'harry')

print("\n调用函数多次")
describe_pet('dog', 'willie')

print("\n位置实参的顺序很重要")
describe_pet('harry', 'hamster')

print("\n关键字参数")
describe_pet(animal_type='hamster', pet_name='harry')

print("\n默认值")
print("使用默认值时，在形参列表中必须先列出没有默认值的形参，再列出有默认值的形参")
def describe_pet_default(pet_name, animal_type='dog'):
	print("I have a " + animal_type + ".")
	print("My " + animal_type + "'s name is " + pet_name.title() + ".")
describe_pet_default(pet_name='willie')

print("\n等效调用")
describe_pet_default('willie')
describe_pet_default(pet_name='willie')
describe_pet_default('harry', 'hamster')
describe_pet_default(pet_name='harry', animal_type='hamster')
describe_pet_default(animal_type='hamster', pet_name='harry')

# 8.3 返回值
print("\n返回简单值")
def get_formatted_name(first_name, last_name):
	full_name = first_name + ' ' + last_name
	return full_name.title()
musician = get_formatted_name('jimi', 'hendrix')
print(musician)

print("\n让实参变成可选的")
def get_formatted_name_choosable(first_name, middle_name, last_name):
	full_name = first_name + ' ' + middle_name + ' ' + last_name
	return full_name.title()
musician = get_formatted_name_choosable('john', 'lee', 'hooker')
print(musician)

print("\n指定默认值")
def get_formatted_name_choosable_default(first_name, last_name, middle_name=''):
	if middle_name:
		full_name = first_name + ' ' + middle_name + ' ' + last_name
	else:
		full_name = first_name + ' ' + last_name

	return full_name.title()
musician = get_formatted_name_choosable_default('jimi', 'hendrix')
print(musician)
musician = get_formatted_name_choosable_default('john', 'hooker', 'lee')
print(musician)

print("\n返回字典")
def build_person(first_name, last_name):
	person = {'first': first_name, 'last': last_name}
	return person
musician = build_person('jimi', 'hendrix')
print(musician)

print("\n返回字典，可选值")
def build_person_choosable(first_name, last_name, age=''):
	person = {'first': first_name, 'last': last_name}
	if age:
		person['age'] = age
	return person
musician = build_person_choosable('jimi', 'hendrix', age=36)
print(musician)

print("\n结合使用函数和while循环")
def get_formatted_name_while(first_name, last_name):
	full_name = first_name + ' ' + last_name
	return full_name.title()
# while True:
# 	print("\nPlease tell me your name: ")
# 	print("(enter 'q' at any time to quit)")
# 	f_name = input("First name: ")
# 	if f_name == 'q':
# 		break
# 	l_name = input("Last name: ")
# 	if l_name == 'q':
# 		break
# 	formatted_name = get_formatted_name_while(f_name, l_name)
# 	print("\nHello, " + formatted_name + "!")

# 8.4 传递列表
print("\n传递列表")
def greet_users(names):
	for name in names:
		msg = 'Hello, ' + name.title() + "!"
		print(msg)
username = ['hannah', 'ty', 'margot']
greet_users(username)

print("\n在函数中修改列表")
print("不使用函数模拟3D打印模型")
unprinted_designs = ['iphone case', 'robot pendant', 'dodecahedron']
completed_models = []
while unprinted_designs:
	current_design = unprinted_designs.pop()
	print("Printing model: " + current_design)
	completed_models.append(current_design)
print("\nThe following models have been printed: ")
for completed_model in completed_models:
	print(completed_model)

print("使用2函数模拟3D打印模型")
def print_models(unprinted_designs, completed_models):
	while unprinted_designs:
		current_design = unprinted_designs.pop()
		print("Printing model: " + current_design)
		completed_models.append(current_design)

def show_completed_models(completed_models):
	print("\nThe following models have been printed: ")
	for completed_model in completed_models:
		print(completed_model)
unprinted_designs = ['iphone', 'robot pendant', 'dodecahedron']
completed_models = []
print_models(unprinted_designs, completed_models)
show_completed_models(completed_models)

# 8.5 传递任意数量的实参
print("\n传递任意数量的实参")
def make_pizza(*toppings):
	print(toppings)
make_pizza('pepperoni')
make_pizza('mushrooms', 'green peppers', 'extra cheese')

print("\n描述顾客点的披萨")
def make_pizza_describe(*toppings):
	print("Making a pizza with the following toppings: ")
	for topping in toppings:
		print('- ' + topping)
make_pizza_describe('pepperoni')
make_pizza_describe('mushrooms', 'green peppers', 'extra cheese')

print("\n结合使用位置实参和任意数量实参")
def make_pizz_unite(size, *toppings):
	print("\nMaking a " + str(size) + "-inch pizza with the following toppings: ")
	for topping in toppings:
		print("- " + topping)
make_pizz_unite(16, 'pepperoni')
make_pizz_unite(12, 'mushrooms', 'green peppers', 'extra cheese')

print("\n任意数量的关键字实参")
def build_profile(first, last, **user_info):
	profile = {}
	profile['first_name'] = first
	profile['last_name'] = last
	for key, value in user_info.items():
		profile[key] = value
	return profile

user_profile = build_profile('albert', 'einstein', location='princeton', field='physics')
print(user_profile)

# 8.6 将函数存储在模块中

# 8.7 函数编写指南
