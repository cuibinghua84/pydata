def favorite_book(title):
	print("One of favorite book is " + title.title())

favorite_book('alice in wonderland')