def make_shirt():
	