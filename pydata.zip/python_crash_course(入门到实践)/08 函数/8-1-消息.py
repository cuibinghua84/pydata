def display_message():
	print("我在努力学习Python。")


display_message()