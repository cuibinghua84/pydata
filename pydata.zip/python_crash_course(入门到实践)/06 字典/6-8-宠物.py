pet1 = {
    'type': 'dog1',
    'master': 'user1'
}

pet2 = {
    'type': 'dog2',
    'master': 'user2'
}

pet3 = {
    'type': 'dog3',
    'master': 'user3'
}

pets = [pet1, pet2, pet3]

for pet in pets:
	for key, value in pet.items():
		print(key, value)
    