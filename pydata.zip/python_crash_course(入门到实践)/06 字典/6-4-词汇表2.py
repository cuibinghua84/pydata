terms = {
    'interpret': '逐句翻译高级语言编写的源程序，边翻译边执行',
    'compile': '一次性把高级语言翻译成二进制指令序列，形成目标代码',
    'syntax': '程序的结构',
    'semantics': '程序的语义',
    'parse': '检查一个程序，并分析其语法结构',
    'function': '一些列命名并且完成某种功能的语句',
    'parameter': '调用函数时所需要的信息',
    'argument': '当调用函数时所必须提供的数值，这个值必须与函数中对应的形参具有相同的类型',
    'debugging': '发现并解释三种错误的过程',
    'concatenate': '将两个操作数首相接',
}

for key, value in terms.items():
    print(key + ":" + value)
    # print(key)
    # print("\t", value)