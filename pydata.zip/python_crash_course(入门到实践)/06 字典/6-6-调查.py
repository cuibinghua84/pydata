favorite_languages = {
    'jen': 'python',
    'sarah': 'c',
    'edward': 'ruby',
    'phil': 'python',
    'df': 'python',
}

survey_users = ['jen', 'jik', 'li', 'df']

for name in favorite_languages.keys():
	if name in survey_users:
		print("十分感谢" + name.title() + " 参与调查")
	else:
		print(name + " 您还未参与调查。")


