favorite_places = {
	'wang': ['beijing', 'shanghai'],
	'zhang': ['tianjin', 'beijing', 'kunming'],
	'hua': ['chengdu', 'dali', 'hangzhou']	
}

for favorite_place_key, favorite_place_values in favorite_places.items():
	print("\n" + favorite_place_key.title() + "'s love city:")
	for favorite_place_value in favorite_place_values:
		print("\t" + favorite_place_value.title())