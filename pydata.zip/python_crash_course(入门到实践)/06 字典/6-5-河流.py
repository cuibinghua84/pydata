rivers = {
    'nile': 'egypt',
    'Yangtze': 'china',
    'Amazon': 'Brazil'
}

for key, value in rivers.items():
    print("The " + key.title() + " runs through " + value.title() + ".")

print()
for key in rivers.keys():
    print(key)
print()
for value in rivers.values():
    print(value)