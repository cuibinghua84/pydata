person1 = {
    'first_name': 'cui1',
    'last_name': 'binghua1',
    'age': '36',
    'city': 'beijing_1',
}

person2 = {
    'first_name': 'cui2',
    'last_name': 'binghua2',
    'age': '37',
    'city': 'beijing_2',
}

person3 = {
    'first_name': 'cui3',
    'last_name': 'binghua3',
    'age': '38',
    'city': 'beijing_3',
}

peoples = [person1, person2, person3]
for people in peoples:
    for key, value in people.items():
        print(key, value)
    