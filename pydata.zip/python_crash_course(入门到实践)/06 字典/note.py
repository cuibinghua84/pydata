
# 6.1 一个简单的字典
# alien_0 = {'color': 'green', 'points': 5}
# print(alien_0['color'])
# print(alien_0['points'])

# 6.2 使用字典
# new_points = alien_0['points']
# print("You just earned " + str(new_points) + " points!")

# print(alien_0)
# alien_0['x_position'] = 0
# alien_0['y_poistion'] = 25
# print(alien_0)

# alien_1 = {}
# alien_1['color'] = 'green'
# alien_1['points'] = 5

# print(alien_1)

# print("The alien is " +alien_0['color'] + ".")
# alien_0['color'] = 'yellow'
# print("The alien is now " + alien_0['color'] + ".")

print("对一个能够以不同速度移动的外星人的位置进行跟踪")
alien_0 = {'color': 'green',  'points': 5, 'x_position': 0, 'y_position': 25, 'speed': 'medium'}
print("Original x-position: " + str(alien_0['x_position']))

# 向右移动外星人
# 据外星人当前速度决定将其移动多远
if alien_0['speed'] == 'slow':
	x_increment = 1
elif alien_0['speed'] == 'medium':
	x_increment = 2
else:
	# 这个外星人的属地一定很快
	x_increment = 3

# 新位置等于老位置加上增量
alien_0['x_position'] = alien_0['x_position'] + x_increment
print("New x-position: " + str(alien_0['x_position']))

# 删除键值对
print("\n删除键值对")
print(alien_0)
del alien_0['points']
print(alien_0)

print("\n由类似对象组成的字典")
favorite_languages = {
	'jen': 'python',
	'sarah': 'c',
	'edward': 'ruby',
	'phil': 'python',
}
print("Sarah's favorite languages is " + favorite_languages['sarah'].title() + ".")

# 6.3 遍历字典
print("\n遍历所有的键值对")
user_0 = {
	'username': 'efermi',
	'first': 'enrico',
	'last': 'fermi'
}
# for key, value in user_0.items():
# 	print("\nKey: " + key)
# 	print("Value: " + value)

for name, language in favorite_languages.items():
	print(name.title() + "'s favorite language is " + language.title() + ".")

print("\n遍历字典中的所有键")
for name in favorite_languages.keys():
	print(name)

print("\n通过键来访问与之相关联的值")
friends = ['phil', 'sarah']
for name in favorite_languages.keys():
	print(name.title())

	if name in friends:
		print("  Hi  " + name.title() + ", I see your favorite language is " + favorite_languages[name].title() + "!")

print("\n使用keys()对某人进行调查")
if 'erin' not in favorite_languages.keys():
	print("Erin, please take our poll!")

print("\n按顺序遍历字典中的所有键")
for name in sorted(favorite_languages.keys()):
	print(name.title() + ", thank you for taking the poll.")

print("\n遍历字典中的所有值")
print("The following languages have been mentioned: ")
for language in set(favorite_languages.values()):
	print(language.title())

# 6.4 嵌套
print("\n字典列表")
alien_0 = {'color': 'green', 'points': 5}
alien_1 = {'color': 'yellow', 'points': 10}
alien_2 = {'color': 'red', 'points': 15}

aliens = [alien_0, alien_1, alien_2]
for alien in aliens:
	print(alien)

print("\n随机生成30个外星人")
# 创建一个用于存储外星人的空列表
aliens = []

# 创建30个绿色的外星人
for alien_number in range(30):
	new_alien = {'color': 'green', 'points': 5, 'speed': 'slow'}
	aliens.append(new_alien)

for alien in aliens[0:3]:
	if alien['color'] == 'green':
		alien['color'] = 'yellow'
		alien['speed'] = 'medium'
		alien['points'] = 10
	elif alien['color'] == 'yellow':
		alien['color']  = 'red'
		alien['speed'] = 'fast'
		alien['points'] = 15

# 显示前五个外星人
for alien in aliens[0:5]:
	print(alien)
print("... ...")

# 显示创建了多少个外星人
print("Total number of aliens: " + str(len(aliens)))

# 存储所点披萨的信息
print("\n字典中存储列表")
pizza = {
	'crust': 'thick',
	'toppings': ['mushrooms', 'extra cheese'],
}
# 概述所点披萨
print("You ordered a " + pizza['crust'] + "-crust pizza " + "with the following toppings:")
for topping in pizza['toppings']:
	print("\t" + topping)

print("\n在使用一个for循环关联被调查者相关联的语言")
favorite_languages = {
	'jen': ['python', 'ruby'],
	'sarah': ['c'],
	'edward': ['ruby', 'go'],
	'phil': ['python', 'haskell'],
}
for name, languages in favorite_languages.items():
	print("\n" + name.title() + "'s favorite languages are: ")
	for language in languages:
		print("\t" +language.title())


print("\n字典中存储字典")
users = {
	'aeinstein': {
		'first': 'albert',
		'last': 'einstein',
		'location': 'princeton',
	},
	'mcurie': {
		'first': 'marie',
		'last': 'curie',
		'location': 'paris',
	},
}
for username, user_info in users.items():
	print("\nUsername: " + username)
	full_name = user_info['first'] + " " + user_info['last']
	location = user_info['location']
	print("\tFull name: " + full_name.title())
	print("\tLocation: " + location.title())
