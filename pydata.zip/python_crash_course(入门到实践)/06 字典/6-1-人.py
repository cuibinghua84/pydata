person = {
    'first_name': 'cui',
    'last_name': 'binghua',
    'age': '36',
    'city': 'beijing',
}

print(person['first_name'])
print(person['last_name'])
print(person['age'])
print(person['city'])