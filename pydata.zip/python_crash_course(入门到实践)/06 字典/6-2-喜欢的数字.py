person_numbers = {
    'cui': 8,
    'zhang': 7,
    'li': 6,
    'wang': 9,
    'zhao': 3
}

print(person_numbers['cui'])
print(person_numbers['zhang'])
print(person_numbers['li'])
print(person_numbers['wang'])
print(person_numbers['zhao'])