car = input("Enter a car: ")
print("Let me see if I can find you a " + car.title())