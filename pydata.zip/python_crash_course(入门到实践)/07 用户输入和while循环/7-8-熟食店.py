sandwich_orders = ['sandwich1', 'sandwich2', 'sandwich3']
finished_sandwiches = []

for sandwich_order in sandwich_orders:
    print("I made your " + sandwich_order)
    
