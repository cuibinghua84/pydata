while True:
	pizza = input()
	if pizza == 'quit':
		break
	else:
		print("我们会在比萨中加入 " + pizza)