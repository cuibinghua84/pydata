number = int(input("Enter a number: "))
if number % 10 == 0:
	print(str(number) + " 是10的整数倍")
else:
	print(str(number) + " 不是10的整数倍")