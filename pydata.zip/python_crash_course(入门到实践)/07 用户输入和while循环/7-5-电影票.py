active = True
while active:
	age = int(input("Please is age: "))
	if age == 0:
		active = False
	elif age < 3:
	    print("免费")
	elif 3 <= age < 12:
		print("10美元")
	else:
		print("15美元")