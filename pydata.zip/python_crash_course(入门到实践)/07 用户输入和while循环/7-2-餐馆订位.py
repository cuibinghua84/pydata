number = input("Enter a numbers: ")
number = int(number)
if number > 8:
	print("不好意思没有空位了")
else:
	print("您好，还有余位")