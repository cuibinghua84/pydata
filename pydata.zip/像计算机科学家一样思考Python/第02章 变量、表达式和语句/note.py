# -*- coding: utf-8 -*-
"""
@author: 崔丙华
@file: note.py
@time: 2019/8/12 10:13
"""

# 2.1 赋值语句
message = 'And now for something completely different'
n = 17
pi = 3.141592653589793

# 2.2 变量名
# 关键字
from keyword import kwlist
print(kwlist)

# 'False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await', 'break', 'class', 
# 'continue', 'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 'from', 
# 'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield'

# 2.3 表达式和语句


# 2.4 脚本模式


# 2.5 运算顺序


# 2.6 字符串运算


# 2.7 注释


# 2.8 调试


# 2.9 术语表


# 2.10 练习


