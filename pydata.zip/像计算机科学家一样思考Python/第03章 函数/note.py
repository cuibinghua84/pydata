# -*- coding: utf-8 -*-
"""
@author: 崔丙华
@file: note.py
@time: 2019/8/12 10:13
"""

import math

# 3.1 函数调用

# 3.2 数学函数



# 3.3 构建

# 3.4 增加新函数
# def print_lyrics():
# 	print("I'm a lumberjack, and I'm okay.")
# 	print("I sleep all night and I work all day.")

# print(print_lyrics)
# print(type(print_lyrics))
# print_lyrics()

# def repeat_lyrics():
# 	print_lyrics()
# 	print()
# 	print_lyrics()

# repeat_lyrics()

# 3.5 定义和使用

# 3.6 执行流程

# 3.7 形参和实参
# def print_twice(bruce):
# 	print(bruce)
# 	print(bruce)
# 	print()

# print_twice('Span')
# print_twice(36)
# print_twice(math.pi)

# print_twice('Span ' * 4)

# print_twice(math.cos(math.pi))

# 3.8 变量和形参都是局部的
# 只能在函数内部存在
def cat_twice(part1, part2):
	cat = part1 + part2
	print_twice(cat)

# line1 = 'Bing tiddle '
# line2 = 'tiddle bang.'
# cat_twice(line1, line2)


# 3.9 堆栈图



# 3.10 有返回值函数和无返回值函数


# 3.11 为什么使用函数


# 3.12 调试


# 3.13 术语表


# 3.14 练习
# Exercise3.1
def right_justify(s):
	print(" "*(70 - len(s)) + s)

# right_justify('monty')



# Exercise3.2

def do_twice(f, f1):
	f(f1)
	f(f1)

def print_spam(f1):
	print(f1)
	print(f1)

def print_twice(f):
	print(f)
	print(f)
	print()

def do_four(f, f1):
	do_twice(f, f1)
	do_twice(f, f1)

# do_twice(print_twice, 'spam')


# Exericise 3.2
# print("+ - - - - + - - - - +")
# print("|         |         |")
# print("|         |         |")
# print("|         |         |")
# print("|         |         |")
# print("+ - - - - + - - - - +")
# print("|         |         |")
# print("|         |         |")
# print("|         |         |")
# print("|         |         |")
# print("+ - - - - + - - - - +")


