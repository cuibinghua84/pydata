# -*- coding: utf-8 -*-
"""
@author: 崔丙华
@file: note.py
@time: 2019/8/12 10:13
"""

# 1.1 什么是程序


# 1.2 运行Python


# 1.3 第一个程序
# print("Hello")

# 1.4 算术运算符
# print(40 + 2)
# print(43 - 1)
# print(6 * 7)
# print(84 / 2)
# print(6 ** 2 + 6)
# print(6 ^ 2)


# 1.5 值和类型
# print(type(2))
# print(type('2'))
# print(type(42.0))
# print(type('42.0'))
# print(type('Hello, World!'))



# 1.6 形式语言和自然语言


# 1.7 调试


# 1.8 术语表


# 1.9 练习
print(42 * 60 + 42)
print(10 / 1.61)