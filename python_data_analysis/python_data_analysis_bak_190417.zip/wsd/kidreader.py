# -*- coding: utf-8 -*-
"""
Created on Thu Aug 30 11:29:23 2018

@author: cuibinghua
"""

import pprint

path = "D:/py/pydata_master/kidreader/101/kidreader_report_2018-08-28.log"
print(open(path).readline())
pprint.pprint(open(path).readline())