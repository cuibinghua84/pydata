# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 4-5-线性代数.py
@time: 2018/10/22 11:18
"""