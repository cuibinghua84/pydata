# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 4-2-ndarray一种多维数组对象.py
@time: 2018/9/26 15:50
"""
import numpy as np
from numpy.random import randn

# ndarray是一个通用的同构数据多维容器，其中所有元素必须是相同类型的，
# 每个数组都有一个shape(一个表示各维度大小的元组)和一个dtype(一个用于说明数组数据类型的对象)
# data = np.array([[0.9526, -0.246, -0.8856], [0.5639, 0.2379, 0.9104]])
# print(data)
# print(data * 10)
# print(data.shape)
# print(data.dtype)

# 创建ndarray：使用array函数
# data1 = [6, 7.5, 8, 0, 1]
# arr1 = np.array(data1)
# print(arr1)
# print(arr1.dtype)
# print(arr1.shape)

# data2 = [[1, 2, 3, 4], [5, 6, 7, 8]]-
# arr2 = np.array(data2)
# print(arr2)
# print(arr2.shape)
# print(arr2.dtype)

# zeros和ones分别可以创建指定长度或形状的全是0或1数组，empty可以创建一个没有任何具体值的数组
# print(np.zeros(10))
# print(np.ones(10))
# print(np.zeros((3, 6)))
# print(np.empty((2, 3, 2)))

# arange是Python内置函数range的数组版
# print(np.arange(15))

# 数组创建函数
# array 将输入数据转换为ndarray，要么推断出dtype，要么显示指定dtype，默认直接复制输入数据
# asarray   将输入转换为ndarray，如果输入本身就是一个ndarray就不进行复制
# arange    类似于内置的range，但返回的是一个ndarray而不是列表
# ones、ones_like    根据指定形状和dtype创建一个全1数组
# zeros、zeros_like  全0数组
# empty、empty_like  创建新数组，只分配内存空间但不填充任何值
# eye、identity  创建一个正方的NxN单位矩阵（对角线为1，其余为0）
# print(np.eye(6,6))

"""
NumPy的数据类型
int8、uint8

"""
# arr = np.array([1, 2, 3, 4, 5])
# print(arr.dtype)

# float_arr = arr.astype(np.float64)
# print(float_arr.dtype)

# 整数转换成了浮点数，小数部分将会被截断
# arr = np.array([3.7, -1.2, -2.6, 0.5, 12.9, 10.1])
# print(arr)
# print(arr.astype(np.int32))

# 如果某字符串数组表示的全是数字，也可以用astype将其转换为数值形式
# numeric_strings = np.array(['1.25', '-9.6', '42'], dtype=np.string_)
# print(numeric_strings.astype(float))

# dtype另外用法
# int_array = np.arange(10)
# calibers = np.array([.22, .270, .357, .380, .44, .50], dtype=np.float64)
# print(int_array.astype(calibers.dtype))

# empty_uint32 = np.empty(8, dtype='u4')
# print(empty_uint32)

# 数组与标量之间的运算
# 矢量化：不用编写循环即可对数据执行批量运算

# arr = np.array([[1., 2., 3.], [4., 5., 6.]])
# print(arr)
# print()
# print(arr * arr)
# print()
# print(arr - arr)
# print(1 / arr)
# print(arr ** 0.5)

# 广播：不同大小数组之间的运算

# 基本的索引和切片
# arr = np.arange(10)
# print(arr)
# print(type(arr))
# print(arr[5])
# print(arr[5:8])
# arr[5:8] = 12
# print(arr)

# arr_slice = arr[5:8]
# arr_slice[1] = 12345
# print(arr)
# arr_slice[:] = 64
# print(arr)

# NumPy的设计目的是处理大数据，ndarray切片得到的是一份副本而非视图，如需要显示地进行复制操作，arr[5:8].copy()

# 高维数组
# arr2d = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
# print(arr2d[2])
# print(arr2d[0][2])
# print(arr2d[0, 2])

# arr3d = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])
# print(arr3d)
# print(arr3d[0])
# old_values = arr3d[0].copy()
# arr3d[0] = 42
# print(arr3d)
# print()
# arr3d[0] = old_values
# print(arr3d)

# 切片索引
# arr = np.array([1, 2, 3, 4, 5, 64, 7])
# print(arr[1:6])

# 布尔索引
#names = np.array(['Bob', 'Joe', 'Will', 'Bob', 'Will', 'Joe', 'Joe'])
#data = randn(7, 4)
# print(data)
# print(names)

#names == "Bob"
#print(names)

# 布尔型索引

# 花式索引：利用整数数组进行索引；花式索引跟切片不一样，它总将数据复制到新数组中

# reshape
# arr = np.arange(32).reshape(8, 4)
# print(arr)
# print(arr[[1, 5, 7, 2], [0, 3, 1, 3]])
# print(arr[[1, 5, 7, 2]][:, [0, 3, 1, 2]])

# np.ix_函数
# print(arr[np.ix_([1, 5, 7, 2], [0, 3, 1, 2])])

# 数组转置和轴兑换
# 转置是重塑的一种特殊形式，它返回的是数据源的视图（不会进行任何复制操作）
# arr = np.arange(15).reshape((3, 5))
# print(arr)
# print('*' * 20)
# print(arr.T)

# 矩阵内积
# arr = np.random.randn(6, 3)
# print(np.dot(arr.T, arr))

arr = np.arange(16).reshape((2, 2, 4))
# print(arr)
# print(arr.transpose((1, 0, 2)))

print(arr.swapaxes(1, 2))