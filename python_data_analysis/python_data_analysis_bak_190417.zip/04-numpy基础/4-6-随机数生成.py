# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 4-6-随机数生成.py
@time: 2018/10/22 11:18
"""