# -*- coding: utf-8 -*-
"""
Created on Fri Sep 28 11:49:50 2018

@author: cuibinghua
"""

import numpy as np
from numpy.random import randn

# 通用函数：快速的元素级数组函数
# 通用函数是一种对ndarray中的数据执行元素级运算的函数
# arr = np.arange(10)
# print(arr)
# print(np.sqrt(arr))
# print(np.exp(arr))

# x = randn(8)
# y = randn(8)
# print(x)
# print(y)
# print(np.maximum(x, y))
# print(randn(7))
# arr = randn(7) * 5
# print(arr)
# print(np.modf(arr))

# 一元ufunc
"""
abs、fabs	计算整数、浮点数或复数的绝对值。对于非复数值，可以使用更快的fabs
sqrt	计算各元素的平方根
square	计算根元素的平方
exp	计算根元素的指数
log log10 log2 log1p	分别为自然对数，底数为10的log、底数为2的log log(1+x)
sign	计算各元素的正负号
ceil	计算各元素的ceiling值，即大于等于该值的最小整数
floor 	计算各元素的floor值，即小玉等于该值的最大整数
rint 	将各元素四舍五入到最接近的整数，保留dtype
modf	将数组的小数和整数部分以两个独立数组的形式返回
isnan	返回一个列表“那些值都是NaN”
isfinite isinf	分别返回一个笔试
cos cosh sin sinh tan tanh
arccos arccosh arcsin arcsinh arctan arctanh
logical_not
"""

# 二元ufunc
"""
add
subtract
multiply
divide floor_divide
power
maximum fmax
minimum fmin
mod
copysign
greater greater_equal
less less_equal
equal not_equal
logical_and logical_or
logical_xor
"""

"""

"""