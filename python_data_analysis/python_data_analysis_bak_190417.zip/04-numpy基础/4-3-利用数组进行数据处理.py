# -*- coding: utf-8 -*-
"""
Created on Fri Sep 28 17:29:58 2018

@author: cuibinghua
"""

import numpy as np
from numpy.random import randn
import matplotlib.pyplot as plt

# 矢量化：用数组表达式代替循环的做法

#points = np.arange(-5, 5, 0.01) # 1000个间隔相等的点
#xs, ys = np.meshgrid(points, points)
# print(ys)
# print()

#z = np.sqrt(xs ** 2 + ys ** 2)
# print(z)

#plt.imshow(z, cmap=plt.cm.gray);plt.colorbar()
#plt.title("Image plot of $\sqrt{x^2 + y^2}$ for a grid of values")

# 将条件逻辑表述为数组运算
# numpy.where函数是三元表达式x if condition else y的矢量化版本
# xarr = np.array([1.1, 1.2, 1.3, 1.4, 1.5])
# yarr = np.array([2.1, 2.2, 2.3, 2.4, 2.5])
# cond = np.array([True, False, True, True, False])
# 根据cond中的值去xarr和yarr的值：当cond中的值为True时，选取xarr的值，否则从yarr中取值，列表推导式如下
# result = [(x if c else y) for x, y, c in zip(xarr, yarr, cond)]
# print(result)

# 使用np.where的简洁写法
# result = np.where(cond, xarr, yarr)
# print(result)

# arr = randn(4, 4)
# print(arr)
# print(np.where(arr > 0, 2, -2))
# print(np.where(arr > 0, 2, arr)) # 只将正值设置为2

# 数学和统计方法
"""
基本数组统计方法
sum	对数组中全部或谋轴想的元素求和 零长度的数组的sum为0
mean	算数平均数 零长度的数组的mean为NaN
std、var	分贝为标准差和方差，自由度可调
min、max	最大值和最小值
argmin、argmax	分别为最大和最小元素的索引
cumsum	所有元素的累计和
cumprod	属于元素的累计积
"""
# arr = np.random.randn(5, 4) # 正态分布的数据
# print(arr.mean())

# 用于布尔型数组的方法：布尔值会被强制转换为1(True)和0(False)，因此sum经常被用来对布尔型数组中的True值计算
# arr = randn(100)
# print(arr)
# print((arr > 0).sum())
# any和all 他们对布尔型数组也有用，any用于测试数组中是否存在一个或多个True，all检查数组中所有值是否都是True
# 也用于非布尔型数组，所有非0元素将会被当做True
# bools = np.array([False, False, True, False])
# print(bools.any())
# print(bools.all())

# 排序
# NumPy数组也可以通过sort方法就地排序
# arr = randn(8)
# print(arr)
# arr.sort()
# print(arr)

# 多维数组可以在任何一个轴向上进行排序，只需将轴编号传给sort即可
# arr = randn(5, 3)
# print(arr)
# print()
# arr.sort(1)
# print(arr)

# np.sort返回的是数组的已排序副本，而就地排序则会修改数组本身。
# large_arr = randn(1000)
# print(large_arr)
# large_arr.sort()
# print(large_arr[int(0.05 * len(large_arr))]) # 5%分位数

# 唯一化以及其他的集合逻辑
"""
unique(x)	计算x中的唯一元素，并返回有序结果
intersect1d(x, y)	计算x和y中的公共元素，并返回有序结果
union1d(x, y)	计算x和y的并集，并返回有序结果
in1d(x, y)	得到一个表示“x的元素是否包含于y”的布尔型数组
setdiff1d(x, y)	集合的差，即元素在x中且不在y中
setxor1d(x, y)	集合的对称差，即存在于一个数组中但不同时存在于两个数组中的元素
"""
# np.unique：找出数组中的唯一值并返回已排序的结果
# names = np.array(['Bob', 'Joe', 'Will', 'Bob', 'Will', 'Joe', 'Joe'])
# print(np.unique(names))
# # 等同
# print(sorted(set(names)))

# ints = np.array([3, 3, 3, 2, 2, 1, 1, 4, 4])
# print(np.unique(ints))
# # 等同
# print(sorted(set(ints)))

# np.in1d 用于测试一个数组中的值在另一个数组中的成员资格，返回要给布尔型数组
values = np.array([6, 0, 0, 3, 2, 5, 6])
print(np.in1d(values, [2, 3, 6]))