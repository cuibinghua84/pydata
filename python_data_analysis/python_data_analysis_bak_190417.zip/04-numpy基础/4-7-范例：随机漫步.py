# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 4-7-范例：随机漫步.py
@time: 2018/10/22 11:19
"""