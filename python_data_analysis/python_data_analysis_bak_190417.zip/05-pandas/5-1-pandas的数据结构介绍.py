# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 5-1-pandas的数据结构介绍.py
@time: 2018/10/8 10:47
"""

from pandas import Series, DataFrame
import pandas as pd
import numpy as np

# pandas的数据结构介绍
# Series：类似于一维数组的对象，它由一组数据以及一组与之相关的数据标签组成
# Series字符串表现形式：索引在左边，值在右边；可通过Series的values和index属性获取其数组表示形式和索引对象
# obj = Series([4, 7, -5, 3])
# print(obj)
# print(obj.values)
# print(obj.index)

# 创建一个可以对各个数据点机型标记的索引的Series
# obj2 = Series([4, 7, -5, 3], index=['d', 'b', 'a', 'c'])
# print(obj2)
# print(obj2.index)
# print(obj2['a'])
# obj2['d'] = 6
# print(obj2[['c', 'a', 'd']])
# print(obj2[obj2 > 0])
# print(obj2 * 2)
# print(np.exp(obj2))

# 把Series看成一个定长的有序字典
# print(obj2)
# print('b' in obj2)
# print('e' in obj2)

# 用字典来创建Series
# sdata = {'Ohio': 35000, 'Texas': 71000, 'Oregon': 16000, 'Utah': 5000}
# obj3 = Series(sdata)
# print(obj3)

# 如果只传入要给字典，则结果是Series中的索引就是原字典的键(有序排列)
# states = ['California', 'Ohio', 'Oregon', 'Texas']
# obj4 = Series(sdata, index=states)
# print(obj4)

# pandas的isnull和notnull函数可用于检测缺失数据
# print(pd.isnull(obj4))
# print(pd.notnull(obj4))
# Series的类似方法
# print(obj4.isnull())

# Series最重要的一个功能是：在算术运算中自动对齐不同索引的数据
# print(obj3)
# print(obj4)
# print(obj3 + obj4)

# Series对象本身及其索引都有一个name属性，该属性跟pandas其他的关键功能关系非常密切
# obj4.name = 'population'
# obj4.index.name = 'state'
# print(obj4)
# print(obj)
# obj.index = ['Bob', 'Steve', 'Jeff', 'Ryan']
# print(obj)

# DataFrame
# DataFrame:是一个表格型的数据结构。它含有一组有序的列，每列可以是不同的值类型(数字，字符串，布尔值等)
# DataFrame既有行索引也有列索引，它可以被看做有Series组成的字典
# 构建DataFrame方法：常用方法直接传入一个由等长列表或NumPy数组组成的字典
# data = {'state': ['Ohio', 'Ohio', 'Ohio', 'Nevada', 'Nevada'],
# 		'year': [2000, 2001, 2002, 2001, 2002],
# 		'pop': [1.5, 1.7, 3.6, 2.4, 2.9]}
# frame = DataFrame(data)
# print(frame)
# print()
# 按照指定序列进行排序
# print(DataFrame(data, columns=['year', 'state', 'pop'])) 

# 如传入的列在数据中找不到，就会产生NA值
# frame2 = DataFrame(data, columns=['year', 'state', 'pop', 'debt'],
# 				   index=['one', 'two', 'three', 'four', 'five'])
# print(frame2)
# print()
# 通过类似字典标记的方式或属性的方式，可以将DataFrame的列获取为一个Series
# print(frame2['state'])
# print()
# print(frame2.year)

# 行也可以通过位置或名称的方式进行获取，比如ix
# print(frame2)
# print()
# print(frame2.ix['three'])

# 列可以通过赋值的方式进行修改
# print(frame2)
# frame2['debt'] = 16.5
# print()
# print(frame2)
# print()
# frame2['debt'] = np.arange(5)
# print(frame2)

# 将列表或数组赋值给某个列时，其长度必须跟DataFrame的长度相匹配；
# 如果赋值的是一个Series，就会精度匹配DataFrame的索引，所有的空位都将被填上缺失值
# print(frame2)
# print()
# val = Series([-1.2, -1.5, -1.7], index=['two', 'four', 'five'])
# frame2['debt'] = val
# print(frame2)
# print()

# 为不存在的列赋值会创建出一个新列，关键字del用于删除列
# frame2['eastern'] = frame2.state == 'Ohio'
# print(frame2)
# print()
# del frame2['eastern']
# print(frame2)
# print(frame2.columns)
# print(frame2.index)

# 另一种常见的数据形式是嵌套字典
# pop = {'Nevada': {2001: 2.4, 2002: 2.9},
#        'Ohio': {2000: 1.5, 2001: 1.7, 2002: 3.6}}
# 把pop传给DataFrame，会被解释为：外层字典的键作为列，内能字典的键作为行
# frame3 = pd.DataFrame(pop)
# print(frame3)
# 对结果进行转置
# print()
# print(frame3.T)
# frame3.T

# 内层字典的键会被合并、排序以形成最终的索引。
# DataFrame(pop, index=[2001,2002,2003])

# 由Series组成的字典差不多也是一样的用法
# pdata = {'Ohio': frame3['Ohio'][:-1],
#          'Nevada': frame3['Nevada'][:2]}
# print(DataFrame(pdata))

# DataFrame构造器的数据
"""
类型                              说明
二维ndarray                       数据矩阵，还可以传入行标和列标

有数据、列标或元组组成的字典        每个序列会变成DataFrame的一列。所有序列的长度必须相同

NumPy的结构化/记录数组             类似于“由数组组成的字典”

由Series组成的字典                 每个Series会成为一列。如果没有显式指定索引，则各Series的索引会被合并成结果的行索引

由字典组成的字典            

字典或Series的列表

由列表或元组组成的列表

另一个DataFrame

NumPy的MaskedArray

"""

# 如果设置了DataFrame的index和columns的name属性，则这些信息也会被显示出来
# frame3.index.name = 'year'
# frame3.columns.name = 'state'
# print(frame3)

# 跟Series一样，values属性也会以二维ndarray的形势返回DataFrame中的数据
# print(frame3.values)

# 如果DataFrame各列的数据类型不同，则值数组的数据类型就会选用能兼容所有列的数据类型
# print(frame2.values)

# 索引对象
# pandas的索引对象负责管理轴标签和其他元数据。构建Series或DataFrame时，所用到的任何数据或其他序列的标签都会被转换成一个Index
# Index对象是不可修改的
# obj = Series(range(3), index=['a', 'b', 'c'])
# index = obj.index
# print(index)
# print(index[1:])

# 不可修改非常重要，这样才能使Index对象在多个数据结构之间安全共享
# index = pd.Index(np.arange(3))
# obj2 = Series([1.5, -2.5, 0], index=index)
# print(obj2.index is index)

# pandas中主要的Index对象
"""
Index                最泛化的index对象，将轴标签表示为一个由Python对象组成的NumPy数组
Int64Index           针对整数的特殊index
MultiIndex           “层次化”索引对象，表示单个轴上的多层索引。可以看做由元组组成的数组
DatetimeIndex        存储纳秒级时间戳（用NumPy的datetime64类型标识）
PeriodIndex          针对Period数据（时间间隔）的特殊index
"""

# index的方法和属性
"""
append        连接另一个index对象，产生一个新的index
diff          计算差集，并得到要给新的index
intersection  计算交集
union         计算并集
isin          计算一个指示各值是否包含在参数集合中的布尔型数组
delete        删除索引i处的元素，并得到新的index
drop          删除传入的值，并得到新的index
insert        将元素插入到索引i处，并得到新的index
is_monotonic  当各元素均大于等于前一个元素时，返回True
is_unique     当index没有重复值时，返回True
unique        计算index中唯一值的数组
"""
