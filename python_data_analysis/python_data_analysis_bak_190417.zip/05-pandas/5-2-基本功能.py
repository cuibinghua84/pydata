# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 5-2-基本功能.py
@time: 2018/10/22 10:36
"""

# 重新索引
# reindex：创建一个适应新索引的新对象

