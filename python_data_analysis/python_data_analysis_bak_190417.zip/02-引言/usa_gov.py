# -*- coding: utf-8 -*-
"""
Created on Wed Aug 22 13:10:28 2018

@author: cuibinghua
"""

import json
import pprint
from collections import defaultdict
from collections import Counter
from pandas import DataFrame, Series
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

path = "D:/py/pydata_master/ch02/usagov_bitly_data2012-03-16-1331923249.txt"
# print(open(path).readline())
# pprint.pprint(open(path).readline())

# 使用JSON模块以及loads函数逐行加载已经下载好的数据文件
records = [json.loads(line) for line in open(path)]  # 此次为列表推导式
# print(records[0])
# pprint.pprint(records[0])
"""
{'a': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like '
      'Gecko) Chrome/17.0.963.78 Safari/535.11',
 'al': 'en-US,en;q=0.8',
 'c': 'US',
 'cy': 'Danvers',
 'g': 'A6qOVH',
 'gr': 'MA',
 'h': 'wfLQtf',
 'hc': 1331822918,
 'hh': '1.usa.gov',
 'l': 'orofrog',
 'll': [42.576698, -70.954903],
 'nk': 1,
 'r': 'http://www.facebook.com/l/7AQEFzjSi/1.usa.gov/wfLQtf',
 't': 1331923247,
 'tz': 'America/New_York',
 'u': 'http://www.ncbi.nlm.nih.gov/pubmed/22415991'}
"""

# 以字符串的形势给出想要访问的键就可以得到当前记录中相应的值
# print(records[0]['tz'])
# print(records[0]['u'])

# 用纯Python代码对时区进行计数，同时判断是否所有记录都有时区（tz）字段
time_zones = [rec['tz'] for rec in records if 'tz' in rec]


# print(time_zones[:10])
# pprint.pprint(time_zones[:10])

# 对时区进行计数
# 方法一遍历时区的过程中将计数保存在字典中
def get_counts(sequence):
    counts = {}
    for x in sequence:
        if x in counts:
            counts[x] += 1
        else:
            counts[x] = 1
    return counts


# counts = get_counts(time_zones)
# print(counts['America/New_York'])
# print(len(time_zones))

# 方法二：领用Python标准库 from collections import defaultdict
def get_counts2(sequence):
    counts = defaultdict(int)  # 所有值均会被初始化为0
    for x in sequence:
        counts[x] += 1
    return counts


counts = get_counts2(time_zones)


# print(counts['America/New_York'])
# print(len(time_zones))

# 获取前10位时区的计数值，需要处理下字典
def top_counts(count_dict, n=10):
    value_key_pairs = [(count, tz) for tz, count in count_dict.items()]
    value_key_pairs.sort()
    return value_key_pairs[-n:]


# print(top_counts(counts))
# pprint.pprint(top_counts(counts))

# 利用Python标准库collections.Counter类，进行计算
# counts = Counter(time_zones)
# pprint.pprint(counts.most_common(30))

# 用pandas对时区进行计数
# DataFrame是pandas中最重要的数据结构，将数据表示为一个表格
frame = DataFrame(records)
# print(frame)
# print(frame['tz'][:10])

# 返回的Series对象有一个value_counts方法
# tz_counts = frame['tz'].value_counts()
# print(tz_counts[:10])

# 给记录中的未知或缺失的时区填上一个替代值。fillna函数可以替换缺失值，而未知值则可以通过布尔型数组索引加以替换
# clean_tz = frame['tz'].fillna('Missing')
# clean_tz[clean_tz == ''] = 'Unknown'
# tz_counts = clean_tz.value_counts()
# print(tz_counts[:10])
# tz_counts[:10].plot(kind='barh', rot=0)

# print(frame['a'][51])

'''
'a': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.11 (KHTML, like '
      'Gecko) Chrome/17.0.963.78 Safari/535.11',
'''
# 分离字符串的第一节（a中的数据）
# results = Series([x.split()[0] for x in frame.a.dropna()])
# print(results[:5])

# 按照Windows和非Windows用户对时区统计信息进行分解
# 移除缺失数据
cframe = frame[frame.a.notnull()]
# 根据a值计算出各行是否有Windows
operating_system = np.where(cframe['a'].str.contains('Windows'), 'Windows', 'Not Windows')
# print(operating_system[:5])
# 根据时区和新得到的操作系统列表对数据进行分组
by_tz_os = cframe.groupby(['tz', operating_system])
# 通过size对分组结果进行计数，利用unstack对计数结果进行重塑
agge_counts = by_tz_os.size().unstack().fillna(0)
# print(age_counts[:10])

# 根据agg_counts中的行数构造一个间接索引数组
# 用于按升序排列
indexer = agge_counts.sum(1).argsort()
# print(indexer[:10])

# 通过take按照这个顺序截取最后10房
count_subset = agge_counts.take(indexer)[-10:]
# print(count_subset)

# 生成一张条形图
# count_subset.plot(kind='barh', stacked=True)
# plt.show()

# 将各行规范化为“总计为1”并重新绘图
# plt.figure(1)
# normed_subset = count_subset.div(count_subset.sum(1), axis=0)
# normed_subset.plot(kind='barh', stacked=True)
# plt.show()
