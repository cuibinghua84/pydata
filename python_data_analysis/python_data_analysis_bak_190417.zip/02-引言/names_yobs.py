# -*- coding: utf-8 -*-
"""
@author: 东风
@file: names_yobs.py
@time: 2018/9/26 0:07
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# path_names = "D:/py/pydata_master/ch02/names/yob1880.txt"

# 这是一个非常标准的以逗号隔开的格式，可以用pandas.read_csv将其加载到DataFrame中
# names1880 = pd.read_csv(path_names, names=['name', 'sex', 'births'])
# print(names1880)

# 利用births列的sex分组计算表示该年度的births总计
# print(names1880.groupby('sex').births.sum())

# 将所有的数据都组装到要给DataFrame里面，并加上year字典。使用pandas.concat可实现
path_names = "D:/py/pydata_master/ch02/names/"

# 2010是目前最后一个有效统计年度
years = range(1880, 2011)

pieces = []
columns = ['name', 'sex', 'births']

for year in years:
    path = path_names + 'yob%d.txt' % year
    frame = pd.read_csv(path, names=columns)

    frame['year'] = year
    pieces.append(frame)

# 将所有数据整合到单个DataFrame中
# concat默认是按行将多个DataFrame组合到一起的；
# 必须指定ignore_index=True，因为我不希望保留 read_csv所返回的原始行号
names = pd.concat(pieces, ignore_index=True)


# print(names)

# 利用groupby或pivot_table在year和sex级别上进行聚合了
# 将rows改成index，cols改成columns
# total_births = names.pivot_table('births', rows='year', cols='sex', aggfunc=sum)
# total_births = names.pivot_table('births', index='year', columns='sex', aggfunc=sum)
# print(total_births.tail())
# total_births.plot(title='Total births by sex and year')
# plt.show()

# 插入piop列，存放指定名字婴儿数相对于总出生数的比例
# 先按year和sex分组，然后再将新列加到各个组上
# def add_prop(group):
#     # 整数乘法会向下圆整
#     births = group.births.astype(float)
#
#     group['prop'] = births / births.sum()
#     return group


# names = names.groupby(['year', 'sex']).apply(add_prop)

# print(names)

# 检查分组总计值是否为1：np.allclose
# print(np.allclose(names.groupby(['year', 'sex']).prop.sum(), 1))

# 取出数据的一个子集：每对sex/year组合的前1000个名字，利用分组
# def get_top1000(group):
#     # return group.sort_index(by='births', ascending=False)[:1000]
#     return group.sort_values(by='births', ascending=False)[:1000]


# grouped = names.groupby(['year', 'sex'])
# top1000 = grouped.apply(get_top1000)
# print(top1000)

# DIY下
pieces = []
for year, group in names.groupby(['year', 'sex']):
    pieces.append(group.sort_values(by='births', ascending=False)[:1000])
top1000 = pd.concat(pieces, ignore_index=True)
# print(top1000)

# 分析命名趋势
# 将前1000个名字分为男女两个部分
# boys = top1000[top1000.sex == 'M']
# girls = top1000[top1000.sex == 'F']


# 生成图表：
# 先生成一张按year和name统计的总出生数透视表
# total_births = top1000.pivot_table('births', rows='year', cols='name', aggfunc=sum)
# total_births = top1000.pivot_table('births', index='year', columns='name', aggfunc=sum)
# print(total_births)

# subset = total_births[['John', 'Harry', 'Mary', 'Marilyn']]
# subset.plot(subplots=True, figsize=(12, 10), grid=False, title='Number of births per year')
# plt.show()

# 评估命名多样性的增长
# 计算最流行的1000个名字所占的比例，按year和sex进行聚合并绘图
# table = top1000.pivot_table('prop', index='year', columns='sex', aggfunc=sum)
# table.plot(title='Sum of table1000.prop by year and sex', yticks=np.linspace(0, 1.2, 13), xticks=range(1880, 2020, 10))
# plt.show()

# 另一种方法计算占总人数前50%的不同名字的数量：不太好计算，只考虑2010年男孩的名字
# df = boys[boys.year == 2010]
# # print(df)
# # prop_cumsum = df.sort_index(by='prop', ascending=False).prop.cumsum()
# prop_cumsum = df.sort_values(by='prop', ascending=False).prop.cumsum()
# print(prop_cumsum[:10])
# print(prop_cumsum.searchsorted(0.5))

# df = boys[boys.year == 1900]
# in1900 = df.sort_values(by='prop', ascending=False).prop.cumsum()
# print(in1900[:10])
# print(in1900.searchsorted(0.5) + 1)


# 对所有year/sex组合执行计算了，先进行groupby处理，后用一个函数计算各分组的值
# def get_quantitle_count(group, q=0.5):
#     group = group.sort_values(by='prop', ascending=False)
#     return group.prop.cumsum().searchsorted(q)[
#                0] + 1  # python3的searchsorted()返回的是ndarray类型而不是int64类型，所以需要先取[0]元素，才能获得想要的数据


# diversity = top1000.groupby(['year', 'sex']).apply(get_quantitle_count)
# diversity = diversity.unstack('sex')
# print(diversity.head())

# 绘图
# diversity.plot(title="Number of popular names in top 50%")
# plt.show()

# 最后一个字母的变革
# 先将全部出生数据在年度、性别以及字母上进行聚合
# 从name列取出最后一个字母
# get_last_letter = lambda x: x[-1]
# last_letters = names.name.map(get_last_letter)
# last_letters.name = 'last_letter'

# table = names.pivot_table('births', index=last_letters, columns=['sex', 'year'], aggfunc=sum)
# 选出具有一定代表性的三年，并输出前面几行
# subtable = table.reindex(columns=[1910, 1960, 2010], level='year')
# print(subtable.head())

# 按总出生数对该表进行规范化处理，以便计算出各性别各末字母占总出生人数的比例
# print(subtable.sum())
# letter_prop = subtable / subtable.sum().astype(float)

# 生成一张各年度各性别的条形图
# fig, axes = plt.subplots(2, 1, figsize=(10, 8))
# letter_prop['M'].plot(kind='bar', rot=0, ax=axes[0], title='Male')
# letter_prop['F'].plot(kind='bar', rot=0, ax=axes[1], title='Female', legend=False)
# plt.show()

# 按年度和性别对其进行规范化处理，并在男孩名字中选取几个字母，最后进行转置以便将各个列做成一个时间序列
# letter_prop = table / table.sum().astype(float)
# dny_ts = letter_prop.ix[['d', 'n', 'y'], 'M'].T
# print(dny_ts.head())

# 趋势图
# dny_ts.plot()
# plt.show()

# 变成女孩名字的男孩名字(以及相反的情况)
# 找出其中以“lesl”开头的一组名字
all_names = top1000.name.unique()
mask = np.array(['lesl' in x.lower() for x in all_names])
lesley_like = all_names[mask]
# print(lesley_like)

# 然后利用这个结果过滤其他的名字，并按名字分组计算出生数，以查看相对频率
filtered = top1000[top1000.name.isin(lesley_like)]
# print(filtered.groupby('name').births.sum())

# 按性别和年度进行聚合，并按年度进行规范化处理
table = filtered.pivot_table('births', index='year', columns='sex', aggfunc='sum')
table = table.div(table.sum(1), axis=0)
# print(table.tail())
# 绘制一张分性别的年度曲线图
table.plot(style={'M': 'k-', 'F': 'k--'})
plt.show()