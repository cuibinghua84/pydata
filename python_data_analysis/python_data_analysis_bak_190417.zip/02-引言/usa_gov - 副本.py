# -*- coding: utf-8 -*-
"""
Created on Wed Aug 22 13:10:28 2018

@author: cuibinghua
"""

import json
import pprint
from collections import defaultdict
from collections import Counter
from pandas import DataFrame, Series
import pandas as pd
import numpy as np


path = "D:/py/pydata_master/ch02/usagov_bitly_data2012-03-16-1331923249.txt"
# print(open(path).readline())

# 使用json模块及其loads函数逐行加载文件
records = [json.loads(line) for line in open(path)]

# print(records[0])
# pprint.pprint(records[0])
# print()
# print(records[0]['tz'])
# pprint.pprint(records[0]['tz'])

# 纯Python代码对时区进行计数
# time_zones = [rec['tz'] for rec in records if 'tz' in rec]  # 在列表推导式末尾增加if判断是否所有字段都有时区


# print(time_zones[:10])
# pprint.pprint(time_zones[:10])

# 遍历时区并将计数值保存在字典中（通过纯Python实现）
# def get_counts(sequence):
#     counts = {}
#     for x in sequence:
#         if x in counts:
#             counts[x] += 1
#         else:
#             counts[x] = 1
#     return counts


# 遍历时区并将计数值保存在字典中（通过Python标准库实现）
# def get_counts2(sequence):
#     counts = defaultdict(int)  # 将所有的值均会被初始化为0
#     for x in sequence:
#         counts[x] += 1
#     return counts


# 传入time_zones
# counts = get_counts2(time_zones)


# print(counts['America/New_York'])
# print(len(time_zones))

# 前10位的时区及其计数值
# def top_counts(count_dict, n=10):
#     value_key_pairs = [(count, tz) for tz, count in count_dict.items()]
#     value_key_pairs.sort()
#     return value_key_pairs[-n:]


# print(top_counts(counts))
# pprint.pprint(top_counts(counts))

# 通过Python标准库collections.Counter类实现
# counts = Counter(time_zones)
# print(counts.most_common(10))
# pprint.pprint(counts.most_common(10))


# 用pandas对时区进行计数
frame = DataFrame(records)
# print(frame)
# print(frame['tz'][:10])

tz_counts = frame['tz'].value_counts()
print(tz_counts[:10])