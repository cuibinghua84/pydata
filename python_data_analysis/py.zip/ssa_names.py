# -*- coding: utf-8 -*-
"""
@author: 东风
@file: ssa_names.py
@time: 2018/1/24 9:50
"""
"""
1880年到2016年婴儿名字的频率：
字段：名字   性别  生日

"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 标准的以逗号隔开的文件，用pd.read_csv将其加载到DataFrame中
# names_path = "D:/py/pydata_master/ch02/names/yob1880.txt"
# names1880 = pd.read_csv(names_path, names=['name', 'sex', 'births'])
# print(names1880)

# 查找当前出现5次的名字，用births列sex分组小计，表示该年度的births总计
# print(names1880.groupby('sex').births.sum())
# names1880.groupby('sex').births.sum()


# 将所有数据组装到一个DataFrame里面，并加上一个year字段 使用pd.concat
# 2016是目前最后一个有效统计年度
years = range(1880, 2017)
pieces = []
columns = ['name', 'sex', 'births']

paths = 'D:/py/pydata_master/ch02/names/'
for year in years:
    path = paths + '/yob%d.txt' % year
    # path = 'D:/py/pydata_master/ch02/names//yob%d.txt' % year
    frame = pd.read_csv(path, names=columns)

    frame['year'] = year
    pieces.append(frame)

# 将所有数据整合到DataFrame中 concat默认是按行将多个DataFrame组合到一起的
# 必须制定 ignore_index=True,因为我们不想保留read_csv所返回的原始行号
names = pd.concat(pieces, ignore_index=True)

# print(names)

# 根据以上数据，可以利用groupby或pivot_table在year和sex级别上对其进行聚合了
# total_births = names.pivot_table('births', rows='year', cols='sex', aggfunc=sum)
total_births = names.pivot_table('births', index='year', columns='sex', aggfunc=sum)


# print(total_births.tail())

# total_births.plot(title='Total births by sex and year')
# plt.show()

# 插入一个prop列，用户存放指定名字的婴儿数相对于总出生数的比例
def add_prop(group):
    # 整数除法会向下园整
    births = group.births.astype(float)

    group['prop'] = births / births.sum()
    return group
names = names.groupby(['year', 'sex']).apply(add_prop)


# print(names)

# 按照性别和年度统计总出生数
# 验证所有分组的prop的总和是否为1 用np.allclose来检查
# print(np.allclose(names.groupby(['year', 'sex']).prop.sum(), 1))

# 取子集：每对sex/year组合的前1000个名字
def get_top1000(group):
    return group.sort_values(by='births', ascending=False)[:1000]

grouped = names.groupby(['year', 'sex'])
top1000 = grouped.apply(get_top1000)

# 或者DIY
# pieces = []
# for year, group in names.groupby(['year', 'sex']):
#     pieces.append(group.sort_values(by='births', ascending=False)[:1000])
# top1000 = pd.concat(pieces, ignore_index=True)
# print(top1000)

# 分析命名趋势
# boys = top1000[top1000.sex == 'M']
# girls = top1000[top1000.sex == 'F']

# total_births = top1000.pivot_table('births', index='year', columns='name', aggfunc=sum)
# print(total_births)
# subset = total_births[['John', 'Harry', 'Marry', 'Marilyn']]
# subset.plot(subplots=True, figsize=(12, 10), grid=False, title="Number of births per year")
# plt.show()

# 评估命名多样性的增长
table = top1000.pivot_table('prop', index='year', columns='sex', aggfunc=sum)
table.plot(title = 'Sum of table1000.prop by year and sex', yticks=np.linspace(0, 1.2, 13), xticks=range(1880, 2020, 10))
plt.show()