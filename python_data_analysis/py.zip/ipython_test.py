# -*- coding: utf-8 -*-
"""
@author: 东风
@file: ipython_test.py
@time: 2018/1/24 17:12
"""

from numpy.random import randn
import numpy as np
import datetime

data = {i:randn() for i in range(7)}
print(data)

'''
1 Tab键自动完成
2 内省
'''

