# -*- coding: utf-8 -*-
"""
Created on Thu Jan 18 17:35:49 2018

@author: cuibinghua
"""

import pandas as pd

"""
movies.dat:电影信息
电影id 电影名称 流派

ratings.dat:评分表
用户id 电影id 评分分数 评分时间

users.dat:用户信息表
用户id 性别 年龄 职业 邮政编码
"""

# 文件路径
# 用户信息文件
users_path = "D:/py/pydata_master/ch02/movielens/users.dat"
# print(open(users_path).readline())
# 电影信息文件
movies_path = "D:/py/pydata_master/ch02/movielens/movies.dat"
# 评分文件
ratings_path = "D:/py/pydata_master/ch02/movielens/ratings.dat"

# 通过pandas.read_table 将各个表分别读到一个pandas DataFrame中
# 定义用户信息字段
unames = ["user_id", "gender", "age", "occupation", "zip"]
users = pd.read_table(users_path, sep="::", header=None, names=unames, engine="python")
# 验证数据加载是否顺利
# print(users[:5])
# 定义评分字段
rnames = ["user_id", "movie_id", "rating", "timestamp"]

ratings = pd.read_table(ratings_path, sep="::", header=None, names=rnames, engine="python")
# 验证数据加载是否顺利
# print(ratings[:5])
# 定义电影信息字段
mnames = ['movie_id', "title", "genres"]
movies = pd.read_table(movies_path, sep="::", header=None, names=mnames, engine="python")

# 验证数据加载是否顺利
# print(movies[:5])
# print(ratings)

# 用pandas的merge函数将ratings跟users合并到一起，然后再将movies也合并进去，pandas会根据列名的重叠情况推断出哪些列是合并键
# 1 ["user_id", "movie_id", "rating", "timestamp"] and ["user_id", "gender", "age", "occupation", "zip"]
#   ["user_id", "movie_id", "rating", "timestamp", "gender", "age", "occupation", "zip"]
# 2 ["user_id", "movie_id", "rating", "timestamp", "gender", "age", "occupation", "zip"] and ['movie_id', "title", "genres"]
# 最终合并字段 ["user_id", "movie_id", "rating", "timestamp", "gender", "age", "occupation", "zip","title", "genres"]
data = pd.merge(pd.merge(ratings, users), movies)
# print(data)

# 
# print(data.ix[0]) #ix已经弃用
# print(data.iloc[0])

# 按照性别计算每部电影的平均得分，可以使用pivot_table方法
# mean_ratings = data.pivot_table("rating", rows="title", cols="gender", aggfunc="mean")
mean_ratings = data.pivot_table("rating", index="title", columns="gender", aggfunc="mean")
# print(mean_ratings[:5])

# 过滤评分不够250条的电影：先对title进行分组，然后利用size()得到一个含有各电影分组大小的Series
ratings_by_title = data.groupby('title').size()
# print(ratings_by_title[:10])
active_titles = ratings_by_title.index[ratings_by_title >= 250]
# print(active_titles)

# 根据mean_ratings中选取所需的行
mean_ratings = mean_ratings.loc[active_titles]
# print(mean_ratings)

# 女性观众最喜欢的电影，按照F列降序排列
# top_female_ratings = mean_ratings.sort_index(by='F', ascending=False)
# print(top_female_ratings[:10])


# 计算评分分歧
# 方法：给mean_ratings加上一个用于存放平均得分之差的列，并对进行排序
mean_ratings['diff'] = mean_ratings['M'] - mean_ratings['F']
# sorted_by_diff = mean_ratings.sort_index(by='diff')
sorted_by_diff = mean_ratings.sort_values(by='diff')
# print(sorted_by_diff[:15])

# 结果反序，并取出前15行，得到男性观众最喜欢的电影
# print(sorted_by_diff[::-1][:15])

# 找出分歧最大的电影（考虑性别因素），可以计算得分数据的方差或标准差
# 1 根据电影名称分组的得分数据的标准差
rating_std_by_title = data.groupby('title')['rating'].std()

# 2 根据active_std_by_title进行过滤
rating_std_by_title = rating_std_by_title.ix[active_titles]

# 3 根据值对Series进行降序排列
# 最新版用的是sort_values，而不是 order
# print(rating_std_by_title.sort_values(ascending=False)[:10])