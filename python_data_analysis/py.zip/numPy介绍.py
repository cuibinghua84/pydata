# -*- coding: utf-8 -*-
"""
Created on Thu Jan 25 15:57:16 2018

@author: cuibinghua
"""

'''
功能介绍
1、ndarray，一个具有矢量运算算数和复杂广播能力的快速且节省空间的多维数组
2、用于对整组数据进行快速运算的标准数学函数
3、用于读写磁盘数据的工具以及用于操作内存映射文件的工具
4、线性代数、随机数生成以及傅里叶变换功能
5、用于集成C、C++、Fortran等语言编写的代码的工具

数据分析功能集中
1、用户数据整理和清理、子集构造和过滤、转换等快速的矢量化数组运算
2、常用的数组算法，如排序、唯一化、集合运算等
3、高效的描述统计和数据聚合/摘要运算
4、用于异构数据集的合并/连接运算的数据对齐和关系型数据运算
5、数据的分组运算（聚合、转换、函数应用等）
'''

import numpy as np

# 创建ndarray数组 np.array
#data = ([[0.9526, -0.246, -0.8856], [0.5639, 0.2379, 0.9104]])

data1 = [6, 7.5, 8, 0, 1]
arr1 = np.array(data1)
#print(arr1)

data2 = [[1, 2, 3, 4], [5, 6, 7, 8]]

arr2 = np.array(data2)
#print(arr2)

#print(arr2.ndim)
#print(arr2.shape)
#
#print(arr1.dtype)
#print(arr2.dtype)

# 创建数组 zeros和ones 分别创建指定长度或形状的全是0或1的数组
# empty创建一个没有任何具体值的数组
#print(np.zeros(10))
#print(np.zeros((3, 6)))

#print(np.ones(10))

#print(np.empty(10))
#print(np.empty((2, 3, 2)))


# arange是Python内置函数range的数组版
print(np.arange(15))