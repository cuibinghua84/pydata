# -*- coding: utf-8 -*-
"""
@author: 东风
@file: TuShare_demo.py
@time: 2018/1/29 11:36
"""
'''
http://tushare.org/
TuShare是一个免费、开源的python财经数据接口包。
主要实现对股票等金融数据从数据采集、清洗加工到数据存储的过程，
能够为金融分析人员提供快速、整洁、和多样的便于分析的数据，
为他们在数据获取方面极大地减轻工作量，使他们更加专注于策略和模型的研究与实现上。
'''

import tushare as ts
import matplotlib.pyplot as plt

# 获取股票历史数据
# print(ts.get_hist_data('601688'))

# 获取股票实时行情
# print(ts.get_realtime_quotes('000002'))

# 存款利率
# print(ts.get_deposit_rate())

# 电影票房
# print(ts.realtime_boxoffice())


# 获取上证指数的日K信息，然后保存成 excel 文件，再画出每日的收盘指数的折线图。
df = ts.get_hist_data('sh', start='2016-01-01')
df.to_excel('stock_sh.xlsx')
df.close.plot()
ax = plt.gca()
ax.invert_xaxis()
plt.show()
