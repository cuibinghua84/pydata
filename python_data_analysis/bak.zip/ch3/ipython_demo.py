# -*- coding: utf-8 -*-
"""
@author: Edward
@file: ipython_demo.py
@time: 2017/8/30 15:13
"""

import numpy as np
from numpy.random import randn

# data = {i : randn() for i in range(7)}
# print(data)

data = np.array([[0.9526, -0.246, -0.8856],[0.5639, 0.2379, 0.9104]])
# print(data)
# print(type(data))
# print(data * 10)
# print(data + data)
# print(data.shape)
# print(data.dtype)

data1 = [6, 7.5, 8, 0.1]
arr1 = np.array(data1)
# print(arr1)

data2 = [[1, 2, 3, 4], [5, 6, 7, 8]]
arr2 = np.array(data2)
# print(arr2)
# print(arr2.ndim)
# print(arr2.shape)

# print(arr1.dtype)
# print(arr2.dtype)

# print(np.zeros(10))
# print(np.zeros((3, 6)))

# print(np.empty((2, 3, 2)))

# print(np.arange(15));

