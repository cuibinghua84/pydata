# -*- coding: utf-8 -*-
"""
@author: Edward
@file: usa_gov.py
@time: 2017/8/29 17:54
"""
import json
from collections import defaultdict
from collections import Counter
import pandas as pd
from pandas import DataFrame,Series
import numpy as np
import matplotlib.pyplot as plt


path = "D:/py/pydata_master/ch02/usagov_bitly_data2012-03-16-1331923249.txt"
# print(open(path).readline())

#将JSON字符串转换成Python字典对象：使用json模块的loads函数逐行加载数据文件
records = [json.loads(line) for line in open(path)]
# print(records)
# print(records[0])

# 时区字段tz
# print(records[0]['tz'])

#一、用纯Python代码对时区进行计数，用列表推导式
#末尾增加if 'tz' in rec 判断字段时候有时区字段
# time_zones = [rec['tz'] for rec in records if 'tz' in rec]
# print(time_zones[:10])

#对时区计数；方法一遍历时区的过程将计数保存在字典中
# def get_counts(sequence):
#     counts = {}
#     for x in sequence:
#         if x in counts:
#             counts[x] += 1
#         else:
#             counts[x] = 1
#     return counts

#方法二
# def get_counts2(sequence):
#     counts = defaultdict(int) #所有的均值会被初始化为0
#     for x in sequence:
#         counts[x] += 1
#     return counts
#
# counts = get_counts(time_zones)
# counts2 = get_counts2(time_zones)

# print(counts['America/New_York'])
# print(counts2['America/New_York'])
#
# print(len(time_zones))

#获得前10位的时区及其计数
# def top_counts(count_dict, n = 10):
#     value_key_pairs = [(count, tz) for tz, count in count_dict.items()]
#     value_key_pairs.sort()
#     return value_key_pairs[-n:]
# print(top_counts(counts2))

#获取前十更简便的方法，利用collections.Counter类
# counts3 = Counter(time_zones)
# print(counts3.most_common(10))

#二、用pandas对时区计数
#DataFrame是pandas中重要的数据结构，它用于将数据表示为一个表格
fram = DataFrame(records)
# print(fram)
# print(fram['tz'][:10])

#value_counts
# tz_counts = fram['tz'].value_counts()
# print(tz_counts[:10])

#fillna函数替换缺失值
# clean_tz = fram['tz'].fillna('Missing')
# clean_tz[clean_tz == ''] = 'Unknown'
# tz_counts = clean_tz.value_counts()
# print(tz_counts[:10])
# tz_counts[:10].plot(kind='barh', rot=0)
# plt.show()

# print(fram['a'][1])
# print(fram['a'][50])
# print(fram['a'][51])

#用户行为摘要
# results = Series([x.split()[0] for x in fram.a.dropna()])
# print(results[:5])
# print(results.value_counts()[:8])

#移除agent缺失字段
cfram = fram[fram.a.notnull()]

#根据a值计算出各行是否是Windows
operating_system = np.where(cfram['a'].str.contains('Windows'), 'Windows', 'Not Windows')
# print(operating_system[:5])

#根据时区和新得到的操作系统对数据进行分组
by_tz_os = cfram.groupby(['tz', operating_system])

#size对分组进行计数,unstack进行重塑
agg_counts = by_tz_os.size().unstack().fillna(0)
# print(agg_counts[:10])

#根据agg_counts中的行数构造一个间接索引数组
indexer = agg_counts.sum(1).argsort()
# print(indexer[:10])

count_subset = agg_counts.take(indexer)[-10:]
# print(count_subset)

#条形图

# count_subset.plot(kind='barh', stacked=True)
normed_subset = count_subset.div(count_subset.sum(1), axis=0)
normed_subset.plot(kind='barh', stacked=True)
plt.show()