# -*- coding: utf-8 -*-
"""
@author: Edward
@file: movie_lens.py
@time: 2017/8/30 8:40
"""

import json
from collections import defaultdict
from collections import Counter
import pandas as pd
from pandas import DataFrame,Series
import numpy as np
import matplotlib.pyplot as plt

unames = ['user_id', 'gender', 'age', 'occupation', 'zip']
#pandas.read_talbe将各表分别读到一个pandas DataFrame对象中
users = pd.read_table('D:/py/pydata_master/ch02/movielens/users.dat', sep='::', header=None, names=unames, engine='python')

rnames = ['user_id', 'movie_id', 'rating', 'timestamp']
ratings = pd.read_table('D:/py/pydata_master/ch02/movielens/ratings.dat', sep='::', header=None, names=rnames, engine='python')

mnames = ['movie_id', 'title', 'genres']
movies = pd.read_table('D:/py/pydata_master/ch02/movielens/movies.dat', sep='::', header=None, names=mnames, engine='python')

# print(users[:5])
# print(ratings[:5])
# print(movies[:5])
# print(ratings)

#合并数据
data = pd.merge(pd.merge(ratings, users), movies)
# print(data)
# print(data.ix[0])

#根据性别计算某部电影的平均得分
#将rows改成index，cols写成全名”columns”:
# mean_ratings = data.pivot_table('rating', index='title', columns='gender', aggfunc='mean')
# print(mean_ratings[:5])

#过滤评分<250条电影
#size()得到一个含有电影分组大小的Series对象
ratings_by_title = data.groupby('title').size()
# print(ratings_by_title[:10])

active_titles = ratings_by_title.index[ratings_by_title >= 250]
# print(active_titles)

# mean_ratings = mean_ratings.ix[active_titles]
# print(mean_ratings)

#女性观众最喜欢的电影
#pandas0.18.1版本sort_index没有by参数
# top_female_ratings = mean_ratings.sort_index(by='F', ascending=False)
# top_female_ratings = mean_ratings.sort_values(by='F', ascending=False)
# print(top_female_ratings[:10])

#计算评分分歧
#男性和女性观众分歧最大的电影
#方法一：mean_ratings加上一个存放平均得分之差的列，然后排序
# mean_ratings['diff'] = mean_ratings['M'] - mean_ratings['F']
# sorted_by_diff = mean_ratings.sort_values(by='diff')
# print(sorted_by_diff[:15])

#对结果反序并取出前15房，测试男性更新的电影
# print(sorted_by_diff[::-1][:15])

#找出分歧最大的电影，不考虑性别，可以计算得分的方差或标准差
#根据电影名称分组的得分的标准差
ratings_std_by_title = data.groupby('title')['rating'].std()

#根据active_titles进行过滤
ratings_std_by_title = ratings_std_by_title.ix[active_titles]

#根据值对Series进行降序排列
# print(ratings_std_by_title.order(ascending=False)[:10])
print(ratings_std_by_title.sort_index(axis=0, ascending=False)[:10])