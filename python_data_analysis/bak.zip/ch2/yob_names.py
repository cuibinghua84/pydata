# -*- coding: utf-8 -*-
"""
@author: Edward
@file: yob_names.py
@time: 2017/8/30 13:44
"""

import json
from collections import defaultdict
from collections import Counter
import pandas as pd
from pandas import DataFrame,Series
import numpy as np
import matplotlib.pyplot as plt

#pandas.read_cav加载到DataFrame
# names1880 = pd.read_csv('D:/py/pydata_master/ch02/names/yob1880.txt', names=['name', 'sex', 'births'])
# print(names1880)

#当前出现超过5次的名字，用births列的sex分组小计标识该年度的births总计
# names1880.groupby('sex').births.sum()
# print(names1880.groupby('sex').births.sum())

#加载所有数据到一个DataFrame中，并加上一个year字段，使用pandas.concat
#2016是最后一个有效统计年
years = range(1880,2017)

pieces = []
columns = ['name', 'sex', 'births']

for year in years:
    path = 'D:/py/pydata_master/ch02/names/yob%d.txt' % year
    fram = pd.read_csv(path, names=columns)

    fram['year'] = year
    pieces.append(fram)
#将所有数据整合到单个DataFrame中
names = pd.concat(pieces, ignore_index=True)
# print(names)

#用groupb或pivot_table在year和sex级别上进行聚合
total_births = names.pivot_table('births', index='year', columns='sex', aggfunc=sum)
total_births.tail()
# print(total_births.tail())
# print(total_births)
# total_births.plot(title='Total births by sex and year')
# plt.show()

#插入prop列，存放指定名字婴儿数相对于总出生数的比例
# def add_prop(group):
#     #整数除法会向下园整
#     births = group.births.astype(float)
#
#     group['prop'] = births / births.sum()
#     return group
# names = names.groupby(['year', 'sex']).apply(add_prop)
# print(names)

# np.allclose(names.groupby(['year', 'sex']).prop.sum(),1)
# print(np.allclose(names.groupby(['year', 'sex']).prop.sum(),1))

# def get_top1000(group):
#     return group.sort_values(by='births', ascending=False)[:1000]
# grouped = names.groupby(['year', 'sex'])
# top1000 = grouped.apply(get_top1000)
pieces = []
for year, group in names.groupby(['year', 'sex']):
    pieces.append(group.sort_values(by='births', ascending=False)[:1000])
top1000 = pd.concat(pieces, ignore_index=True)
# print(top1000)

#名字命名趋势
boys = top1000[top1000.sex == 'M']
# girls = top1000[top1000.sex == 'F']

# total_births = top1000.pivot_table('births', index='year', columns='name', aggfunc=sum)
# print(total_births)

#绘制几个名字的曲线图
# subset = total_births[['John', 'Harry', 'Mary', 'Marilyn']]
# subset.plot(subplots=True, figsize=(12, 10), grid=False, title="Number of births per year")
# plt.show()

#计算最流行的1000个名字所占的比例
# table = top1000.pivot_table('prop', index='year', columns='sex', aggfunc=sum)
# table.plot(title='Sum of table1000.prop by year and sex', yticks=np.linspace(0, 1.2, 13), xticks=range(1880, 2020, 10))
# plt.show()

#计算占总出生人数前50%的不同名字的数量

df = boys[boys.year == 2010]
print(df)