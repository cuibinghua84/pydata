# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 3.1-数据结构和序列.py
@time: 2019/4/24 17:57
"""

# tup = 4, 5, 6
# print(tup)
#
# nested_tup = (4, 5, 6), (7, 8)
# print(nested_tup)

# tuple可以将任意序列或迭代器转换成元组
# print(tuple([4, 0, 2]))
# tup = tuple('string')
# print(tup)
# print(tup[0])

# 拆分元组
# tup = (4, 5, 6)
# a, b, c = tup
# print(a)
# print(b)
# print(c)

# tup1 = 4, 5, (6, 7)
# a, b, (c, d) = tup1
# print(a)
# print(b)
# print(c)

# 二分搜索和维护已排序的列表
import bisect

c = [1, 2, 2, 2, 3, 4, 7]
print(bisect.bisect(c, 2))
print(c)
print(bisect.bisect(c, 5))
print(c)




