# -*- coding: utf-8 -*-
# 作者      : p_bhcui
# 创建时间  : 2019/9/6 9:56
# 文件      : note.py
# IDE       : PyCharm

"""
常用数据结构：元组、列表、字典和集合
"""
# 元组
# tup = 4, 5, 6
# print(tup)
# nested_tup = (4, 5, 7), (7, 8)
# print(nested_tup)

# 元组转换函数 tuple
# print(tuple([4, 0, 2]))
# tup1 = tuple('string')
# print(tup1)

# 元组拆包
# tup2 = (4, 5, 6)
# a, b, c = tup2
# print(a, b, c)

# 嵌套元组拆包
# tup3 = 4, 5, (6, 7)
# a, b, (c, d) = tup3
# print(a)
# print(b)
# print(d)

seq = [(1, 2, 3), (4, 5, 6), (7, 8, 9)]
for a, b, c in seq:
    print('a={0}, b={1}, c={2}'.format(a, b, c))
