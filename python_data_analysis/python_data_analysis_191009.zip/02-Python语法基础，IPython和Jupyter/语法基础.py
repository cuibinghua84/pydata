# -*- coding: utf-8 -*-
"""
Created on Wed Apr 24 13:48:13 2019

@author: cuibinghua
"""

import numpy as np
from numpy.random import randn
from datetime import datetime, date, time

# data = {i : np.random.randn() for i in range(7)}
# print(data)

# data = {i : randn() for i in range(7)}
# print(data)

# =============================================================================
# # 日期和时间

# 
# dt = datetime(2019, 4, 24, 14, 5, 23)
# print(dt.year)
# print(dt.month)
# print(dt.day)
# print(dt.hour)
# print(dt.minute)
# print(dt.second)
# 
# print(dt.date())
# print(dt.time())
# 
# print(datetime.now().date())
# 
# # strftime格式化字符串
# print(dt.strftime('%m/%d/%Y %H:%M'))
# 
# # strptime将字符串转换成datetime对象
# print(datetime.strptime('20190424', '%Y%m%d'))
# =============================================================================

"""
%Y
%y
%m
%d
%H
%I
%M
%S
%w
%U
%W
%z
%F
%D
"""

# =============================================================================
sequence = [1, 2, None, 4, None, 5]
total = 0
for value in sequence:
    if value is None:
        continue
    total += value
print(total)
# =============================================================================

# =============================================================================
# sequence = [1, 2, 0, 4, 6, 5, 2, 1]
# total_until_5 = 0
# for value in sequence:
#     if value == 5:
#         break
#     total_until_5 += value
# print(total_until_5)
# =============================================================================

# =============================================================================
# for i in range(4):
#     for j in range(4):
#         if j > i:
#             break
#         print((i, j)    )
# =============================================================================

# x = 256
# total = 0
# while x > 0:
#     if total > 500:
#         break
#     total += x
#     x = x // 2
# print(total)

# print(list(range(10)))
# print(list(range(0, 20, 2)))
# print(list(range(5, 0, -1)))

# seq = [1, 2, 3, 4]
# for i in range(len(seq)):
#     val = seq[i]
# print(val)

sum = 0
for i in range(100000):
    if i % 3 == 0 and i % 5 == 0:
        print(i)
        # sum += i
        # print(sum)
# print(sum)


