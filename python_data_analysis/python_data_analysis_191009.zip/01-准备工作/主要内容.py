# -*- coding: utf-8 -*-
"""
Created on Wed Aug 22 09:44:00 2018

@author: cuibinghua
"""

# import scipy

"""
主要内容：利用Python进行数据控制、处理、整理、分析等方面的具体细节和基本要点；也是利用Python
进行科学计算的实用指南；重点介绍了用于高效解决各种数据分析问题的Python语言和库

数据：指的是结构化数据(structured data)，不如
多维数组
表格型数据，其中格列可能是不同的类型
通过关键列相关联系的多个表（对于SQL用户而言，就是主键和外键）
间隔平均或不平均的时间序列

重要Python库
NumPy：Python科学计算的基础包
	快速高效的多维数组对象ndarray
	用于对数组执行元素级计算以及直接对数组执行数学运算的函数
	用于读写硬盘上基于数组的数据集的工具
	线性代数运算、傅里叶变换，以及随机数生成
	成熟的C API，用于Python插架和原生C C++ Fortran代码访问NumPy的数据结构和计算工具

pandas：提供了使我们能够快速便捷地处理结构化数据的大量数据结构和函数

mattplotlib：用于绘制数据图表的Python库。

IPython：是Python科学计算标准工具集的组成部分，它将其他所有的东西联系到了一起

SciPy：一组专门解决科学计算中各种标准问题域的包的集合

scikit-learn：通用机器学习工具包

statsmodels：一个统计分析包
"""
# 惯例
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import statsmodels as sm

"""
行话
数据规整
	指的是将非结构化和散乱数据处理为结构化或整洁形式的整个过程。

伪码
	算法或过程的“代码式”描述，而这些代码本身并不是实际有效的源代码

语法糖
	这是一种编程语法，它并不会带来新的特性，但却能使代码更易读、更易写


"""
