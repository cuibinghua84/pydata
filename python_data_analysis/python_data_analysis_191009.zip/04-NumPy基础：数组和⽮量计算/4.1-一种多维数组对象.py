# -*- coding: utf-8 -*-
"""
@author: 东风
@file: 4.1-一种多维数组对象.py
@time: 2019/4/24 19:14
"""

import numpy as np

# data = np.random.randn(2, 3)
# print(data)
# print(data * 10)
# print(data + data)

# ndarry是一个通用的同构数据多维容器，其中的所有元素必须是相同类型的
# 每个数组都有一个shape：表示各维度大小的元组；dtype：说明数组数据类型的对象
# print(data.shape)
# print(data.dtype)

# 创建ndarray：使用函数array
# 还可以用zeros和ones分别可以创建指定长度或形状的全是0或全是1的数组
# empty可以创建一个没有任何具体值的数组
data1 = [6, 7.5, 8, 0, 1]
arr1 = np.array(data1)
print(arr1)

data2 = [[1, 2, 3, 4], [5, 6, 7, 8]]
arr2 = np.array(data2)
print(arr2)

# ndim
"""
数组创建函数
array

asarray

arange

ones, ones_like

zeros, zeros_like

empty, empty_like

full, full_like

eye, identitly

"""




