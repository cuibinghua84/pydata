# -*- coding: utf-8 -*-
"""
@author: 东风
@file: numpy_demo.py
@time: 2019/4/24 19:00
"""

import numpy as np

my_arr = np.arange(1000000)

my_list = list(range(1000000))


