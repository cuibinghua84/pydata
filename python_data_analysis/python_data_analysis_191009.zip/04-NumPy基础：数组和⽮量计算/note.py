# -*- coding: utf-8 -*-
# 作者      : p_bhcui
# 创建时间  : 2019/9/6 11:37
# 文件      : note.py
# IDE       : PyCharm

import numpy as np
import time

# 对比Python内建方法和NumPy方法的对比
# my_arr = np.arange(100000000)
# my_arr2_start = time.time()
# my_arr2 = my_arr * 2
# my_arr2_end = time.time()
# print(my_arr2_end - my_arr2_start)
#
# my_list = list(range(100000000))
# my_list2_start = time.time()
# my_list2 = my_list * 2
# my_list2_end = time.time()
# print(my_list2_end - my_list2_start)

# data = np.random.randn(2, 3)
# print(data)
# print(data * 10)
# print(data + data)
# print(data.shape)   # 表征数据每一维度的数量
# print(data.dtype)   # 描述数组的数据类型

# ndarray是一个通用的多维同类数据容器
# 生成数组最简单的方式就是使用array函数，可接受任意序列型对象
# data1 = [6, 7.5, 8, 0, 1]
# arr1 = np.array(data1)
# print(arr1)
# print(arr1.shape)
# print(arr1.dtype)

# 同等长度的列表，将会自动转换成多维数组
# print()
# data2 = [[1, 2, 3, 4], [5, 6, 7, 8]]
# arr2 = np.array(data2)
# print(arr2)
# print(arr2.shape)
# print(arr2.dtype)
# print(arr2.ndim)

# zeros一次性创造全是0数组
# print(np.zeros(10))
# print(np.zeros((3, 6)))

# ones一次性创造全1数组
# print(np.ones(10))
# print(np.ones((3, 6)))

# empty创建一个没有初始化数组的数组
# print(np.empty(10))
# print(np.empty((2, 3, 2)))

# arange是Python内建函数range的数组版
# print(np.arange(15))

# 4.1.2 ndarray的数据类型
# arr1 = np.array([1, 2, 3], dtype=np.float64)
# print(arr1.dtype)
#
# arr2 = np.array([1, 2, 3], dtype=np.int32)
# print(arr2.dtype)

# astype方法显式地转换数组的数据类型
# arr = np.array([1, 2, 3, 4, 5])
# print(arr.dtype)
# float_arr = arr.astype(np.float64)
# print(float_arr.dtype)

# 把浮点数转换成整数
# arr = np.array([3.7, -1.2, -2.6, 0.5, 12.9, 10.1])
# print(arr)
# print(arr.astype(np.int32))
# print(arr)

# numeric_strings = np.array(['1.25', '-9.6', '42'], dtype=np.string_)
# print(numeric_strings.astype(float))

# print()
# print("使用另一个数组的dtype属性")
# int_array = np.arange(10)
# print(int_array)
# calibers = np.array([.22, .270, .35, .380, .44, .50], dtype=np.float64)
# print(int_array.astype(calibers.dtype))

# print()
# print("使用类型代码来传入数据类型")
# empty_unint32 = np.empty(8, dtype='u4')
# print(empty_unint32)

# 4.1.3 NumPy数组算术
# 带有标量计算的算术操作，会把计算参数传递给数组的每一个元素
# arr = np.array([[1., 2., 3.], [4., 5., 6.]])
# print(arr)
# print(arr * arr)
# print(arr - arr)
# print(1 / arr)
# print(arr ** 0.5)

# print()
# print("arr2")
# arr2 = np.array([[0., 4., 1.], [7., 2., 12.]])
# print(arr2)
# print(arr2 > arr)

# 不同尺寸的数据间的操作，会用到广播特性
# 4.1.4 基础索引与切片
# arr = np.arange(10)
# print(arr)
# print(arr[5])
# print(arr[5:8])
# arr[5:8] = 12
# print(arr)

# arr_slice = arr[5:8]
# print(arr_slice)
# arr_slice[1] = 12345
# print(arr)
# arr_slice[:] = 64
# print(arr)

# arr2d = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
# print(arr2d[2])
# print(arr2d[0])
# print(arr2d[0][2])
# print(arr2d[0, 2])

# print()
# print("2x2x3的数组")
# arr3d = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])
# print(arr3d)
# print("***********************")
# print(arr3d[0])

# print()
# print("标量和数组都可以传递给ard3d[0")
# print(arr3d)
# old_values = arr3d[0].copy()
# arr3d[0] = 42
# print(arr3d)

# arr3d[0] = old_values
# print(arr3d)

# print(arr3d[1, 0])

# print()
# print("步骤分解")
# x = arr3d[1]
# print(x)
# print(x[0])

# print()
# print("数组的切片和索引")
# print(arr)
# print(arr[1:6])

# print(arr2d)
# print(arr2d[:2])
# print(arr2d[:2, 1:])
# print("\n选择第二行且前两列")
# print(arr2d[1])
# print(arr2d[1, :2])

# print()
# print("选择第三列，只选择前两行")
# print(arr2d[:2])
# print(arr2d[:2, 2])

# print()
# print(arr2d[:, :1])

# print("\n对切片重新赋值")
# print(arr2d[:2, 1:])
# arr2d[:2, 1:] = 0
# print(arr2d)

# 4.1.5布尔索引
names = np.array(['Bob', 'Joe', 'Will', 'Bob', 'Will', 'Joe', 'Jow'])
data = np.random.randn(7, 4)
print(names)
print(data)

# names中的每个人名都和data数组中的一行相对应，选取所有Bob对应的行
# 数组的比较也可以向量化
# 查收一个布尔数组值
# names == 'Bob'
# print(names == 'Bob')
# print(data[names == 'Bob'])
# 注意：布尔值数组的长度必须和数组轴索引长度一致

# print("用切片或整数值对布尔值数组进行混合和匹配")
# print(data[names == 'Bob', 2:])
# print(data[names == 'Bob', 3])

# print("\n选择除了'Bob'以外的其他数据，可使用!=或在表达式前使用~对条件取反")
# names != 'Bob'
# print(data[names != 'Bob'])
# 或
# print(data[~(names == 'Bob')])

# ~可以在你想要对一个通用条件进行取反时使用
print()
cond = names == 'Bob'
print(data[~cond])

print("\n")