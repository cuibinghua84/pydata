# -*- coding: utf-8 -*-
"""
Created on Fri Apr 26 14:00:30 2019

@author: cuibinghua
"""

import numpy as np

# 一、NumPy简介
# Numpy部分功能

# NumPy关注的功能

# NumPy高效处理大数组的原因


# 二、NumPy的ndarray：一种多维数组对象
# 生成一个包含随机数据的小数组
# data = np.random.randn(2, 3)
# print(data)

# 随机小数组进行数学运算
# print(data * 10)
# print(data + data)

# ndarray是一个通用的同构数据多维容器：所有元素必须是相同类型的
# shape和dtype的含义及用法
# print(data.shape)
# print(data.dtype)

# 创建ndarray的函数
"""
array:
asarray:
range:
ones,ones_like:
zeros,zeros_like:
empty,empty_like:
full,full_like:
eye,identity:
""" 

# NumPy的数据类型：
"""
int8,uint8
int16,uint16
int32,uint32
int64,uint64
float16
float32
float64
float128
complex64 complex128
complex256
bool
object
string_
unicode_
"""

# astype数组类型转换函数
# 实例：整数转换成浮点数
# 实例：字符串全是数字转换为数值


# NumPy数组的运算：大小相等的数组之间的任何运算都会将运算应用到元素级
# arr = np.array([[1., 2., 3.], [4., 5., 6.]])
# arr = np.array([[1., 2., 3.], [4., 5., 6.]])
# print(arr)
# print(arr * arr)
# print()
# print(arr - arr)
# print()

# 数组与标量的算数运算会将标量值传播到各个元素
# print(1 / arr)
# print()
# print(arr ** 0.5)

# 大小相同的数组之间的比较会生成布尔值数组
# 不同大小的数组之间的运算叫做广播
# arr2 = np.array([[0., 4., 1.], [7., 2., 12.]])
# print(arr2)
# print()
# print(arr2 > arr)


# 基本的索引和切片
# 将标量赋值给一个切片时，该值回自动传播
# 跟列表最重要的区别在于，数组切片是原始数组的视图，意味着数据不会被复制，视图上的任何修改都会直接反映到原数组上
arr = np.arange(10)
# print(arr)
# print(arr[5])
# print(arr[5:8])

arr[5:8] = 12
# print(arr)


arr_slice = arr[5:8]
print(arr_slice)
arr_slice[1] = 12345
print(arr)
# [:]会给数组中的所有值赋值
arr_slice[:] = 64
print(arr)


